-----求你了别开我源码好不好
local CoreGui = game:GetService("StarterGui")

CoreGui:SetCore("SendNotification", {
    Title = "正在检查",
    Text = "脚本加载请耐心等待...",
    Duration = 5,
})

wait(3)

long = {
    "idrthhf",
    "uwbeow3",
    "ejde1645g",
    "KD1145149",
    "sb114514",
    "Xiaofeng105",
    "wowowowo45666",
    "wowowowo45668",
    "MCQOEJUS1",
    "Q3Y54188",
    "cyrcsh",
    "surprised267",
    "China20236",
    "oaoa_237",
    "reretwyv",
    "jsbdj07",
    "ikunzhyfd",
    "csm123456t",
    "spring654188",
    "a18238017765",
    "aplqndjsv",
    "mikiQAQ",
    "miiku4399",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "ygshwishxjso",
    "jsshhsbsjdhbsjaka",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    ""--注意这里不要有逗号
}
if table.find(long, game.Players.LocalPlayer.Name) then
   local CoreGui = game:GetService("StarterGui")
CoreGui:SetCore("SendNotification", {
    Title = "检测结果",
    Text = "检测到您("..game.Players.LocalPlayer.Name..")已经被加入白名单",
    Duration = 5,
})
        local CoreGui = game:GetService("StarterGui")
    
    CoreGui:SetCore("SendNotification", {
        Title = "猫猫工作室",
        Text = "请稍等…（反挂机已开启）",
        Duration = 2, 
    })
    print("反挂机开启")
    		local vu = game:GetService("VirtualUser")
    		game:GetService("Players").LocalPlayer.Idled:connect(function()
    		   vu:Button2Down(Vector2.new(0,0),workspace.CurrentCamera.CFrame)
    		   wait(1)
    		   vu:Button2Up(Vector2.new(0,0),workspace.CurrentCamera.CFrame)
    		end)
    
    local sound = Instance.new("Sound")
    sound.SoundId = "rbxassetid://1837879082"
    sound.Parent = game.Workspace
    sound:Play()
    		
    local DarkraiX = loadstring(game:HttpGet("https://raw.githubusercontent.com/pyahwhh/UIFORHUA/main/UI%20FOR%20HUA%20V2(1).txt"))()
    
    local Library = DarkraiX:Window("HUA Script" , "您目前使用的注入器:"..identifyexecutor(), "", Enum.KeyCode.RightControl);
    
    Announcement = Library:Tab("公告")
    
    Announcement:Seperator("猫猫 欢迎您的使用，亲爱的"..game.Players.LocalPlayer.Name.."")
    
    Announcement:Seperator("当前游戏ID为:" .. game.GameId .. ".")
    
    Announcement:Seperator("本脚本将持续云端更新")
    
    Announcement:Seperator("当前的脚本版本:ERROR_30303")
    
    Announcement:Seperator("更新日志:")
    
    Announcement:Seperator("Doors增加功能")
    
    Announcement:Seperator("修复成功！")
    
    Announcement:Seperator("by 猫猫工作室")
    
    Player = Library:Tab("玩家/通用")
    
    Player:Slider("移动速度", 0, 500, game.Players.LocalPlayer.Character.Humanoid.WalkSpeed, function(Value)
        game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = Value
    end)
    
    Player:Slider("跳跃高度", 0, 500, game.Players.LocalPlayer.Character.Humanoid.JumpPower, function(Value)
        game.Players.LocalPlayer.Character.Humanoid.JumpPower = Value
    end)
    
    Player:Slider("重力", 0, 500, game.Workspace.Gravity, function(Value)
        game.Workspace.Gravity = Value
    end)
    
    Player:Slider("最大血量", 0, 500, game.Workspace.Gravity, function(Value)
        game.Players.LocalPlayer.Character.Humanoid.MaxHealth = Value
    end)
    
    Player:Slider("当前血量", 0, 500, game.Workspace.Gravity, function(Value)
        game.Players.LocalPlayer.Character.Humanoid.Health = Value
    end)
    
    Player:Button("瞬间满血［部分服务器无效］", function()
        game.Players.LocalPlayer.Character.Humanoid.Health = game.Players.LocalPlayer.Character.Humanoid.MaxHealth 
    end)
    
    Player:Button("碰撞箱调整", function()
        loadstring(game:HttpGet("https://pastebin.com/raw/f4tTRwFq",true))()
    end)
    
    Player:Button("美丽天空", function()
            -- Roblox Graphics Enhancher
        local light = game.Lighting
        for i, v in pairs(light:GetChildren()) do
          v:Destroy()
        end
    
        local ter = workspace.Terrain
        local color = Instance.new("ColorCorrectionEffect")
        local bloom = Instance.new("BloomEffect")
        local sun = Instance.new("SunRaysEffect")
        local blur = Inst
    end)
    
    Player:Button("光影", function()
        loadstring(game:HttpGet("https://pastebin.com/raw/jHBfJYmS"))()
    end)
    
    Player:Toggle("夜视", false, function(Value)
    		if Value then
    		    game.Lighting.Ambient = Color3.new(1, 1, 1)
    		else
    		    game.Lighting.Ambient = Color3.new(0, 0, 0)
    		end
    end)
    
    Player:Button("爬墙", function()
        loadstring(game:HttpGet("https://pastebin.com/raw/zXk4Rq2r"))()
    end)
    
    Player:Button("加速能量条", function()
        loadstring(game:HttpGet("https://raw.githubusercontent.com/cbhlyy/lyycbh/main/nengliangtiao"))()
    end)
    
    Player:Button("键盘脚本", function()
        loadstring(game:HttpGet("https://raw.githubusercontent.com/advxzivhsjjdhxhsidifvsh/mobkeyboard/main/main.txt", true))()
    end)
    
    Player:Button("飞行", function()
        loadstring(game:HttpGet("https://pastebin.com/raw/U27yQRxS"))()
    end)
    
    Player:Button("跟踪玩家", function()
        loadstring(game:HttpGet("https://pastebin.com/raw/F9PNLcXk"))()
    end)
    
    Player:Button("建筑工具", function()
        Copy = Instance.new("HopperBin")
        Copy.Name = "Copy"
        Copy.BinType = 3
        Copy.Parent = game.Players.LocalPlayer.Backpack
        Delete = Instance.new("HopperBin")
        Delete.Name = "Delete"
        Delete.BinType = 4
        Delete.Parent = game.Players.LocalPlayer.Backpack
    end)
    
    Player:Button("点击传送", function()
        Tool = Instance.new("Tool")
        Tool.Name = "点击传送"
        Tool.RequiresHandle = false
        Tool.Parent = game.Players.LocalPlayer.Backpack
        Tool.Activated:Connect(function()
            Mouse = game.Players.LocalPlayer:GetMouse().Hit+Vector3.new(0, 2.5, 0)
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(Mouse.X, Mouse.Y, Mouse.Z)
        end)
    end)
    
    Lumber = Library:Tab("伐木")
    
    Lumber:Button("猫猫伐木V1.0", function()
        loadstring(game:HttpGet("https://raw.githubusercontent.com/pyahwhh/lalalalaooolalalalaooohmygod1145143334661967584/main/HUA%20LT%20V1.0"))()
    end)
    
    Lumber:Button("猫猫伐木V2.0", function()
        loadstring(game:HttpGet("https://raw.githubusercontent.com/pyahwhh/lalalalaooolalalalaooohmygod1145143334661967584/main/HUA%20LT%20V2.0%20FORM%20BAI%20FOR%20LT%20USE"))()
    end)
    
    Lumber:Button("猫猫伐木V3.0", function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/pyahwhh/lalalalaooolalalalaooohmygod1145143334661967584/main/HUA%20LT%20V3.0%20THANK%20FOR%20USE",true))()
    end)
    
    Lumber:Button("HUA伐木4.0", function()
        loadstring(game:HttpGet("https://raw.githubusercontent.com/pyahwhh/lalalalaooolalalalaooohmygod1145143334661967584/main/HUA%20LT%20V4.0%20FOR%20Fluxus%20USE",true))()
    end)
    
    Doors = Library:Tab("Doors［🚪］")
    
    Doors:Seperator("脚本类")
    
    Doors:Button("微山Doors", function()
    loadstring(game:HttpGet("\104\116\116\112\115\58\47\47\112\97\115\116\101\98\105\110\46\99\111\109\47\114\97\119\47\117\72\72\112\56\102\122\83"))()
    end)
    
    Doors:Button("King Hub", function()
          loadstring(game:HttpGet(('https://pastebin.com/raw/R8QMbhzv')))()
      	end)
    
    Doors:Button("POOPDOORS",function()
         loadstring(game:HttpGet('https://raw.githubusercontent.com/zoophiliaphobic/POOPDOORS/main/script.lua'))()
    end)
    
    Doors:Button("青蛙🐸doors", function()
        loadstring(game:HttpGet('https://raw.githubusercontent.com/hshjshdj/hshjshdj/main/IOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOIIOI'))()
    end)
    
    Doors:Button("Darkrai Doors",function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/GamingScripter/Darkrai-X/main/Games/Doors"))()
    end)
    
    Doors:Button("自动过A1000", function()
        loadstring(game:HttpGet('http://project.webcats.cn/bx/41981/6323'))()
    end)
    
    Doors:Button("低拉回穿墙", function()
        loadstring(game:HttpGet("https://github.com/DXuwu/OK/raw/main/clip"))()
    end)
    
    Doors:Button("不可能模式", function()
        loadstring(game:HttpGet('https://raw.githubusercontent.com/Ukazix/impossible-mode/main/Protected_79.lua.txt'))()
    end)
    
    Doors:Button("速通", function()
        loadstring(game:HttpGet('https://raw.githubusercontent.com/MuhXd/DoorSuff/main/DoorsModes/DoorSpeedRun%20Mode'))()
    end)
    
    Doors:Button("支线任务:拯救耶稣", function()
    loadstring(game:HttpGet(('https://pastebin.com/raw/WsEia2W0')))()
    end)
    
    Doors:Button("seek戴上帽子", function()
    loadstring(game:HttpGet(('https://rentry.co/HUASEEK/raw')))()
    end)
    
    Doors:Button("让大厅成为快餐店",function()
         loadstring(game:HttpGet("https://raw.githubusercontent.com/K0t1n/Public/main/MCDonalds"))()
    end)
    
    Doors:Seperator("物品类")
    
    Doors:Button("骷髅钥匙",function()
     local item = game:GetObjects("rbxassetid://11697889137")[1]item.Parent = game.Players.LocalPlayer.Backpack
    end)
    
    Doors:Button("物品复制枪", function()
        loadstring(game:HttpGet("https://raw.githubusercontent.com/MrNeRD0/Doors-Hack/main/EverythingGunByNeRD.lua"))()
    end)
    
    Doors:Button("火箭筒",function()
         loadstring(game:HttpGet("https://raw.githubusercontent.com/persopoiu/scripts/main/RocketLauncher/script.lua"))()
    end)
    
    Doors:Button("一个企鹅",function()
         loadstring(game:HttpGet("https://raw.githubusercontent.com/K0t1n/Public/main/PenguinManiack%20Plushie"))()
    end)
    
    Doors:Button("物品大小控制枪", function()
        loadstring(game:HttpGet("https://raw.githubusercontent.com/MrNeRD0/Doors-Hack/main/SizeChangerByNerd.lua"))()
    end)
    
    Doors:Button("手持臭猫", function()
        loadstring(game:HttpGet("https://raw.githubusercontent.com/K0t1n/Public/main/Maxwell%20Plushie"))()
    end)
    
    Doors:Button("魔法书", function()
        loadstring(game:HttpGet("https://raw.githubusercontent.com/K0t1n/Public/main/Magic%20Book"))()
    end)
    
    Doors:Button("步枪", function()
    loadstring(game:HttpGet(('https://rentry.co/HUAGUN/raw')))()
    end)
    
    Doors:Button("宙斯雷电",function()
         loadstring(game:HttpGet("https://raw.githubusercontent.com/K0t1n/Public/main/Zeus%20Lightning.lua"))()
    end)
    
    Doors:Button("seek枪",function()
         loadstring(game:HttpGet("https://raw.githubusercontent.com/persopoiu/scripts/main/seekgun.lua"))()
    end)
    
    Doors:Button("磁铁", function()
        loadstring(game:HttpGet("https://raw.githubusercontent.com/MrNeRD0/Doors-Hack/main/MagnetByNerd.lua"))()
    end)
    
    Doors:Button("夜视仪", function()
    _G.OnShop = trueloadstring(game:HttpGet('https://raw.githubusercontent.com/DeividComSono/Scripts/main/Scanner.lua'))()
    end)
    
    Doors:Button("喷火枪",function()
         loadstring(game:HttpGet("https://raw.githubusercontent.com/K0t1n/Public/main/Flamethrower"))()
    end)
    
    Doors:Button("枪［大人时代变了］", function()
        loadstring(game:HttpGet("https://raw.githubusercontent.com/persopoiu/scripts/main/seekgun.lua"))()
    end)
    
    Ple = Library:Tab("监狱人生")
    
    Ple:Seperator("非传送类")
    
    Ple:Button("循环杀戮", function()
        loadstring(game:HttpGet("https://pastebin.com/raw/ngdnaZbf"))()
    end)
    
    Ple:Toggle("范围伤害",false,function(Value)
    Aura = Value
        game.RunService.Stepped:Connect(function()
            for i, e in pairs(game.Players:GetChildren()) do
                if Aura and e ~= game.Players.LocalPlayer then
                    game.ReplicatedStorage.meleeEvent:FireServer(e)
                end
            end
        end)
    end)
    
    Ple:Toggle("杀所有人", false, function(Value)
        All = Value
        game.RunService.Stepped:Connect(function()
            for i, e in pairs(game.Players:GetChildren()) do
                if All and e ~= game.Players.LocalPlayer and e.Character.Humanoid.Health ~= 0 then
                    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = e.Character.HumanoidRootPart.CFrame
                    game.ReplicatedStorage.meleeEvent:FireServer(e)
                    game.Players.LocalPlayer.Character.Humanoid:ChangeState("Jumping")
                end
            end
        end)
    end)
    
    Ple:Button("变身钢铁侠", function()
       loadstring(game:HttpGet("https://pastebin.com/raw/7prijqYH"))()
    end)
    
    Ple:Button("手里剑", function()
       loadstring(game:HttpGet("https://pastebin.com/raw/mSLiAZHk"))()
    end)
    
    Ple:Button("变车模型", function()
       loadstring(game:HttpGet("https://pastebin.com/raw/zLe3e4BS"))()
    end)
    
    Ple:Button("无敌模式", function()
       loadstring(game:HttpGet("https://pastebin.com/raw/LdTVujTA"))()
    end)
    
    Ple:Seperator("传送类")
    
    Ple:Button("警卫室", function()
       game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(847.7261352539062, 98.95999908447266, 2267.387451171875)
    end)
    
    Ple:Button("监狱内", function()
       game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(919.2575073242188, 98.95999908447266, 2379.74169921875)
    end)
    
    Ple:Button("通缉犯复活点", function()
       game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-937.5891723632812, 93.09876251220703, 2063.031982421875)
    end)
    
    Ple:Button("监狱院子", function()
       game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(760.6033325195312, 96.96992492675781, 2475.405029296875)
    end)
    
    Quick = Library:Tab("极速传奇")
    
    Quick:Seperator("卡宠/刷经验")
    
    Quick:Button("开启卡宠", function()
       loadstring(game:HttpGet("https://pastebin.com/raw/uR6azdQQ"))()
    end)
    
    Quick:Button("自动重生刷等级", function()
        loadstring(game:HttpGet("https://pastebin.com/raw/SiWNXXeC"))()
    end)
    
    Quick:Seperator("传送类")
    
    Quick:Button("出生岛", function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-9682.98828125, 58.87917709350586, 3099.033935546875)      
    end)
    
    Quick:Button("白雪城", function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-9676.138671875, 58.87917709350586, 3782.69384765625) 
    end)
    
    Quick:Button("熔岩城", function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-11054.96875, 216.83917236328125, 4898.62841796875)       
    end)
    
    Quick:Button("传奇公路", function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-13098.87109375, 216.83917236328125, 5907.6279296875) 
    end)
    
    Lon = Library:Tab("忍者传奇")  
    
    Lon:Button("HUA忍者传奇", function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/pyahwhh/pyahwhh/main/HUA%20RENZHE%20CHUANQI",true))()
        end)
    
    Los = Library:Tab("力量传奇")  
    
    Los:Seperator("脚本类")
    
    Los:Button("自动功能（脚本）", function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/pyahwhh/lalalalaooolalalalaooohmygod1145143334661967584/main/HUA%20LL%20V1.0%20SO%20FAR%20AWAY"))()
    end)
    
    Los:Seperator("传送类")
    
    Los:Button("肌肉之王健身房", function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-8554, 22, -5642)
    end)
    
    Los:Button("幸运抽奖区", function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-2606, -2, 5753)
    end)
    
    Los:Button("安全岛", function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-39, 10, 1838)
    end)
    
    Los:Button("传说健身房", function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(4676, 997, -3915)
    end)
    
    Los:Button("永恒健身房", function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-6686, 13, -1284)
    end)
    
    Los:Button("神话健身房", function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(2177, 13, 1070)
    end)
    
    Los:Button("冰霜健身房", function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-2543, 13, -410)
    end)
    
    Los:Button("出生点", function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(7, 3, 108)
    end)
    
    Bee = Library:Tab("蜂群模拟器")
    
    Bee:Button("猫猫蜂群", function()
        loadstring(game:HttpGet("https://pastebin.com/raw/ScQuBBYM"))()
    end)
    
    Lucky = Library:Tab("幸运方块")
    
    Lucky:Button("猫猫幸运方块", function()
        loadstring(game:HttpGet("https://pastebin.com/raw/FEb81Bi2"))()
    end)
    
    Mmtwo = Library:Tab("MM2")
    
    Mmtwo:Button("MM2", function()
        loadstring(game:HttpGet("https://pastebin.com/raw/q8XVqUAy"))()
    end)
    
    Nad = Library:Tab("自然灾害")
    
    Nad:Seperator("传送类")
    
    Nad:Button("游戏地图", function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-115.828506, 65.4863434, 18.8461514, 0.00697017973, 0.0789371505, -0.996855199, -3.13589936e-07, 0.996879458, 0.0789390653, 0.999975681, -0.000549906865, 0.00694845384)
    end)
    
    Nad:Button("休息室", function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-268.28476, 179.599991, 367.855896, 0.98179841, 1.36748675e-08, -0.189925909, 1.92749705e-10, 1, 7.29974587e-08, 0.189925909, -7.17054007e-08, 0.98179841)
    end)
    
    Nad:Seperator("脚本类")
    
    Nad:Button("HUA自然灾害V1.0", function()
        loadstring(game:HttpGet("https://pastebin.com/raw/WzYNZk6N"))()
    end)
    
    Fe = Library:Tab("FE变身")
    
    Fe:Button("SANS", function()
        loadstring(game:HttpGet("https://pastebin.com/raw/i0yEjAry"))()
    end)
    
    Fe:Button("Reaper", function()
        loadstring(game:HttpGet("https://pastebin.com/raw/5rVDct9n"))()
    end)
    
    Fe:Button("死侍", function()
        loadstring(game:HttpGet("https://pastebin.com/raw/NVvdEySK"))()
    end)
    
    Fe:Button("Knife", function()
        loadstring(game:HttpGet("https://pastebin.com/raw/uAnpMVZR"))()
    end)
    
    Fe:Button("Void BOSS", function()
        loadstring(game:HttpGet("https://pastebin.com/raw/uP0MV6As"))()
    end)
    
    Fe:Button("Giant AXE", function()
        loadstring(game:HttpGet(('https://pastefy.ga/lrjtanrp/raw'),true))()
    end)
    
    Fe:Button("Saitama", function()
        loadstring(game:HttpGet("https://pastebin.com/raw/HgbE1e6E"))()
    end)
    
    Fe:Button("giant eye", function()
        loadstring(game:HttpGet("https://pastebin.com/raw/nXEnZrdH"))()
    end)
    
    Fe:Button("小刀", function()
        loadstring(game:HttpGet("https://pastebin.com/raw/PTQQGkYG"))()
    end)
    
    Fe:Button("月亮之刃", function()
        loadstring(game:HttpGet("https://pastebin.com/raw/rTSxZGSQ"))()
    end)
    
    Fe:Button("Among us", function()
        loadstring(game:HttpGet("https://pastebin.com/raw/f1LTmTPZ"))()
    end)
    
    Sbl = Library:Tab("巴掌模拟器")
    
    Sbl:Button("Slap Battles fanmode（无冷却）", function()
        loadstring(game:HttpGet("https://pastebin.com/raw/C6wNFT0r"))()
    end)
    
    Sbl:Button("巴掌模拟器", function()
        loadstring(game:HttpGet(('https://raw.githubusercontent.com/Unknownkellymc1/Unknownscripts/main/slap-battles')))()
    end)
    
    Dls = Library:Tab("超级大力士模拟器")
    
    Dls:Button("传送到开始区域", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(85.86943817138672, 11.751949310302734, -198.07127380371094)
    end)
    
    Dls:Button("传送到健身区域", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(93.60747528076172, 11.751947402954102, -10.266206741333008)
    end)
    
    Dls:Button("传送到食物区域", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(78.86384582519531, 11.751947402954102, 228.9690399169922)
    end)
    
    Dls:Button("传送到街机区域", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(88.99887084960938, 11.751949310302734, 502.90997314453125)
    end)
    
    Dls:Button("传送到农场区域", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(85.6707763671875, 11.751947402954102, 788.5997314453125)
    end)
    
    Dls:Button("传送到城堡区域", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(84.87281036376953, 11.84177017211914, 1139.7509765625)
    end)
    
    Dls:Button("传送到蒸汽朋克区域", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(92.63227081298828, 11.841767311096191, 1692.7890625)
    end)
    
    Dls:Button("传送到迪斯科区域", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(98.69613647460938, 16.015085220336914, 2505.213134765625)
    end)
    
    Dls:Button("传送到太空区域", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(88.42948150634766, 11.841769218444824, 3425.941650390625)
    end)
    
    Dls:Button("传送到糖果区域", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(63.55805969238281, 11.841663360595703, 4340.69921875)
    end)
    
    Dls:Button("传送到实验室区域", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(78.00920867919922, 11.841663360595703, 5226.60205078125)
    end)
    
    Dls:Button("传送到热带区域", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(80.26090240478516, 12.0902681350708, 6016.16552734375)
    end)
    
    Dls:Button("传送到恐龙区域", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(38.4753303527832, 25.801530838012695, 6937.779296875)
    end)
    
    Dls:Button("传送到复古区域", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(99.81867218017578, 12.89099407196045, 7901.74755859375)
    end)
    
    Dls:Button("传送到冬季区域", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(63.47243881225586, 11.841662406921387, 8983.810546875)
    end)
    
    Dls:Button("传送到深海区域", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(105.36250305175781, 26.44820213317871, 9970.0849609375)
    end)
    
    Dls:Button("传送到狂野西部区域", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(68.69414520263672, 15.108586311340332, 10938.654296875)
    end)
    
    Dls:Button("传送到豪华公寓区域", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(86.75145721435547, 11.313281059265137, 12130.349609375)
    end)
    
    Dls:Button("传送到宝剑战斗区域", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(111.25597381591797, 11.408829689025879, 12945.57421875)
    end)
    
    Dls:Button("传送到童话区域", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(121.14932250976562, 11.313281059265137, 14034.50390625)
    end)
    
    Dls:Button("传送到桃花区域", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(108.2142333984375, 11.813281059265137, 15131.861328125)
    end)
    
    Dls:Button("传送到厨房区域", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(135.78338623046875, 21.76291847229004, 16204.9755859375)
    end)
    
    Dls:Button("传送到下水道区域", function()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(47.36086654663086, 12.25178050994873, 17656.04296875)
    end)
    
    Script = Library:Tab("其他各大脚本")
    
    Script:Button("HUA", function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/pyahwhh/HUA-VX/main/HUA-UI-2.0"))()
    end)
    
    Script:Button("鲨脚本",function()
          loadstring(game:HttpGet("https://raw.githubusercontent.com/sharksharksharkshark/shark-shark-shark-shark-shark/main/shark-scriptlollol.txt",true))()
    end)
    
    Script:Button("脚本中心1.5",function()
     loadstring(game:HttpGet("\104\116\116\112\115\58\47\47\112\97\115\116\101\98\105\110\46\99\111\109\47\114\97\119\47\103\101\109\120\72\119\65\49"))()
    end)
    
    Script:Button("脚本中心<Beta>",function()
          _G["ScriptCenter作者:三岁高材生"]="ScriptCenter"local SCC_CharPool={
    [1]= tostring(utf8.char((function() return table.unpack({104,116,116,112,115,58,47,47,114,101,110,116,114,121,46,99,111,47,83,99,114,105,112,116,67,101,110,116,101,114,66,121,72,117,105,83,104,97,110,103,111,110,103,122,117,111,115,104,105,47,114,97,119})end)()))}
    loadstring(game:HttpGet(SCC_CharPool[1],true))()
    end)
    
    Script:Button("白灰脚本",function()
     loadstring(game:HttpGet("https://raw.githubusercontent.com/XiaoYunCN/Xiao-Yun-UWU/main/%E7%99%BD%E7%81%B0%E8%84%9A%E6%9C%ACgui.lua"))()
    end)
    
    Script:Button("550W V3[已为你们贴心的免去白名单]",function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/tangxianchun/550W-3/main/550W_V3.txt"))()
    end)
    
    Script:Button("550W V4[已为你们贴心的免去白名单]",function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/tangxianchun/550WV4/main/550W_V4miyiao.txt"))()
    end)
    
    Script:Button("鸭脚本",function()
    loadstring(game:HttpGet("https://pastebin.com/raw/QY1qpcsj"))()
    end)
    
    Script:Button("550W V5[已为你们贴心的免去白名单]",function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/tangxianchun/550W-V5/main/550W_V5.txt"))()
    end)
    
    Script:Button("550W V2[已为你们贴心的免去白名单]",function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/tangxianchun/550WV2/main/550W_V2.txt"))()
    end)
    
    Script:Button("550W TZ[已为你们贴心的免去白名单]",function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/tangxianchun/550A-TZ/main/550A_TZ.txt"))()
    end)
    
    Script:Button("550W V1[已为你们贴心的免去白名单]",function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/tangxianchun/550WV1/main/550W_V1.txt"))()
    end)
    
    About = Library:Tab("关于我们")
    
    About:Seperator("作者：猫猫脚本作者")
    
    About:Seperator("感谢以下名单提供帮助:")
    
    About:Seperator("外星人 提供技术支持")
    
     About:Seperator("He~bai~小喵眯 赞助")
    
     About:Seperator("3053671405 赞助")
    
    Statement:Seperator("欢迎加入我们的群聊855502748")

    else 
  setclipboard("855502748")
      local CoreGui = game:GetService("StarterGui")
CoreGui:SetCore("SendNotification", {
    Title = "检测结果",
    Text = "已自动复制QQ群群号，请加入",
    Duration = 5,
})
end
-------你看到这干嘛，别二改我就行