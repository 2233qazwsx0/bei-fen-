local library = loadstring(game:HttpGet('https://raw.githubusercontent.com/sharksharksharkshark/-/main/black%20ui.txt'))()

local Window = library:CreateWindow("创想工作室", "脚本整合", 132872684918876)

local Tab = Window:CreateTab("欢迎使用")

local Page = Tab:CreateFrame("主要")

local Button1 = Page:CreateButton("飞行", "起飞~", function()
    loadstring("\108\111\97\100\115\116\114\105\110\103\40\103\97\109\101\58\72\116\116\112\71\101\116\40\34\104\116\116\112\115\58\47\47\112\97\115\116\101\98\105\110\46\99\111\109\47\114\97\119\47\90\66\122\99\84\109\49\102\34\41\41\40\41\10")()
end)

local Button2 = Page:CreateButton("隐身", "", function()
    loadstring(game:HttpGet("https://gist.githubusercontent.com/skid123skidlol/cd0d2dce51b3f20ad1aac941da06a1a1/raw/f58b98cce7d51e53ade94e7bb460e4f24fb7e0ff/%257BFE%257D%2520Invisible%2520Tool%2520(can%2520hold%2520tools)",true))()
end)

local Button3 = Page:CreateButton("范围", "小型", function()
    loadstring(game:HttpGet("https://pastebin.com/raw/trQyNUD4",true))()
end)

local Button4 = Page:CreateButton("十年老兵", "娱乐专用", function()
    loadstring(game:HttpGet('https://pastebin.com/raw/r97d7dS0', true))()
end)

local Toggle = Page:CreateToggle("夜视", " ", function(Value)
    if Value then
        game.Lighting.Ambient = Color3.new(1, 1, 1)
    else
        game.Lighting.Ambient = Color3.new(0, 0, 0)
    end
end)

local originalSizes = {}

local function applyBigHead()
    local Settings = {Size = 8}
    local Players = game:GetService("Players")
    local LocalPlayer = Players.LocalPlayer

    local function Alive(player)
        if player then
            return player.Character and player.Character:FindFirstChild("Head") and player.Character:FindFirstChild("Humanoid") or false
        end
        return false
    end

    for _, player in pairs(Players:GetPlayers()) do
        if player ~= LocalPlayer and Alive(player) then
            local head = player.Character.Head
            if not originalSizes[player] then
                originalSizes[player] = head.Size
            end
            head.Massless = true
            head.Size = Vector3.new(Settings.Size, Settings.Size, Settings.Size)
        end
        player.CharacterAdded:Connect(function()
            while not Alive(player) do wait() end
            local head = player.Character.Head
            if not originalSizes[player] then
                originalSizes[player] = head.Size
            end
            head.Massless = true
            head.Size = Vector3.new(Settings.Size, Settings.Size, Settings.Size)
        end)
    end

    Players.PlayerAdded:Connect(function(player)
        player.CharacterAdded:Wait()
        if Alive(player) then
            local head = player.Character.Head
            if not originalSizes[player] then
                originalSizes[player] = head.Size
            end
            head.Massless = true
            head.Size = Vector3.new(Settings.Size, Settings.Size, Settings.Size)
        end
        
        player.CharacterAdded:Connect(function()
            while not Alive(player) do wait() end
            local head = player.Character.Head
            if not originalSizes[player] then
                originalSizes[player] = head.Size
            end
            head.Massless = true
            head.Size = Vector3.new(Settings.Size, Settings.Size, Settings.Size)
        end)
    end)
end

local function resetBigHead()
    local Players = game:GetService("Players")
    
    for _, player in pairs(Players:GetPlayers()) do
        if player.Character and player.Character:FindFirstChild("Head") then
            local head = player.Character.Head
            head.Massless = false
            head.Size = originalSizes[player] or Vector3.new(2, 1, 1) -- Use original size or default size if not recorded
        end
    end
    
    Players.PlayerAdded:Connect(function(player)
        player.CharacterAdded:Connect(function(character)
            if character:FindFirstChild("Head") then
                local head = character.Head
                head.Massless = false
                head.Size = originalSizes[player] or Vector3.new(2, 1, 1) -- Use original size or default size if not recorded
            end
        end)
    end)
end

local BigHeadToggle = Page:CreateToggle("大头", "让所有人的头变大", function(Value)
    if Value then
        applyBigHead()
    else
        resetBigHead()
    end
end)

local WarPage = Tab:CreateFrame("DOORS")

local WarButton1 = WarPage:CreateButton("脚本", "带汉化", function()
    loadstring(game:HttpGet("\104\116\116\112\115\58\47\47\112\97\115\116\101\98\105\110\46\99\111\109\47\114\97\119\47\54\53\84\119\84\56\106\97"))()
end)

local WarButton2 = WarPage:CreateButton("正在更新", "目前只有这么多", function()
    -- 在这里添加按钮2的功能代码
end)