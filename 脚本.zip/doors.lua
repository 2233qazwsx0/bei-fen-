-- Gui to Lua
-- Version: 3.6

-- Instances:

local ScreenGui = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local zhmmFrame = Instance.new("Frame")
local UICorner = Instance.new("UICorner")
local TextLabel = Instance.new("TextLabel")
local TextLabel_2 = Instance.new("TextLabel")
local zh = Instance.new("TextBox")
local mm = Instance.new("TextBox")
local dl = Instance.new("TextButton")
local UICorner_2 = Instance.new("UICorner")
local UICorner_3 = Instance.new("UICorner")

-- Properties:

ScreenGui.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")
ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

Frame.Parent = ScreenGui
Frame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Frame.BackgroundTransparency = 0.500
Frame.BorderColor3 = Color3.fromRGB(0, 0, 0)
Frame.BorderSizePixel = 0
Frame.Active = true
Frame.Draggable = true
Frame.Position = UDim2.new(0.2, 0, 0, 0)
Frame.Size = UDim2.new(0, 457, 0, 313)

zhmmFrame.Name = "zhmmFrame"
zhmmFrame.Parent = Frame
zhmmFrame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
zhmmFrame.BackgroundTransparency = 0.400
zhmmFrame.BorderColor3 = Color3.fromRGB(0, 0, 0)
zhmmFrame.BorderSizePixel = 0
zhmmFrame.Position = UDim2.new(0.113785557, 0, 0.115015976, 0)
zhmmFrame.Size = UDim2.new(0, 363, 0, 149)

UICorner.Parent = zhmmFrame

TextLabel.Parent = zhmmFrame
TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel.BackgroundTransparency = 1.000
TextLabel.BorderColor3 = Color3.fromRGB(0, 0, 0)
TextLabel.BorderSizePixel = 0
TextLabel.Size = UDim2.new(0, 101, 0, 54)
TextLabel.Font = Enum.Font.SourceSans
TextLabel.Text = "账号："
TextLabel.TextColor3 = Color3.fromRGB(0, 0, 0)
TextLabel.TextSize = 26.000

TextLabel_2.Parent = zhmmFrame
TextLabel_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel_2.BackgroundTransparency = 1.000
TextLabel_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
TextLabel_2.BorderSizePixel = 0
TextLabel_2.Position = UDim2.new(0, 0, 0.503355682, 0)
TextLabel_2.Size = UDim2.new(0, 101, 0, 54)
TextLabel_2.Font = Enum.Font.SourceSans
TextLabel_2.Text = "密码："
TextLabel_2.TextColor3 = Color3.fromRGB(0, 0, 0)
TextLabel_2.TextSize = 26.000

zh.Name = "zh"
zh.Parent = zhmmFrame
zh.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
zh.BackgroundTransparency = 1.000
zh.BorderColor3 = Color3.fromRGB(0, 0, 0)
zh.BorderSizePixel = 0
zh.Position = UDim2.new(0.195592284, 0, 0.0268456377, 0)
zh.Size = UDim2.new(0, 292, 0, 50)
zh.Font = Enum.Font.SourceSans
zh.Text = ""
zh.TextColor3 = Color3.fromRGB(0, 0, 0)
zh.TextScaled = true
zh.TextSize = 26.000
zh.TextWrapped = true

mm.Name = "mm"
mm.Parent = zhmmFrame
mm.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
mm.BackgroundTransparency = 1.000
mm.BorderColor3 = Color3.fromRGB(0, 0, 0)
mm.BorderSizePixel = 0
mm.Position = UDim2.new(0.214876026, 0, 0.503355682, 0)
mm.Size = UDim2.new(0, 275, 0, 54)
mm.Font = Enum.Font.SourceSans
mm.Text = ""
mm.TextColor3 = Color3.fromRGB(0, 0, 0)
mm.TextScaled = true
mm.TextSize = 26.000
mm.TextWrapped = true

dl.Name = "dl"
dl.Parent = Frame
dl.BackgroundColor3 = Color3.fromRGB(102, 51, 255)
dl.BorderColor3 = Color3.fromRGB(0, 0, 0)
dl.BorderSizePixel = 0
dl.Position = UDim2.new(0.0634573326, 0, 0.757188499, 0)
dl.Size = UDim2.new(0, 409, 0, 57)
dl.Font = Enum.Font.SourceSans
dl.Text = "登     录"
dl.TextColor3 = Color3.fromRGB(0, 0, 0)
dl.TextSize = 70.000

UICorner_2.Parent = dl

UICorner_3.Parent = Frame

-- Scripts:

local function VBMNV_fake_script() -- ScreenGui.LocalScript 
	local script = Instance.new('LocalScript', ScreenGui)

	
	--
	local REN_ok = script.Parent.Frame.dl
	REN_ok.MouseButton1Click:Connect(function()
		local REN_zhanghao = script.Parent.Frame.zhmmFrame.zh.Text
		local REN_mima = script.Parent.Frame.zhmmFrame.mm.Text
		if  #REN_zhanghao <= 10 and #REN_zhanghao >= 5 and #REN_mima >= 1 then
			if #REN_zhanghao <= 10 and #REN_zhanghao >= 5 then
			local a = game:HttpGet("http://shuixian.ltd/main/api/user/login.php?admin=397510573&user="..REN_zhanghao.."&password="..REN_mima)
			    			local CoreGui = game:GetService("StarterGui")
			CoreGui:SetCore("SendNotification", {
				Title = "忍脚本",
				Text = ""..a,
				Duration = 5,
			})
			end
		else
			local CoreGui = game:GetService("StarterGui")
			CoreGui:SetCore("SendNotification", {
				Title = "忍脚本",
				Text = "账号密码过短",
				Duration = 5,
			})
	    end
	end)
	--]]
	
	
	
end
coroutine.wrap(VBMNV_fake_script)()
