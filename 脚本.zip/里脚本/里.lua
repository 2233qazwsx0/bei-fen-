--[[

░░░█▄▒▄█░▄▀▄░▄▀▀░█▄█▒▄▀▄░░░█▄█░█▒█░██▄
▒░░█▒▀▒█░▀▄▀░▀▄▄▒█▒█░█▀█▒░▒█▒█░▀▄█▒█▄█

Intro made by N4ri. Coco Hub Edit By AkilBlox14, Plarizastefan And ChocoMochalovescofe. AKA The Lerk Team!


]]--

local CCOpeningScreen = Instance.new("ScreenGui")
local MainFrame = Instance.new("Frame")
local CocoLogo = Instance.new("ImageLabel")
local T1 = Instance.new("TextLabel")
local T2 = Instance.new("TextLabel")
local T3 = Instance.new("TextLabel")
local LoadBar = Instance.new("Frame")

CCOpeningScreen.Name = "CCOpeningScreen"
CCOpeningScreen.Parent = game.CoreGui
CCOpeningScreen.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

MainFrame.Name = "MainFrame"
MainFrame.Parent = CCOpeningScreen
MainFrame.Active = true
MainFrame.AnchorPoint = Vector2.new(0.5, 0.5)
MainFrame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
MainFrame.BorderSizePixel = 0
MainFrame.ClipsDescendants = true
MainFrame.Position = UDim2.new(0.5, 0, 0.5, 0)
MainFrame.Selectable = true
MainFrame.Size = UDim2.new(0, 0, 0, 158)

CocoLogo.Name = "CocoLogo"
CocoLogo.Parent = MainFrame
CocoLogo.AnchorPoint = Vector2.new(0.5, 0.5)
CocoLogo.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
CocoLogo.BackgroundTransparency = 1.000
CocoLogo.BorderSizePixel = 0
CocoLogo.ClipsDescendants = true
CocoLogo.Position = UDim2.new(0.255176783, 0, 0.49999997, 0)
CocoLogo.Size = UDim2.new(0, 86, 0, 86)
CocoLogo.Image = "hhttps://create.roblox.com/store/asset/132872684918876/Camera1729176562624avif"

T1.Name = "T1"
T1.Parent = MainFrame
T1.AnchorPoint = Vector2.new(0.5, 0.5)
T1.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
T1.BackgroundTransparency = 1.000
T1.BorderSizePixel = 0
T1.Position = UDim2.new(0.646776021, 0, 0.407925308, 0)
T1.Size = UDim2.new(0, 144, 0, 13)
T1.Font = Enum.Font.Gotham
T1.Text = "欢迎使用"
T1.TextColor3 = Color3.fromRGB(255, 255, 255)
T1.TextScaled = true
T1.TextSize = 14.000
T1.TextWrapped = true
T1.TextXAlignment = Enum.TextXAlignment.Left

T2.Name = "T2"
T2.Parent = MainFrame
T2.AnchorPoint = Vector2.new(0.5, 0.5)
T2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
T2.BackgroundTransparency = 1.000
T2.BorderSizePixel = 0
T2.Position = UDim2.new(0.646776021, 0, 0.538823366, 0)
T2.Size = UDim2.new(0, 144, 0, 28)
T2.Font = Enum.Font.GothamBold
T2.Text = "里脚本"
T2.TextColor3 = Color3.fromRGB(255, 255, 255)
T2.TextScaled = true
T2.TextSize = 14.000
T2.TextWrapped = true
T2.TextXAlignment = Enum.TextXAlignment.Left

T3.Name = "T3"
T3.Parent = MainFrame
T3.AnchorPoint = Vector2.new(0.5, 0.5)
T3.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
T3.BackgroundTransparency = 1.000
T3.BorderSizePixel = 0
T3.Position = UDim2.new(0.5, 0, 0.885999978, 0)
T3.Size = UDim2.new(1, 0, 0, 10)
T3.Font = Enum.Font.Gotham
T3.Text = ""
T3.TextColor3 = Color3.fromRGB(255, 255, 255)
T3.TextScaled = true
T3.TextSize = 14.000
T3.TextWrapped = true

LoadBar.Name = "LoadBar"
LoadBar.Parent = MainFrame
LoadBar.Active = true
LoadBar.AnchorPoint = Vector2.new(0, 0.5)
LoadBar.BackgroundColor3 = Color3.fromRGB(60, 60, 60)
LoadBar.BorderSizePixel = 0
LoadBar.ClipsDescendants = true
LoadBar.Position = UDim2.new(0, 0, 0.977999985, 0)
LoadBar.Selectable = true
LoadBar.Size = UDim2.new(0, 0, 0, 7)

-- Scripts:

local function MNQEF_fake_script()
	local script = Instance.new('LocalScript', MainFrame)

	wait(1)
	script.Parent:TweenSize(UDim2.new(0,310,0,158), "Out", "Quad", 0.5, true)
	wait(1)
	script.Parent.LoadBar:TweenSize(UDim2.new(0.1,0,0,7), "Out", "Quad", 0.5, true)
	script.Parent.T3.Text = "加载UI中"
	wait(1)
	script.Parent.LoadBar:TweenSize(UDim2.new(0.50,0,0,7), "Out", "Quad", 0.5, true)
	script.Parent.T3.Text = "加载功能中"
	wait(1)
	script.Parent.LoadBar:TweenSize(UDim2.new(0.50,0,0,7), "Out", "Quad", 0.5, true)
	script.Parent.T3.Text = "加载bug中"
	wait(1)
	script.Parent.LoadBar:TweenSize(UDim2.new(1,0,0,7), "Out", "Quad", 0.5, true)
	script.Parent.T3.Text = "加载完成!"
	wait(1.5)
	script.Parent:TweenSize(UDim2.new(0,0,0,158), "Out", "Quad", 0.5, true)
	wait(0.5)
    local OrionLib = loadstring(game:HttpGet("https://pastebin.com/raw/yDVWkjx6"))()--ui启动库


local Window = OrionLib:MakeWindow({Name = "里·脚本", HidePremium = false, SaveConfig = true,IntroText = "里.脚本", ConfigFolder = "好闲"})
OrionLib:MakeNotification({
  Name = "密码正确，欢迎使用,作者QQ:2337018045",
  Content = "当前游戏ID为:" .. game.GameId .. ".",
  Image = "rbxassetid://7734068321",
  Time = 10
})
OrionLib:MakeNotification({
	Name = "里脚本",
	Content = "欢迎使用里脚本",
	Image = "rbxassetid://13708514549",
	Time = 1
})

wait(1)

OrionLib:MakeNotification({
	Name = "里脚本",
	Content = "该脚本为哪里都是你制作",
	Image = "rbxassetid://13708514549",
	Time = 1
})

wait(1)

OrionLib:MakeNotification({
	Name = "里脚本",
	Content = "作者第一次做",
	Image = "rbxassetid://13708514549",
	Time = 1
})

wait(1)

OrionLib:MakeNotification({
	Name = "里脚本",
	Content = "有卡密，希望你能验证对",
	Image = "rbxassetid://13708514549",
	Time = 1
})

wait(1)

OrionLib:MakeNotification({
	Name = "里脚本",
	Content = "欢迎使用里脚本",
	Image = "rbxassetid://13708514549",
	Time = 30
})

local Tab = Window:MakeTab({    Name = "玩家",	Icon = "rbxassetid://4483345998",	PremiumOnly = false})
Tab:AddButton({	Name = "无限跳",	Callback = function()
loadstring(game:HttpGet("https://pastebin.com/raw/V5PQy3y0", true))()
end
}) 
Tab:AddButton({
	Name = "飞行",
	Callback = function()
      	loadstring(game:HttpGet("https://pastebin.com/raw/U27yQRxS"))()
  	end    
})
Tab:AddTextbox({
	Name = "移动速度",
	Default = "",
	TextDisappear = true,
	Callback = function(Value)
		game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = Value
	end	 
})
Tab:AddTextbox({
	Name = "跳跃高度",
	Default = "",
	TextDisappear = true,
	Callback = function(Value)
		game.Players.LocalPlayer.Character.Humanoid.JumpPower = Value
	end	 
})
Tab:AddTextbox({
	Name = "重力设置",
	Default = "",
	TextDisappear = true,
	Callback = function(Value)
		game.Workspace.Gravity = Value
	end
})
Tab:AddButton({
	Name = "人物无敌",
	Callback = function()
     loadstring(game:HttpGet('https://pastebin.com/raw/H3RLCWWZ'))()
	end    
})
Tab:AddButton({
	Name = "变成蛇",
	Callback = function()
loadstring(game:HttpGet(('https://pastefy.ga/tWBTcE4R/raw'),true))()
	end
})
Tab:AddButton({
	Name = "踏空行走",
	Callback = function()
loadstring(game:HttpGet('https://raw.githubusercontent.com/GhostPlayer352/Test4/main/Float'))()
	end
})
Tab:AddButton({
	Name = "爬墙",
	Callback = function()
loadstring(game:HttpGet("https://pastebin.com/raw/zXk4Rq2r"))()
end
})
Tab:AddButton({
	Name = "防止掉线（反挂机）",
	Callback = function()
	print("Anti Afk On")
		local vu = game:GetService("VirtualUser")
		game:GetService("Players").LocalPlayer.Idled:connect(function()
		   vu:Button2Down(Vector2.new(0,0),workspace.CurrentCamera.CFrame)
		   wait(1)
		   vu:Button2Up(Vector2.new(0,0),workspace.CurrentCamera.CFrame)
		end)
  	end
})
Tab:AddButton({
	Name = "甩飞别人",
	Callback = function()
     loadstring(game:HttpGet("https://pastebin.com/raw/GnvPVBEi"))()
  	end    
})
local Tab = Window:MakeTab({
	Name = "游戏脚本",
	Icon = "rbxassetid://13519683179",
	PremiumOnly = false
})
Tab:AddButton({
	Name = "极速",
	Callback = function()
      	loadstring(game:HttpGet('\104\116\116\112\115\58\47\47\114\97\119\46\103\105\116\104\117\98\117\115\101\114\99\111\110\116\101\110\116\46\99\111\109\47\98\111\121\115\99\112\47\98\101\116\97\47\109\97\105\110\47\37\69\57\37\56\48\37\57\70\37\69\53\37\66\65\37\65\54\37\69\55\37\56\50\37\66\56\37\69\56\37\66\53\37\66\55\46\108\117\97'))()
  	end
})
Tab:AddButton({
  Name = "力量",
  Callback = function()
    loadstring(game:HttpGet('https://raw.githubusercontent.com/BoaHacker/ROBLOX/main/cheat', true))()
  end
})
Tab:AddButton({
  Name = "忍者",
  Callback = function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/why-png/scriptstuffz/master/ninjaleg2", true))()
  end
})
Tab:AddButton({
	Name = "脚本中心",
	Callback = function()
  loadstring(game:HttpGet("https://pastebin.com/raw/De4aYHDY"))()
  	end
})
Tab:AddButton({
	Name = "自然灾害",
	Callback = function()
      	loadstring(game:HttpGet('https://raw.githubusercontent.com/9NLK7/93qjoadnlaknwldk/main/main'))()
  	end
})
Tab:AddButton({
    Name="彩虹朋友1",
    Callback=function()
loadstring(game:HttpGet("https://raw.githubusercontent.com/JNHHGaming/Rainbow-Friends/main/Rainbow%20Friends"))()
    end
})
Tab:AddButton({
	Name = "星期五",
	Callback = function()
      	loadstring(game:HttpGet("https://raw.githubusercontent.com/wally-rblx/funky-friday-autoplay/main/main.lua",true))()
  	end
})

Tab:AddButton({
	Name = "evade",
	Callback = function()
      	loadstring(game:HttpGet("https://raw.githubusercontent.com/GamingScripter/Darkrai-X/main/Games/Evade"))()
  	end
})

Tab:AddButton({
	Name = "监狱人生",
	Callback = function()
     loadstring(game:HttpGet("https://pastebin.com/raw/mHfK0Xk4", true))()
  	end
})
Tab:AddButton({
	Name = "兵工厂",
	Callback = function()
     loadstring(game:HttpGet(('https://raw.githubusercontent.com/RandomAdamYT/DarkHub/master/Init'), true))()
  	end
})
Tab:AddButton({
	Name = "USA卡密:USA AER",
	Callback = function()
  getgenv().USA="作者莫羽免费请勿倒卖"loadstring(game:HttpGet("https://raw.githubusercontent.com/boyscp/beta/main/USA.lua"))()
  	end
})
local Tab = Window:MakeTab({    Name = "各大脚本",    Icon = "rbxassetid://4483345998",    PremiumOnly = false})
Tab:AddButton({	Name = "云脚本",	Callback = function()
loadstring(game:HttpGet("https://raw.githubusercontent.com/XiaoYunCN/LOL/main/%E4%BA%91%E8%84%9A%E6%9C%ACCloud%20script.lua", true))()  	
end
})
Tab:AddButton({    Name="XC卡密:w",    Callback=function()
        getgenv().XC="作者XC"loadstring(game:HttpGet("https://pastebin.com/raw/PAFzYx0F"))()    
end
})
Tab:AddButton({    
Name="坑钱龙脚本",    
Callback=function() 
       getgenv().long = "龙脚本，加载时间长请耐心"loadstring("\108\111\97\100\115\116\114\105\110\103\40\103\97\109\101\58\72\116\116\112\71\101\116\40\34\104\116\116\112\115\58\47\47\114\97\119\46\103\105\116\104\117\98\117\115\101\114\99\111\110\116\101\110\116\46\99\111\109\47\108\121\121\97\105\110\105\47\108\111\110\47\109\97\105\110\47\108\105\115\119\109\34\41\41\40\41")()    
end
})
Tab:AddButton({    Name="USA",    
Callback=function()        getgenv().USA="作者USA免费请勿倒卖"
loadstring(game:HttpGet("https://raw.githubusercontent.com/boyscp/beta/main/USA.lua"))()    
end
})
Tab:AddButton({	
Name = "青脚本——支持很多游戏",	
Callback = function()
loadstring(game:HttpGet('https://raw.githubusercontent.com/kkaaccnnbb/money/main/fix'))()    
end
})
Tab:AddButton({	
Name = "冰脚本",	
Callback = function()
loadstring(game:HttpGet("https://pastebin.com/raw/GR4ChWKv"))()    
end
})
Tab:AddButton({	
Name = "剑客v3_roblox加入群组剑客才可用",	
Callback = function()
jianke_V3 = "作者_初夏"jianke = "剑客QQ群347724155"loadstring(game:HttpGet(('https://raw.githubusercontent.com/jiankeQWQ/jiankeV3/main/jianke_V3')))()    
end
})
Tab:AddButton({	Name = "鲨脚本",	Callback = function()
loadstring(game:HttpGet("https://raw.githubusercontent.com/sharksharksharkshark/shark-shark-shark-shark-shark/main/shark-scriptlollol.txt",true))()    
end
})
Tab:AddButton({	Name = "水下世界支持很多游戏白名单已被破除",	
Callback = function()
loadstring(game:HttpGet(('https://raw.githubusercontent.com/jiankeQWQ/Fish/main/sx')))()    
end
})
Tab:AddButton({	Name = "怀脚本",	Callback = function()
loadstring(game:HttpGet("https://raw.githubusercontent.com/zuohongjian/bjb/main/bjb"))()    
end
})
Tab:AddButton({	
Name = "EZ Hub 150+",	Callback = function()
loadstring(game:HttpGet(('https://raw.githubusercontent.com/debug420/Ez-Industries-Launcher-Data/master/Launcher.lua'),true))()    
end
})
Tab:AddButton({	
Name = "客户端中心",	Callback = function()
loadstring(game:HttpGet("https://raw.githubusercontent.com/ObviouslyOrchi/Moonlight_Client.lua/main/Universal",true))()    
end
})
Tab:AddButton({	Name = "作弊中心",	Callback = function()loadstring(game:HttpGet("https://raw.githubusercontent.com/mrgunz/UnnamedCheat/main/Loader"))();    
end
})
Tab:AddButton({	Name = "阿斯顿中心",	Callback = function()
loadstring(game:HttpGet(('https://raw.githubusercontent.com/rblxscriptsnet/unfair/main/rblxhub.lua'),true))()    
end
})

Tab:AddButton({	Name = "脚本中心外网",	Callback = function()
loadstring(game:HttpGet("https://raw.githubusercontent.com/TakeModzz/Games-Hub-Script/main/Games%20Hub%20(Always%20updated)"))()    
end
})
Tab:AddButton({	Name = "Every day中心",	Callback = function()
loadstring(game:HttpGet("https://raw.githubusercontent.com/KATERGaming/Roblox/main/KaterHub.Lua"))()    
end
})
Tab:AddButton({	Name = "移动中心",	Callback = function()loadstring(game:HttpGetAsync("https://shz.al/~mobile-hub-v2"))()    
end
})
Tab:AddButton({	Name = "脚本中心另一版本",	Callback = function()
loadstring(game:HttpGet("https://raw.githubusercontent.com/fgasfga/SCRIPT-HUB/main/Hello.lua", true))()    
end
})
Tab:AddButton({	Name = "140+中心",	Callback = function()
loadstring(game:HttpGet('https://raw.githubusercontent.com/1201for/V.G-Hub/main/V.Ghub'))()    
end
})
Tab:AddButton({	Name = "地岩",	Callback = function()loadstring("\108\111\97\100\115\116\114\105\110\103\40\103\97\109\101\58\72\116\116\112\71\101\116\40\34\104\116\116\112\115\58\47\47\114\97\119\46\103\105\116\104\117\98\117\115\101\114\99\111\110\116\101\110\116\46\99\111\109\47\98\98\97\109\120\98\98\97\109\120\98\98\97\109\120\47\99\111\100\101\115\112\97\99\101\115\45\98\108\97\110\107\47\109\97\105\110\47\37\69\55\37\57\57\37\66\68\34\41\41\40\41")()	
end
})
Tab:AddButton({	
Name = "dx旧版本",	
Callback = function()
loadstring(game:HttpGet("https://raw.githubusercontent.com/DXuwu/test-lol/main/YO.lua"))()
end
})
Tab:AddButton({	
Name = "脚本中心",	Callback = function()
loadstring(game:HttpGet("\104\116\116\112\115\58\47\47\112\97\115\116\101\98\105\110\46\99\111\109\47\114\97\119\47\103\101\109\120\72\119\65\49"))()end
})
local Tab = Window:MakeTab({
	Name = "造船寻宝",
	Icon = "rbxassetid://13519683179",
	PremiumOnly = false
})
local Section = Tab:AddSection({
	Name = "付费功能"
})
Tab:AddButton({
	Name = "自动刷金条",
	Callback = function()
	loadstring(game:HttpGet("https://pastebin.com/raw/Lyy77rnr",true))()
  	end
})
Tab:AddButton({
	Name = "工具包",
	Callback = function()
	loadstring(game:HttpGet("https://cdn.wearedevs.net/scripts/BTools.txt"))()	
  	end
})
Tab:AddButton({
	Name = "防止掉线（反挂机）",
	Callback = function()
	print("Anti Afk On")
		local vu = game:GetService("VirtualUser")
		game:GetService("Players").LocalPlayer.Idled:connect(function()
		   vu:Button2Down(Vector2.new(0,0),workspace.CurrentCamera.CFrame)
		   wait(1)
		   vu:Button2Up(Vector2.new(0,0),workspace.CurrentCamera.CFrame)
		end)
  	end
})
local Tab = Window:MakeTab({
	Name = "监狱人生",
	Icon = "rbxassetid://13519683179",
	PremiumOnly = false
})
Tab:AddButton({
	Name = "PRISONWARE V1.3",
	Callback = function()
     loadstring(game:HttpGet("https://raw.githubusercontent.com/Denverrz/scripts/master/PRISONWARE_v1.3.txt"))();
  	end    
})
Tab:AddButton({
	Name = "PRISONWARE V1.5",
	Callback = function()
	loadstring(game:HttpGet(('https://raw.githubusercontent.com/h17s3/TIGERADMIN/main/TIGERADMINSCRIPTFREE'),true))()
	end
})
Tab:AddButton({
	Name = "警卫室",
	Callback = function()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(847.7261352539062, 98.95999908447266, 2267.387451171875)
  	end
})
Tab:AddButton({
	Name = "监狱室内",
	Callback = function()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(919.2575073242188, 98.95999908447266, 2379.74169921875)
  	end
})
Tab:AddButton({
	Name = "罪犯复活点",
	Callback = function()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-937.5891723632812, 93.09876251220703, 2063.031982421875)
  	end
})
Tab:AddButton({
	Name = "监狱室外",
	Callback = function()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(760.6033325195312, 96.96992492675781, 2475.405029296875)
  	end
})
local Tab = Window:MakeTab({
	Name = "鲨口求生2",
	Icon = "rbxassetid://13519683179",
	PremiumOnly = false
})
Tab:AddDropdown({
	Name = "免费船只",
	Default = "1",
	Options = {"DuckyBoatBeta", "DuckyBoat", "BlueCanopyMotorboat", "BlueWoodenMotorboat", "UnicornBoat", "Jetski", "RedMarlin", "Sloop", "TugBoat", "SmallDinghyMotorboat", "JetskiDonut", "Marlin", "TubeBoat", "FishingBoat", "VikingShip", "SmallWoodenSailboat", "RedCanopyMotorboat", "Catamaran", "CombatBoat", "TourBoat", "Duckmarine", "PartyBoat", "MilitarySubmarine",  "GingerbreadSteamBoat", "Sleigh2022", "Snowmobile", "CruiseShip"},
	Callback = function(Value)
local ohString1 = (Value)

game:GetService("ReplicatedStorage").EventsFolder.BoatSelection.UpdateHostBoat:FireServer(ohString1)
	end    
})
Tab:AddButton({
	Name = "自动杀鲨鱼",
	Callback = function()
     loadstring(game:HttpGet("https://raw.githubusercontent.com/Sw1ndlerScripts/RobloxScripts/main/Misc%20Scripts/sharkbite2.lua",true))()
  	end    
})
local other = Window:MakeTab({
    Name = "力量传奇",
    Icon = "rbxassetid://13519683179",
    PremiumOnly = false
})
local Section = other:AddSection({
	Name = "↓用电脑↓"
})
lother:AddButton({
	Name = "电脑",
	Callback = function()
      	loadstring(game:HttpGet("https://raw.githubusercontent.com/advxzivhsjjdhxhsidifvsh/mobkeyboard/main/main.txt", true))()
  	end
})
local Section = other:AddSection({
	Name = "↓开始↓"
})
lother:AddButton({
	Name = "力量传奇修改",
	Callback = function()
      	loadstring(game:HttpGet('https://raw.githubusercontent.com/jynzl/main/main/Musclas%20Legenos.lua'))()
  	end
})
lother:AddButton({
	Name = "力量传奇",
	Callback = function()
      	loadstring(game:HttpGet("https://raw.githubusercontent.com/1201for/littlegui/main/MuscleLegends"))()
  	end
})
lother:AddButton({
	Name = "极速传奇",
	Callback = function()
      	loadstring(game:HttpGet("\104\116\116\112\115\58\47\47\114\97\119\46\103\105\116\104\117\98\117\115\101\114\99\111\110\116\101\110\116\46\99\111\109\47\98\111\121\115\99\112\47\98\101\116\97\47\109\97\105\110\47\37\69\57\37\56\48\37\57\70\37\69\53\37\66\65\37\65\54\37\69\55\37\56\50\37\66\56\37\69\56\37\66\53\37\66\55\46\108\117\97"))()
  	end
})
local Tab = Window:MakeTab({
	Name = "通用",
	Icon = "rbxassetid://13519683179",
	PremiumOnly = false
})
Tab:AddParagraph("您的用户名:"," "..game.Players.LocalPlayer.Name.."")
Tab:AddParagraph("您的注入器:"," "..identifyexecutor().."")
Tab:AddParagraph("您当前服务器的lD"," "..game.GameId.."")

Tab:AddToggle({
	Name = "夜视",
	Default = false,
	Callback = function(Value)
		if Value then
		    game.Lighting.Ambient = Color3.new(1, 1, 1)
		else
		    game.Lighting.Ambient = Color3.new(0, 0, 0)
		end
	end
})
Tab:AddButton({
	Name = "光影",
	Callback = function()
      	loadstring(game:HttpGet("https://raw.githubusercontent.com/MZEEN2424/Graphics/main/Graphics.xml"))()
  	end
})
Tab:AddButton({
	Name = "飞车",
	Callback = function()
loadstring(game:HttpGet("https://pastebin.com/raw/MHE1cbWF"))()
	end
})
Tab:AddButton({
  Name = "最强透视",
  Callback = function ()
    loadstring(game:HttpGet("https://pastebin.com/raw/uw2P2fbY"))()
  end
})
Tab:AddToggle({
	Name = "穿墙",
	Default = false,
	Callback = function(Value)
		if Value then
		    Noclip = true
		    Stepped = game.RunService.Stepped:Connect(function()
			    if Noclip == true then
				    for a, b in pairs(game.Workspace:GetChildren()) do
                        if b.Name == game.Players.LocalPlayer.Name then
                            for i, v in pairs(game.Workspace[game.Players.LocalPlayer.Name]:GetChildren()) do
                                if v:IsA("BasePart") then
                                    v.CanCollide = false
                                end
                            end
                        end
                    end
			    else
				    Stepped:Disconnect()
			    end
		    end)
	    else
		    Noclip = false
	    end
	end
})

Tab:AddButton({
	Name = "转起来",
	Callback = function()
      	loadstring(game:HttpGet('https://pastebin.com/raw/r97d7dS0', true))()
  	end
})
Tab:AddButton({
	Name = "隐身弹人",
	Callback = function()
     loadstring(game:HttpGet("https://pastebin.com/raw/kenX0BHc"))()
  	end
})
Tab:AddButton({
	Name = "电脑键盘",
	Callback = function()    	loadstring(game:HttpGet("https://raw.githubusercontent.com/advxzivhsjjdhxhsidifvsh/mobkeyboard/main/main.txt", true))()
  	end
})
Tab:AddButton({
	Name = "鼠标（手机非常不建议用）",
	Callback = function()
loadstring(game:HttpGet(('https://pastefy.ga/V75mqzaz/raw'),true))()
	end
})
Tab:AddButton({
	Name = "隐身",
	Callback = function()
      	loadstring(game:HttpGet("https://gist.githubusercontent.com/skid123skidlol/cd0d2dce51b3f20ad1aac941da06a1a1/raw/f58b98cce7d51e53ade94e7bb460e4f24fb7e0ff/%257BFE%257D%2520Invisible%2520Tool%2520(can%2520hold%2520tools)",true))()
  	end
})
Tab:AddButton({
	Name = "替身",
	Callback = function()
      	loadstring(game:HttpGet(('https://raw.githubusercontent.com/SkrillexMe/SkrillexLoader/main/SkrillexLoadMain')))()
  	end
})
Tab:AddButton({
	Name = "跟踪玩家",
	Callback = function()
      	loadstring(game:HttpGet("https://pastebin.com/raw/F9PNLcXk"))()
  	end
})
Tab:AddButton({
	Name = "吸取全部玩家",
	Callback = function()
     loadstring(game:HttpGet('https://pastebin.com/raw/hQSBGsw2'))()
  	end    
})
Tab:AddButton({
	Name = "伪名说话",
	Callback = function()
loadstring(game:HttpGet(('https://pastefy.ga/zCFEwaYq/raw'),true))()
	end 
})
local Tab = Window:MakeTab({
	Name = "游戏脚本",
	Icon = "rbxassetid://13519683179",
	PremiumOnly = false
})
Tab:AddButton({
	Name = "极速",
	Callback = function()
      	loadstring(game:HttpGet('\104\116\116\112\115\58\47\47\114\97\119\46\103\105\116\104\117\98\117\115\101\114\99\111\110\116\101\110\116\46\99\111\109\47\98\111\121\115\99\112\47\98\101\116\97\47\109\97\105\110\47\37\69\57\37\56\48\37\57\70\37\69\53\37\66\65\37\65\54\37\69\55\37\56\50\37\66\56\37\69\56\37\66\53\37\66\55\46\108\117\97'))()
  	end
})
Tab:AddButton({
  Name = "力量",
  Callback = function()
    loadstring(game:HttpGet('https://raw.githubusercontent.com/BoaHacker/ROBLOX/main/cheat', true))()
  end
})
Tab:AddButton({
  Name = "忍者",
  Callback = function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/why-png/scriptstuffz/master/ninjaleg2", true))()
  end
})
Tab:AddButton({
	Name = "脚本中心",
	Callback = function()
  loadstring(game:HttpGet("https://pastebin.com/raw/De4aYHDY"))()
  	end
})
Tab:AddButton({
	Name = "自然灾害",
	Callback = function()
      	loadstring(game:HttpGet('https://raw.githubusercontent.com/9NLK7/93qjoadnlaknwldk/main/main'))()
  	end
})
Tab:AddButton({
    Name="彩虹朋友1",
    Callback=function()
loadstring(game:HttpGet("https://raw.githubusercontent.com/JNHHGaming/Rainbow-Friends/main/Rainbow%20Friends"))()
    end
})
Tab:AddButton({
	Name = "星期五",
	Callback = function()
      	loadstring(game:HttpGet("https://raw.githubusercontent.com/wally-rblx/funky-friday-autoplay/main/main.lua",true))()
  	end
})

Tab:AddButton({
	Name = "evade",
	Callback = function()
      	loadstring(game:HttpGet("https://raw.githubusercontent.com/GamingScripter/Darkrai-X/main/Games/Evade"))()
  	end
})

Tab:AddButton({
	Name = "监狱人生",
	Callback = function()
     loadstring(game:HttpGet("https://pastebin.com/raw/mHfK0Xk4", true))()
  	end
})
Tab:AddButton({
	Name = "兵工厂",
	Callback = function()
     loadstring(game:HttpGet(('https://raw.githubusercontent.com/RandomAdamYT/DarkHub/master/Init'), true))()
  	end
})
Tab:AddButton({
	Name = "USA卡密:USA AER",
	Callback = function()
  getgenv().USA="作者莫羽免费请勿倒卖"loadstring(game:HttpGet("https://raw.githubusercontent.com/boyscp/beta/main/USA.lua"))()
  	end
})
local Tab = Window:MakeTab({
	Name = "doors",
	Icon = "rbxassetid://13519683179",
	PremiumOnly = false
})
Tab:AddButton({
  Name = "DOORS低回拉穿墙",
  Callback = function()
    loadstring(game:HttpGet("https://github.com/DXuwu/OK/raw/main/clip"))()
  end
})

Tab:AddButton({
  Name = "exp",
  Callback = function()
    loadstring(game:HttpGet('https://raw.githubusercontent.com/zoophiliaphobic/POOPDOORS/main/script.lua'))()
  end
})
Tab:AddButton({
  Name = "变身",
  Callback = function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/ChronoAccelerator/Public-Scripts/main/Morphing/MorphScript.lua"))();
  end
})
Tab:AddButton({
  Name = "磁铁",
  Callback = function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/MrNeRD0/Doors-Hack/main/MagnetByNerd.lua"))()
  end
})
Tab:AddButton({
	Name = "神圣炸弹",
	    Callback = function()
loadstring(game:HttpGet("https://raw.githubusercontent.com/MrNeRD0/Doors-Hack/main/HolyGrenadeByNerd.lua"))()
  end
})
Tab:AddButton({
	Name = "激光枪",
	Callback = function()
loadstring(game:HttpGet("https://raw.githubusercontent.com/K0t1n/Public/main/Laser%20Gun"))()
end
})
Tab:AddButton({
  Name = "剪刀",
  Callback = function()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/MrNeRD0/Doors-Hack/main/shears_done.lua"))()
  end
})
Tab:AddButton({
  Name = "骷髅钥匙",
  Callback = function ()
    local item = game:GetObjects("rbxassetid://11697889137")[1]item.Parent = game.Players.LocalPlayer.Backpack
  end
})
Tab:AddButton({
	Name = "紫色手电筒",
	Callback = function()
loadstring(game:HttpGet("https://raw.githubusercontent.com/K0t1n/Public/main/Purple%20Flashlight"))()
end
})  
Tab:AddButton({
	Name = "手电筒（没电会有bug）",
	Callback = function()
loadstring(game:HttpGet("https://raw.githubusercontent.com/K0t1n/Public/main/Normal%20Flashlight"))()
end
})      
Tab:AddButton({
  Name = "耶稣十字架",
  Callback = function ()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/cbhlyy/lyycbh/main/shizi2"))()
  end
})
Tab:AddButton({
  Name = "紫光十字架",
  Callback = function ()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/cbhlyy/lyycbh/main/shizi3"))()
  end
})
Tab:AddButton({
  Name = "万圣节十字架",
  Callback = function ()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/cbhlyy/lyycbh/main/shizi4"))()
  end
})
Tab:AddButton({
  Name = "Zepsyy十字架",
  Callback = function ()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/ZepsyyCodesLUA/Utilities/main/Crucifix"))()
  end
})
Tab:AddButton({
  Name = "普通十字架",
  Callback = function ()
    loadstring(game:HttpGet("https://raw.githubusercontent.com/cbhlyy/lyycbh/main/shizizhen"))()
  end
})
Tab:AddButton({
  Name = "老六十字架",
  Callback = function ()
    loadstring(game:HttpGet("https://pastebin.com/raw/W1AzELhb"))()
  end
}) 
local Tab = Window:MakeTab({
	Name = "鲨口求生(bushi",
	Icon = "rbxassetid://13519683179",
	PremiumOnly = false
})
Tab:AddButton({
  Name = "脚本",
  Callback = function()
    loadstring(game:HttpGet("https://pastebin.com/raw/YYVLbzVg", true))()
  end
})
Tab:AddButton({
	Name = "自动杀鲨鱼🦈(鲨鱼)",
	Callback = function()
     loadstring(game:HttpGet("https://raw.githubusercontent.com/Sw1ndlerScripts/RobloxScripts/main/Misc%20Scripts/sharkbite2.lua",true))()
  	end    
})
local Tab = Window:MakeTab({
	Name = "游戏脚本",
	Icon = "rbxassetid://13519683179",
	PremiumOnly = false
})
Tab:AddButton({
	Name = "操人脚本",
	Callback = function()
		loadstring(game:HttpGet('https://pastebin.com/raw/bzmhRgKL'))()
	end
})
Tab:AddButton({
	Name = "动感星期五",
	Callback = function()	
	loadstring(game:HttpGet('https://raw.githubusercontent.com/ShowerHead-FluxTeam/scripts/main/funky-friday-autoplay'))()
	end
})
Tab:AddButton({
	Name = "餐厅大亨2",
	Callback = function()
	loadstring(game:httpget("https://raw.githubusercontent.com/LabibKazi858/Scripts/main/Restaurant%20Tycoon%202", true))()
	end
})
Tab:AddButton({
	Name = "蜂群模拟器",
	Callback = function()
	loadstring(game:HttpGet("https://rahttps://rahttps://raw.githubusercontent.com/USA868/USA--/main/.github/%E5%B7%A5%E4%BD%9C%E6%B5%81%E7%A8%8B/1%E6%9D%96%E4%BA%BA%E4%BD%BF%E7%94%A8?token=GHSAT0AAAAAACB6LLQWA5JNQNNWTP47AOWSZCLYRTQ"))()
	end
})
Tab:AddButton({
	Name = "服务器模拟器",
	Callback = function()
	loadstring(game:HttpGet("https://pastebin.com/raw/1Kj71cJM"))();
		end
})
Tab:AddButton({
	Name = "苦力怕",
	Callback = function()
	loadstring(game:HttpGet("https://raw.githttps://raw.githubusercontent.com/USA868/USA--/main/%E8%8B%A6%E5%8A%9B%E6%80%95%E6%9D%80%E6%89%8B(ZERO%E6%B1%89%E5%8C%96)%20(1).txt?token=GHSAT0AAAAAACB6LLQWG2CFCYA27H5D33DSZCMVNZQ"))()
		end
})
Tab:AddButton({
	Name = "脚本搜索",
	Callback = function()
	loadstring(game:HttpGet("https://raw.githubusercontent.com/AZYsGithub/chillz-workshop/main/ScriptSearcher"))()
	end
})
Tab:AddButton({
	Name = "幸运战场",
	Callback = function()
	loadstring(game:HttpGet(('https://raw.githubusercontent.com/zeuise0002/SSSWWW222/main/README.md'),true))()
	end
})
Tab:AddButton({
	Name = "DX",
	Callback = function()
	loadstring(game:HttpGet("https://github.com/DocYogurt/lolololololololololololololollolololololololololololololollolololololololololololololollolololololol/raw/main/lolololololololololololololollolololololololololololololollolololololololololololololollolololololololololololololollolololololololololololololollolololololololololololololollolololololololololololololollolololololololololololololollolololololololololololololollolololololololololololololollolololololololololololololol.lua"))()
	end
})
Tab:AddButton({
	Name = "饥饿的艺术家",
	Callback = function()
	loadstring(game:HttpGet("https://raw.githubusercontent.com/SuperRegex/RobloxScripts/main/DrawingScript.lua"))()
	end
})
Tab:AddButton({
	Name = "监狱人生",
	Callback = function()
loadstring(game:HttpGet("https://raw.githubusercontent.com/Denverrz/scripts/master/PRISONWARE_v1.3.txt"))();
	end
})
Tab:AddButton({
	Name = "脚本F",
	Callback = function()		loadstring(game:HttpGet('loadstring(game:HttpGet("https://raw.githubusercontent.com/Wangzhehaoh/fly-away/main/how%20didb%20mOD"))()'))()
	end
})
Tab:AddButton({
	Name = "胭脂模拟器",
	Callback = function()
	loadstring(game:HttpGet("https://raw.githubusercontent.com/USA868/USA--/main/%E5%8C%97%E7%BA%A6%E8%84%82%E8%82%AA?token=GHSAT0AAAAAACB6LLQXW62E3GRGCTS3O4RCZCMUN2Q"))()
		end
})
Tab:AddButton({
	Name = "脚本中心1.5",
	Callback = function()		loadstring(game:HttpGet('\104\116\116\112\115\58\47\47\112\97\115\116\101\98\105\110\46\99\111\109\47\114\97\119\47\103\101\109\120\72\119\65\49"))()'))()
	end
})
Tab:AddButton({
	Name = "隐身（按E）",
	Callback = function()
		loadstring(game:HttpGet('http://pan.rlyun.asia/api/v3/file/get/15096/%E9%9A%90%E8%BA%AB?sign=e_W9VovlrlZFy_OwwmQSLn6POQ6FwtWXFvrb2lBaJq8%3D%3A0'))()
	end
})
Tab:AddButton({
	Name = "BOL",
	Callback = function()
	loadstring(game:HttpGet("https://github.com/ScriptKiddyQuinn/Blox-Hub-Version-1.3/blob/main/Blox%20Hub%20Version%201.3", true))()
	end
})
Tab:AddButton({
	Name = "音乐",
	Callback = function()		
loadstring(game:HttpGet("https://raw.githubusercontent.com/boyscp/beta/main/music.lua"))()
    end
})
Tab:AddButton({
	Name = "轰炸（封号风险）",
	Callback = function()		
loadstring(game:HttpGet("https://raw.githubusercontent.com/boyscp/scriscriptsc/main/%E8%BD%B0%E7%82%B8.lua"))()
    end
})
Tab:AddButton({
	Name = "回答或死亡",
	Callback = function()
	loadstring(game:HttpGet('https://raw.githubusercontent.com/jaeelin/S-Ware/main/S-WARE'))()
	end
})
Tab:AddButton({
	Name = "兵工厂",
	Callback = function()
		loadstring(game:HttpGet('http://pan.rlyun.asia/api/v3/file/get/15369/%E4%B9%92%E5%B7%A5%E5%8E%82?sign=pDWgMBQ_m8pjcTS9-o8N1zvCmYmc6LsQVjeDaypp0bw%3D%3A0'))()
	end
})
Tab:AddButton({
	Name = "鲨口求生",
	Callback = function()		
	loadstring(game:HttpGet("https://pastebin.com/raw/YYVLbzVg", true))()
	end
})
Tab:AddButton({
	Name = "变大变小",
	Callback = function()	
	loadstring(game:HttpGet("http://pan.rlyun.asia/api/v3/file/get/18187/%E5%8F%98%E5%A4%A7%E5%8F%98%E5%B0%8F?sign=nR9TjQacuB58vmwKApyTIaWJykPqbr3KNPusu_MqNbg%3D%3A0"))()
	end
})
Tab:AddButton({
	Name = "bf神龙",
	Callback = function()		
	loadstring(game:HttpGet("https://raw.githubusercontent.com/Kaizenofficiall/ZenHub/main/Loader", true))()
    end
})
Tab:AddButton({
	Name = "技能大战2卡密：lMXJsryGVIajsQrMJmaVde3MIUoHCa",
	Callback = function()
	loadstring(game:HttpGet("https://raw.githubusercontent.com/VxleLUA/Dynamic-Offical/main/System/GameChecker.lua"))()
	end
})
Tab:AddButton({
	Name = "军事大亨 查找干扰器",
	Callback = function()
	loadstring(game:HttpGet("https://oopshub.vercel.app/scripts/MT_event_Hacker.lua"))()
	end
})
Tab:AddButton({
	Name = "帝国中心（荐）",
	Callback = function()	
	loadstring(game:HttpGet("https://raw.githubusercontent.com/aerocontentdeliverynetwork/3456465f7453x447r76h86856233423645756354b/master/loader.lua"))()
	end
})
Tab:AddButton({
	Name = "evade新版",
	Callback = function()	
	loadstring(game:HttpGet("https://raw.githubusercontent.com/Wangzhehaoh/fly-away/main/---EF---fluxus%20debtsesgh%20%E6%AC%A2%E8%BF%8E%E6%9D%A5%E5%88%B0%E8%84%9A%E6%9C%ACEF%20%E6%B5%8B%E8%AF%95%E7%89%88"))()
		end
})
Tab:AddButton({
	Name = "派系防御大亨",
	Callback = function()
	game:GetService("ReplicatedStorage").PlayerMoneyUpdate[game:GetService("Players").LocalPlayer.Name]:FireServer(999999999)
	end
})
Tab:AddButton({
	Name = "军事大亨",
	Callback = function()
	loadstring(game:HttpGet("https://pastebin.com/raw/q94czk7E",true))()
	end
})
Tab:AddButton({
	Name = "通用ESP",
	Callback = function()
	loadstring(game:HttpGet('https://raw.githubusercontent.com/Lucasfin000/SpaceHub/main/UESP'))()
	end
})
Tab:AddButton({
	Name = "导弹模拟器",
	Callback = function()	
	loadstring(game:HttpGet('https://raw.githubusercontent.com/KodaLINEN/NukeSim/main/Main'))()
	end
})	
Tab:AddButton({
	Name = "矿车",
	Callback = function()
	loadstring(game:HttpGet("https://raw.githubusercontent.com/Holdmyhacks/scripts/main/scripts", true))()
	end
})
Tab:AddButton({
	Name = "通用脚本",
	Callback = function()
	loadstring(game:HttpGet('https://raw.githubusercontent.com/raw-scriptpastebin/raw/main/B_Genesis'))()
	end
})
Tab:AddButton({
	Name = "宠物模拟器",
	Callback = function()
	-- key from https://discord.gg/u7JNWQcgsU
getgenv().key = "projectWBIsAwesomeG8J7GJ678PY"
loadstring(game:HttpGet("https://raw.githubusercontent.com/Muhammad6196/Project-WD/main/Main.lua"))()
    end
})
OrionLib:Init()
end
coroutine.wrap(MNQEF_fake_script)()