local NotificationHolder = loadstring(game:HttpGet("https://raw.githubusercontent.com/BocusLuke/UI/main/STX/Module.Lua"))() 
 local Notification = loadstring(game:HttpGet("https://raw.githubusercontent.com/BocusLuke/UI/main/STX/Client.Lua"))() 

 wait(1) 
 Notification:Notify( 
     {Title = "白灰", Description = "白灰正在加载"}, 
     {OutlineColor = Color3.fromRGB(80, 80, 80),Time = 5, Type = "image"}, 
     {Image = "http://www.roblox.com/asset/?id=4483345998", ImageColor = Color3.fromRGB(255, 84, 84)} 
 ) 
 wait(2) 
 Notification:Notify( 
     {Title = "白灰", Description = "准备好了！"}, 
     {OutlineColor = Color3.fromRGB(80, 80, 80),Time = 5, Type = "image"}, 
     {Image = "http://www.roblox.com/asset/?id=4483345998", ImageColor = Color3.fromRGB(255, 84, 84)} 
 )
 wait(0.9)
 
local Cloudlib = loadstring(game:HttpGet("https://gist.githubusercontent.com/XiaoYunCN/c212174d6263d5a43e95a59110a2724b/raw/c89c61fa5c8149a2554b66f618a32cd3e4d42877/gistfile1.txt", true))()

local window = Cloudlib:new("白灰--造船寻宝")

local creds = window:Tab("主要的",'4483345998')
local Tab2 = creds:section("玩家",true)

Tab2:Slider('步行', 'SliderInfo', 16, 16, 250,false, function(value)
    game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = value
end)

Tab2:Slider('跳跃', 'SliderInfo', 16, 16, 250,false, function(value)
    game.Players.LocalPlayer.Character.Humanoid.JumpPower = value
end)

Tab2:Button("单击TP工具",function()
mouse = game.Players.LocalPlayer:GetMouse()
                tool = Instance.new("Tool")
                tool.RequiresHandle = false
                tool.Name = "Click Teleport"
                tool.Activated:connect(function()
                local pos = mouse.Hit+Vector3.new(0,2.5,0)
                pos = CFrame.new(pos.X,pos.Y,pos.Z)
                game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = pos
                end)
                tool.Parent = game.Players.LocalPlayer.Backpack
end)

Tab2:Button("反AFK",function()
wait(0.5)
    local bb=game:service'VirtualUser'
    game:service'Players'.LocalPlayer.Idled:connect(function()
    bb:CaptureController()
    bb:ClickButton2(Vector2.new())
    end)
 
    print("Antiafk enabled")
end)

Tab2:Button("飞行",function()
loadstring(game:HttpGet("https://pastebin.com/raw/gqv7PXAa"))()
end)

local Tab = creds:section("农扬",true)

Tab:Toggle("自动农场", "text", false, function(FARM)
_G.FARMs = FARM
while _G.FARMs do wait()
    pcall(function()
game.Workspace.Gravity = 0
    wait(0.5)
local TweenService = game:GetService("TweenService")
local Tw = TweenService:Create(game.Players.LocalPlayer.Character.HumanoidRootPart, TweenInfo.new(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out,0,false,0), 
{CFrame = CFrame.new(-51.05019, 43.5682182, 702.193481, -0.999886811, -0.000135422233, 0.0150433034, 8.65181704e-09, 0.999959469, 0.00900237076, -0.0150439134, 0.00900135189, -0.999846339)}):Play()
    wait(1)
local TweenService = game:GetService("TweenService")
local Tw = TweenService:Create(game.Players.LocalPlayer.Character.HumanoidRootPart, TweenInfo.new(30, Enum.EasingStyle.Linear, Enum.EasingDirection.Out,0,false,0), 
{CFrame = CFrame.new(-50.4467354, 34.108551, 8676.95117, -0.999937415, -0.000405743311, 0.0111814411, -6.1212857e-09, 0.999342263, 0.0362627953, -0.0111888004, 0.0362605266, -0.999279737)}):Play()
    wait(30)
local TweenService = game:GetService("TweenService")
local Tw = TweenService:Create(game.Players.LocalPlayer.Character.HumanoidRootPart, TweenInfo.new(5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out,0,false,0), 
{CFrame = CFrame.new(-54.1517258, -359.077667, 9497.03418, -0.99982208, 0.00359633542, -0.0185163822, -7.16419102e-09, 0.981655717, 0.190661997, 0.0188623965, 0.190628082, -0.981481075)}):Play()
    wait(5)
game.Workspace.Gravity = 200
    wait(20)
    end)
 end
end)
Tab:Toggle("自动农场快速[测试版]", "text", false, function(FARM2)
_G.FARM2s = FARM2
while _G.FARM2s do wait()
    pcall(function()
game.Workspace.Gravity = 0
    wait(0.5)
local TweenService = game:GetService("TweenService")
local Tw = TweenService:Create(game.Players.LocalPlayer.Character.HumanoidRootPart, TweenInfo.new(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out,0,false,0), 
{CFrame = CFrame.new(-51.05019, 43.5682182, 702.193481, -0.999886811, -0.000135422233, 0.0150433034, 8.65181704e-09, 0.999959469, 0.00900237076, -0.0150439134, 0.00900135189, -0.999846339)}):Play()
    wait(1)
local TweenService = game:GetService("TweenService")
local Tw = TweenService:Create(game.Players.LocalPlayer.Character.HumanoidRootPart, TweenInfo.new(5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out,0,false,0), 
{CFrame = CFrame.new(-50.4467354, 34.108551, 8676.95117, -0.999937415, -0.000405743311, 0.0111814411, -6.1212857e-09, 0.999342263, 0.0362627953, -0.0111888004, 0.0362605266, -0.999279737)}):Play()
    wait(5)
local TweenService = game:GetService("TweenService")
local Tw = TweenService:Create(game.Players.LocalPlayer.Character.HumanoidRootPart, TweenInfo.new(5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out,0,false,0), 
{CFrame = CFrame.new(-51.05019, 43.5682182, 702.193481, -0.999886811, -0.000135422233, 0.0150433034, 8.65181704e-09, 0.999959469, 0.00900237076, -0.0150439134, 0.00900135189, -0.999846339)}):Play()
    wait(5)
local Event = game:GetService("Workspace").ClaimRiverResultsGold
Event:FireServer()
    wait(0.1)
game.Players.LocalPlayer.Character.Humanoid.Health = -1000
    wait(0.1)
game.Workspace.Gravity = 200
    wait(7)
    end)
 end
end)

Tab:Toggle("自动索赔金", "text", false, function(value)
_G.ClaimGolds = ClaimGold
while _G.ClaimGolds do wait()
    pcall(function()
local Event = game:GetService("Workspace").ClaimRiverResultsGold
Event:FireServer()
    end)
 end
end)
MainSection:Button("ClearAllBoatParts", function()
local Event = game:GetService("Workspace").ClearAllPlayersBoatParts
Event:FireServer()
end)
 
wait(0.5)local ba=Instance.new("ScreenGui")
local ca=Instance.new("TextLabel")local da=Instance.new("Frame")
local _b=Instance.new("TextLabel")local ab=Instance.new("TextLabel")ba.Parent=game.CoreGui
ba.ZIndexBehavior=Enum.ZIndexBehavior.Sibling;ca.Parent=ba;ca.Active=true
ca.BackgroundColor3=Color3.new(0.176471,0.176471,0.176471)ca.Draggable=true
ca.Position=UDim2.new(0.698610067,0,0.098096624,0)ca.Size=UDim2.new(0,370,0,52)
ca.Font=Enum.Font.SourceSansSemibold;ca.Text="Anti AFK Script"ca.TextColor3=Color3.new(0,1,1)
ca.TextSize=22;da.Parent=ca
da.BackgroundColor3=Color3.new(0.196078,0.196078,0.196078)da.Position=UDim2.new(0,0,1.0192306,0)
da.Size=UDim2.new(0,370,0,107)_b.Parent=da
_b.BackgroundColor3=Color3.new(0.176471,0.176471,0.176471)_b.Position=UDim2.new(0,0,0.800455689,0)
_b.Size=UDim2.new(0,370,0,21)_b.Font=Enum.Font.Arial;_b.Text="made by simon"
_b.TextColor3=Color3.new(0,1,1)_b.TextSize=20;ab.Parent=da
ab.BackgroundColor3=Color3.new(0.176471,0.176471,0.176471)ab.Position=UDim2.new(0,0,0.158377,0)
ab.Size=UDim2.new(0,370,0,44)ab.Font=Enum.Font.ArialBold;ab.Text="Status: Active"
ab.TextColor3=Color3.new(0,1,1)ab.TextSize=20;local bb=game:service'VirtualUser'
game:service'Players'.LocalPlayer.Idled:connect(function()
bb:CaptureController()bb:ClickButton2(Vector2.new())
ab.Text="机器人想踢你，但我踢了他"wait(2)ab.Text="状态:活动"
end)